from collections import deque, defaultdict


def parse_schema(schema):
    nodes_section = False
    edges_section = False
    nodes = []
    edges = []

    for line in schema.strip().splitlines():
        line = line.strip()
        if line == "<nodes>":
            nodes_section = True
            continue
        elif line == "</nodes>":
            nodes_section = False
            continue
        elif line == "<edges>":
            edges_section = True
            continue
        elif line == "</edges>":
            edges_section = False
            continue

        if nodes_section:
            if line:
                nodes.append(line)
        elif edges_section:
            if line:
                # Manually parse the line to get the edge as a list
                line = line.strip("[]")  # Remove the square brackets
                edge = line.split(",")  # Split by commas
                edges.append([item.strip() for item in edge])  # Strip spaces and store in edges

    return nodes, edges


def build_graph(edges):
    graph = defaultdict(list)
    for edge in edges:
        src, _, dst = edge
        graph[src].append(dst)
    return graph


def bfs_subgraph(graph, start_node, max_length):
    visited = set()
    queue = deque([(start_node, 0)])
    result_edges = []

    while queue:
        current_node, depth = queue.popleft()
        if depth > max_length:
            continue

        visited.add(current_node)

        for neighbor in graph[current_node]:
            result_edges.append((current_node, neighbor))
            if neighbor not in visited and (neighbor, depth + 1) not in queue:
                queue.append((neighbor, depth + 1))

    return visited, result_edges


def extract_subschema(schema, input_predicate, max_length):
    nodes, edges = parse_schema(schema)

    graph = build_graph(edges)
    visited_nodes, sub_edges = bfs_subgraph(graph, input_predicate, max_length)
    sub_nodes = [node for node in nodes if node.split("[")[0] in visited_nodes]
    return get_subschema_as_variables(sub_nodes, sub_edges)


def get_subschema_as_variables(sub_nodes, sub_edges):
    sub_nodes_str = "<nodes>\n " + "\n".join(sub_nodes) + "\n< /nodes>"
    sub_edges_str = "<edges>\n " + "\n".join([f"[{edge[0]}, Person, {edge[1]}]" for edge in sub_edges]) + "\n </edges>"
    return sub_nodes_str, sub_edges_str


def example():
    # Example schema and usage
    schema = """
    <nodes>
    aunt[Person,Person]
    brother[Person,Person]
    daughter[Person,Person]
    father[Person,Person]
    husband[Person,Person]
    mother[Person,Person]
    nephew[Person,Person]
    niece[Person,Person]
    sister[Person,Person]
    son[Person,Person]
    uncle[Person,Person]
    wife[Person,Person]
    </nodes>
    <edges>
    [aunt,Person,brother]
    [aunt,Person,daughter]
    [aunt,Person,father]
    [aunt,Person,husband]
    [aunt,Person,mother]
    [aunt,Person,nephew]
    [aunt,Person,niece]
    [aunt,Person,sister]
    [aunt,Person,son]
    [aunt,Person,uncle]
    [aunt,Person,wife]
    [brother,Person,daughter]
    [brother,Person,father]
    [brother,Person,husband]
    [brother,Person,mother]
    [brother,Person,nephew]
    [brother,Person,niece]
    [brother,Person,sister]
    [brother,Person,son]
    [brother,Person,uncle]
    [brother,Person,wife]
    [daughter,Person,father]
    [daughter,Person,husband]
    [daughter,Person,mother]
    [daughter,Person,nephew]
    [daughter,Person,niece]
    [daughter,Person,sister]
    [daughter,Person,son]
    [daughter,Person,uncle]
    [daughter,Person,wife]
    [father,Person,husband]
    [father,Person,mother]
    [father,Person,nephew]
    [father,Person,niece]
    [father,Person,sister]
    [father,Person,son]
    [father,Person,uncle]
    [father,Person,wife]
    [husband,Person,mother]
    [husband,Person,nephew]
    [husband,Person,niece]
    [husband,Person,sister]
    [husband,Person,son]
    [husband,Person,uncle]
    [husband,Person,wife]
    [mother,Person,nephew]
    [mother,Person,niece]
    [mother,Person,sister]
    [mother,Person,son]
    [mother,Person,uncle]
    [mother,Person,wife]
    [nephew,Person,niece]
    [nephew,Person,sister]
    [nephew,Person,son]
    [nephew,Person,uncle]
    [nephew,Person,wife]
    [niece,Person,sister]
    [niece,Person,son]
    [niece,Person,uncle]
    [niece,Person,wife]
    [sister,Person,son]
    [sister,Person,uncle]
    [sister,Person,wife]
    [son,Person,uncle]
    [son,Person,wife]
    [uncle,Person,wife]
    </edges>
    """

    input_predicate = "aunt"
    max_length = 2

    subS = extract_subschema(schema, input_predicate=input_predicate, max_length=max_length)
    print((subS))

# example()
