import os
import tiktoken
from llama_index.core import Settings
from llama_index.core.llms import ChatMessage, MessageRole
from llama_index.llms.anthropic import Anthropic
from llama_index.llms.gemini import Gemini
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from typing import List, Tuple, Optional


def create_llm(model_name: str = "gpt-3.5-turbo", timeout: int = 1200):
    """Creates an LLM instance based on the model name."""
    try:
        if model_name.startswith("gpt"):
            return OpenAI(model=model_name, timeout=timeout)
        elif model_name.startswith("claude"):
             # Adjust max_tokens for Anthropic if needed, default is often sufficient
            return Anthropic(model=model_name, timeout=timeout, max_tokens=4000)
        elif model_name.startswith("gemini"):
            # Ensure the model name format is correct for the Gemini API
            # e.g., "gemini-1.5-pro-latest" or "gemini-1.0-pro"
            # The "models/" prefix might be specific to certain SDK versions/uses
            gemini_model_id = f"models/{model_name}" if "models/" not in model_name else model_name
            return Gemini(model=gemini_model_id) # timeout might not be direct param, handled by underlying client
        elif model_name.startswith("ollama_"):
            m_name = model_name[7:]  # strip the prefix ollama_
            return Ollama(model=m_name, request_timeout=timeout)
        else:
            raise ValueError(f"Unknown or unsupported model prefix: {model_name}")
    except Exception as e:
        print(f"Error creating LLM for {model_name}: {e}")
        raise # Re-raise the exception to stop execution if LLM can't be created


# --- Simulation Setup ---
coordinator="ollama_gemma3:27b"
agent_1="ollama_deepseek-r1:1.5b"
agent_2="ollama_qwen2.5:72b"
agent_3="ollama_qwen3:30b-a3b"
#gemma3:27b
#qwen3:30b-a3b

# 1. Define the LLMs for the simulation
#    Using gpt-3.5-turbo for agents as a cost-effective alternative
coordinator_llm = create_llm(model_name=coordinator)
agent1_llm = create_llm(model_name=agent_1)
agent2_llm = create_llm(model_name=agent_2)
agent3_llm = create_llm(model_name=agent_3)

agents = {
    f"Agent1 {agent_1}": agent1_llm,
    f"Agent2 {agent_2}": agent2_llm,
    f"Agent3 {agent_3}": agent3_llm,
}
coordinator_name = f"Coordinator {coordinator}"

# 2. Define the task and context
rules_to_debate = """
1. wasBornIn(X, L) ← livesIn(X, L)  [Confidence: Low - People often move]
2. worksAt(X, O) ← isAffiliatedTo(X, O) [Confidence: Medium - Affiliation often implies working, but not always]
3. isLeaderOf(X, O) ← worksAt(X, O) ∧ owns(X, O) [Confidence: High - Owning and working usually means leadership]
"""
kg_schema = """
# Entity Types: Person, Location, Organization, Award, CreativeWork
# Relations:
wasBornIn(Person, Location)
livesIn(Person, Location)
worksAt(Person, Organization)
isAffiliatedTo(Person, Organization)
isLeaderOf(Person, Organization)
owns(Person, Organization)
hasWonPrize(Person | CreativeWork, Award)
hasChild(Person, Person)
# ... (add more relevant schema details if available)
"""

# 3. Define the simulation function
def simulate_consensus_discussionOLD(
    coordinator_llm,
    agents: dict,
    rules: str,
    schema: str,
    rounds: int = 3, # Number of discussion rounds among agents
    prompt_path: str = None
) -> str:
    """Simulates a multi-turn discussion between LLM agents and a coordinator."""

    # Read consensus prompt from file if provided
    if prompt_path:
        try:
            with open(prompt_path + "spca_consensus_prompt.txt", 'r') as f:
                consensus_prompt_template = f.read()
        except FileNotFoundError:
            print(f"Warning: consensus_prompt.txt not found at {prompt_path}, using default prompt")
            exit(0)
        
        # Read user instruction from file
        try:
            with open(prompt_path + "spca_consensus_prompt.txt", 'r') as f:
                user_instruction_template = f.read()
        except FileNotFoundError:
            print(f"Warning: consensus_user_instruction.txt not found at {prompt_path}, using default instruction")
            exit(0)

    # Replace coordinator name placeholder
    consensus_prompt = consensus_prompt_template.format(coordinator_name=coordinator_name)
    
    # Replace variables in user instruction
    user_instruction = user_instruction_template.format(
        rules=rules,
        schema=schema,
        rounds=rounds,
        coordinator_name=coordinator_name
    )

    # Initial system message for all participants
    system_message = ChatMessage(
        role=MessageRole.SYSTEM,
        content=consensus_prompt
    )

    # Initial user prompt setting up the debate
    initial_user_prompt = ChatMessage(
        role=MessageRole.USER,
        content=user_instruction
    )

    conversation_history: List[ChatMessage] = [system_message, initial_user_prompt]

    print(f"--- Starting Debate ---")
    print(f"{initial_user_prompt.role.capitalize()}: {initial_user_prompt.content}\n")

    # --- Agent Discussion Rounds ---
    for r in range(rounds):
        print(f"--- Round {r+1} ---")
        for agent_name, agent_llm in agents.items():
            # Prompt the specific agent
            agent_prompt = ChatMessage(
                role=MessageRole.USER,
                content=f"{agent_name}, please provide your analysis and critique based on the discussion so far."
            )
            current_turn_history = conversation_history + [agent_prompt]

            try:
                # Ensure history isn't too long for the agent
                # (Simple approach: limit history length, more complex: summarization)
                max_hist_len = 10 # Keep last N messages for context
                limited_history = [system_message] + current_turn_history[-max_hist_len:]

                print(f"Asking {agent_name}...")
                response = agent_llm.chat(limited_history)
                agent_response_content = response.message.content

                # Add agent's response to history
                conversation_history.append(ChatMessage(
                    role=MessageRole.ASSISTANT,
                    content=agent_response_content,
                    # Store which agent said what in additional_kwargs
                    additional_kwargs={"agent_name": agent_name}
                ))
                print(f"{agent_name}: {agent_response_content}\n")

            except Exception as e:
                print(f"Error during {agent_name}'s turn: {e}")
                # Add an error message to history or handle as needed
                conversation_history.append(ChatMessage(
                    role=MessageRole.SYSTEM,
                    content=f"Error encountered for {agent_name}. Skipping turn."
                ))
            print("************CURRENT CHAT HISTORY************")
            print(current_turn_history)
            print("************CURRENT CHAT HISTORY************")
    # --- Coordinator Summarization ---
    print(f"--- Coordinator Summarization ---")
    coordinator_prompt = ChatMessage(
        role=MessageRole.USER,
        content=(
            f"{coordinator_name}, based on the entire discussion above, please provide the final "
            "consensus ranking of the rules, including confidence levels and key justifications or disagreements."
        )
    )
    final_history = conversation_history + [coordinator_prompt]

    try:
         # Limit history again if necessary
        #max_hist_len = 20
        #limited_final_history = [system_message] + final_history[-max_hist_len:]

        limited_final_history =final_history
        print(limited_final_history)
        print(f"Asking {coordinator_name} for final consensus...")
        final_response = coordinator_llm.chat(limited_final_history)
        consensus_content = final_response.message.content

        print(f"\n{coordinator_name}: {consensus_content}\n")
        return consensus_content

    except Exception as e:
        print(f"Error during coordinator's summarization: {e}")
        return "Error: Could not generate final consensus."




def simulate_consensus_discussion(
        coordinator_llm,
        agents: dict,
        rules: str,
        schema: str,
        rounds: int = 3,
        prompt_path: str = None,
        predicate_id: str = None,  # NEW: Unique identifier for this predicate
        base_prompt_name: str = "c2r_new",  # Selected BASE prompt type
        base_prompt_text: Optional[str] = None,  # EXACT prompt used in generation from main_SOLAR
        out_root: Optional[str] = None,  # Root directory to write per-agent/coordinator artifacts
        coordinator_model_name: Optional[str] = None,  # For Coordinator_ dir naming
) -> str:
    """Token-optimized multi-turn discussion between LLM agents and coordinator.

    CRITICAL: Each call is for a DIFFERENT predicate - all history must be reset!
    """

    # 🔴 CRITICAL: RESET ALL CONVERSATION STATE
    print(f"🔄 RESETTING for new predicate: {predicate_id or 'unknown'}")

    # 1. EXTRACT STATIC CONTENT (cached/reused)
    predicate_session_id = f"PRED_{hash(rules + schema) % 10000}_{predicate_id or 'unknown'}"
    static_schema_ref = f"[SCHEMA_ID: {predicate_session_id}]"

    # 2. LOAD PROMPTS
    base_prompt = base_prompt_text or ""
    user_instruction = ""
    if prompt_path:
        # If the exact prompt text wasn't passed, fall back to files
        if not base_prompt:
            base_candidates = [
                f"{base_prompt_name}.txt",            # selected base
                "spca_consensus_prompt.txt",         # legacy consensus base prompt
                "c2r_consensus.txt",                 # dataset-specific consensus
            ]
            for fname in base_candidates:
                p = os.path.join(prompt_path, fname)
                if os.path.exists(p):
                    try:
                        with open(p, 'r') as f:
                            base_prompt = f.read()
                        break
                    except Exception:
                        pass
        # Debate/user instruction is mandatory; raise a clearer error if missing
        cui_path = os.path.join(prompt_path, "consensus_user_instruction.txt")
        if not os.path.exists(cui_path):
            raise FileNotFoundError(
                f"consensus_user_instruction.txt not found under {prompt_path}."
            )
        with open(cui_path, 'r') as f:
            user_instruction = f.read()

    # 3. 🔴 FRESH SESSION SETUP - NO PREVIOUS PREDICATE CONTAMINATION
    # Try formatting coordinator_name if placeholder exists; otherwise keep raw
    try:
        formatted_base = base_prompt.format(coordinator_name=coordinator_name)
    except Exception:
        formatted_base = base_prompt

    # System reset plus the EXACT initial instruction used for generation
    fresh_schema_setup = ChatMessage(
        role=MessageRole.SYSTEM,
        content=(
            f"[NEW_SESSION: {predicate_session_id}]\n"
            f"{formatted_base}\n"
            f"🔴 IMPORTANT: This is a completely new predicate analysis. "
            f"Ignore any previous discussions about other predicates."
        )
    )

    # 4. COMPRESSED INITIAL INSTRUCTION (no schema repetition)
    initial_instruction = user_instruction.format(
        rules=rules,
        schema=schema,  # Use the real schema text to mirror initial context
        rounds=rounds,
        coordinator_name=coordinator_name
    )

    # 5. 🔴 COMPLETELY FRESH CONVERSATION STATE
    conversation_summary = ""  # Reset summary
    current_round_history = []  # Reset round history
    all_agent_messages: List[ChatMessage] = []  # Accumulate across rounds

    print(f"--- Starting FRESH Token-Optimized Debate for {predicate_session_id} ---")

    # Prepare output directories (optional)
    def _sanitize(name: str) -> str:
        return name.replace("/", "-").replace(":", "-").replace(" ", "_")

    coord_dir = None
    agent_dirs = {}
    if out_root and predicate_id:
        try:
            if coordinator_model_name:
                safe_coord = _sanitize(str(coordinator_model_name))
                coord_dir = os.path.join(out_root, f"Coordinator_{safe_coord}")
                os.makedirs(coord_dir, exist_ok=True)
            # Prepare per-agent directories
            for agent_name in agents.keys():
                safe_agent = _sanitize(agent_name)
                a_dir = os.path.join(out_root, safe_agent)
                os.makedirs(a_dir, exist_ok=True)
                agent_dirs[agent_name] = a_dir
        except Exception as _e:
            # Non-fatal: continue without logging
            coord_dir = None
            agent_dirs = {}

    # 6. CONVERSATION SUMMARIZATION STRATEGY
    def summarize_previous_rounds(history: List[ChatMessage], max_summary_tokens: int = 500) -> str:
        """Compress conversation history into key points."""
        if len(history) <= 3:  # Keep short conversations as-is
            return ""

        # Extract key points from each agent's contributions
        agent_positions = {}
        for msg in history:
            if hasattr(msg, 'additional_kwargs') and 'agent_name' in msg.additional_kwargs:
                agent_name = msg.additional_kwargs['agent_name']
                if agent_name not in agent_positions:
                    agent_positions[agent_name] = []
                # Extract first sentence as key position
                first_sentence = msg.content.split('.')[0] + '.'
                agent_positions[agent_name].append(first_sentence)

        # Create compressed summary
        summary_parts = []
        for agent, positions in agent_positions.items():
            latest_position = positions[-1] if positions else "No clear position"
            summary_parts.append(f"{agent}: {latest_position}")

        return f"Summary of CURRENT predicate discussion:\n" + "\n".join(summary_parts)

    # 7. 🔴 AGENT DISCUSSION WITH EXPLICIT SESSION ISOLATION
    for r in range(rounds):
        print(f"--- Round {r + 1} ---")
        round_responses = []

        for agent_name, agent_llm in agents.items():
            # 🔴 BUILD COMPLETELY FRESH CONTEXT FOR THIS AGENT
            agent_context = [fresh_schema_setup]  # Fresh session with explicit reset

            # Add compressed history ONLY from current predicate discussion
            if conversation_summary:
                summary_msg = ChatMessage(
                    role=MessageRole.SYSTEM,
                    content=f"🔴 CURRENT PREDICATE ONLY: {conversation_summary}"
                )
                agent_context.append(summary_msg)

            # Add only current round's relevant exchanges (not full history!)
            if current_round_history:
                recent_context = ChatMessage(
                    role=MessageRole.SYSTEM,
                    content=f"Current round context (THIS PREDICATE ONLY): {'; '.join(current_round_history[-3:])}"
                )
                agent_context.append(recent_context)

            # 🔴 EXPLICIT AGENT PROMPT WITH SESSION ISOLATION
            agent_prompt = ChatMessage(
                role=MessageRole.USER,
                content=(
                    f"🔴 NEW PREDICATE SESSION: {predicate_session_id}\n"
                    f"{agent_name}, analyze ONLY these rules for THIS predicate: {rules[:200]}{'...' if len(rules) > 200 else ''}\n"
                    f"Ignore any previous predicate discussions. Your position (max 150 words):"
                )
            )
            agent_context.append(agent_prompt)

            try:
                print(f"Asking {agent_name} (context: {sum(len(msg.content) for msg in agent_context)} chars)...")
                response = agent_llm.chat(agent_context)
                agent_response = response.message.content

                # Store only essential info
                round_responses.append(f"{agent_name}: {agent_response}")
                current_round_history.append(f"{agent_name}: {agent_response[:100]}...")  # Truncated for next context
                # Save full message for cumulative summarization
                all_agent_messages.append(ChatMessage(
                    role=MessageRole.ASSISTANT,
                    content=agent_response,
                    additional_kwargs={"agent_name": agent_name}
                ))

                print(f"{agent_name}: {agent_response}\n")

                # Persist agent response for this round
                if agent_dirs and agent_name in agent_dirs and predicate_id:
                    try:
                        out_path = os.path.join(agent_dirs[agent_name], f"{_sanitize(predicate_id)}_round{r+1}.txt")
                        with open(out_path, 'w') as af:
                            af.write(agent_response)
                    except Exception:
                        pass

            except Exception as e:
                print(f"Error with {agent_name}: {e}")
                round_responses.append(f"{agent_name}: [Error]")

        # 8. UPDATE ROLLING SUMMARY (compress all rounds so far)
        conversation_summary = summarize_previous_rounds(all_agent_messages)
        # Keep only current round in active history for final positions
        current_round_history = current_round_history[-len(agents):]

    # 9. 🔴 COORDINATOR FINAL CONSENSUS (completely fresh context)
    print(f"--- Coordinator Summarization for {predicate_session_id} ---")

    final_context = [
        fresh_schema_setup,  # Fresh session setup
        ChatMessage(
            role=MessageRole.SYSTEM,
            content=(
                f"🔴 FINAL CONSENSUS FOR PREDICATE: {predicate_session_id}\n"
                f"{conversation_summary if conversation_summary else 'No previous discussion for this predicate.'}"
            )
        ),
        ChatMessage(
            role=MessageRole.SYSTEM,
            content=f"Final round positions (THIS PREDICATE ONLY): {'; '.join(current_round_history)}"
        ),
        ChatMessage(
            role=MessageRole.USER,
            content=(
                f"🔴 FINAL TASK FOR {predicate_session_id}\n"
                f"{coordinator_name}, provide final consensus ranking for THIS predicate only "
                f"with confidence levels (max 200 words). Ignore all previous predicates:"
            )
        )
    ]

    try:
        total_chars = sum(len(msg.content) for msg in final_context)
        print(f"Final consensus context: {total_chars} chars...")

        final_response = coordinator_llm.chat(final_context)
        consensus_content = final_response.message.content

        print(f"\n{coordinator_name}: {consensus_content}\n")
        # Persist coordinator final consensus
        if coord_dir and predicate_id:
            try:
                out_path = os.path.join(coord_dir, f"{_sanitize(predicate_id)}_consensus.txt")
                with open(out_path, 'w') as cf:
                    cf.write(consensus_content)
            except Exception:
                pass

        # === FINAL VOTING PHASE (participants output -1/0/+1 per rule) ===
        # Compact debate recap to condition judgments
        recap = conversation_summary if conversation_summary else 'No prior discussion summary.'
        recap += "\nFinal positions: " + ('; '.join(current_round_history) if current_round_history else 'N/A')

        # Extract rule-like lines for stable voting; fallback to raw if none
        def _extract_rule_lines(txt: str) -> List[str]:
            out = []
            seen = set()
            for ln in str(txt).splitlines():
                s = ln.strip()
                if ':-' in s and '(' in s and ')' in s:
                    if s not in seen:
                        seen.add(s)
                        out.append(s)
            return out

        rule_lines = _extract_rule_lines(rules)
        rules_block = "\n".join(rule_lines) if rule_lines else str(rules)

        # Strict voting prompt: output exactly one integer per rule in order
        voting_instruction = (
            "You are voting on the quality of each horn rule.\n"
            "For EACH rule, output exactly one integer on its own line: -1 (reject), 0 (neutral/uncertain), or +1 (accept).\n"
            "Do NOT include any text besides these integers. Maintain the input order of rules.\n"
            "Rules:\n{rules}\n"
        )

        # Prepare a voting helper
        def vote_with_history(llm, name: str, out_dir: str):
            user_text = voting_instruction.format(rules=rules_block)
            msgs = [
                ChatMessage(role=MessageRole.SYSTEM, content=f"Debate recap (use as background only):\n{recap}"),
                ChatMessage(role=MessageRole.USER, content=user_text),
            ]
            try:
                resp = llm.chat(msgs)
                txt = resp.message.content
                if out_dir and predicate_id:
                    fp = os.path.join(out_dir, f"{_sanitize(predicate_id)}_final_votes.txt")
                    with open(fp, 'w') as f:
                        f.write(txt)
            except Exception:
                pass

        # Vote with each agent
        for agent_name, agent_llm in agents.items():
            a_dir = agent_dirs.get(agent_name) if agent_dirs else None
            vote_with_history(agent_llm, agent_name, a_dir or '')
        # Vote with coordinator
        vote_with_history(coordinator_llm, coordinator_name, coord_dir or '')
        return consensus_content

    except Exception as e:
        print(f"Error during coordinator's summarization: {e}")
        return "Error: Could not generate final consensus."


# ADDITIONAL OPTIMIZATION: Prompt Caching Wrapper
def cache_optimized_chat(llm, messages, cache_boundary_content=None):
    """Wrapper to leverage prompt caching when available."""
    if cache_boundary_content and hasattr(llm, 'supports_caching'):
        # Restructure messages to maximize cache hits
        cached_msgs = [msg for msg in messages if cache_boundary_content in msg.content]
        non_cached_msgs = [msg for msg in messages if cache_boundary_content not in msg.content]
        return llm.chat(cached_msgs + non_cached_msgs)
    else:
        return llm.chat(messages)


# TOKEN USAGE MONITORING
def estimate_tokens(text: str) -> int:
    """Rough token estimation: ~4 chars per token."""
    return len(text) // 4


def log_token_usage(messages: List[ChatMessage], stage: str):
    """Log token usage for monitoring."""
    total_chars = sum(len(msg.content) for msg in messages)
    estimated_tokens = estimate_tokens(''.join(msg.content for msg in messages))
    print(f"[TOKEN USAGE] {stage}: ~{estimated_tokens} tokens ({total_chars} chars)")

# --- Run the Simulation ---
if __name__ == "__main__":

    final_consensus = simulate_consensus_discussion(
        coordinator_llm=coordinator_llm,
        agents=agents,
        rules=rules_to_debate,
        schema=kg_schema,
        rounds=2 # Adjust number of rounds as needed
    )

    print("--- Final Consensus Result ---")
    print(final_consensus)
