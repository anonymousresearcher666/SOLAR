
from llama_index.core import Settings
import os
import warnings
try:
    from transformers.utils import logging as hf_logging  # type: ignore
    os.environ.setdefault('TRANSFORMERS_VERBOSITY', 'error')
    hf_logging.set_verbosity_error()
    # Silence the specific FutureWarning about clean_up_tokenization_spaces
    warnings.filterwarnings(
        "ignore",
        message=r".*clean_up_tokenization_spaces.*",
        category=FutureWarning,
    )
except Exception:
    pass
from llama_index.core.llms import ChatMessage
from llama_index.llms.anthropic import *
from llama_index.llms.gemini import *
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import *

import os
import tiktoken
from anthropic import Anthropic

os.environ["OPENAI_API_KEY"] = ""
os.environ["ANTHROPIC_API_KEY"] = ""
os.environ["GEMINI_API_KEY"] = ""
os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = "/Volumes/DATI/GitHub/SOLAR/rule-learning.json"


def get_tokenizer_and_limit(model_name):
    if model_name in ['gpt-4-turbo', 'gpt-4o', 'gpt-4o-2024-08-06', 'gpt-4o-mini-2024-07-18']:
        max_tokens = 128000
        # Using tiktoken library for OpenAI GPT models
        tokenizer = tiktoken.encoding_for_model(model_name)
    elif model_name.startswith("claude"):
        tokenizer = Anthropic().tokenizer
        Settings.tokenizer = tokenizer
        tokenizer = None  # Anthropics models may not use a traditional tokenizer
        max_tokens = 200000
    elif model_name.startswith("gemini"):
        # Hypothetical tokenizer and limit for Gemini
        tokenizer = None
        max_tokens = 1000000
    elif model_name.startswith("llama"):
        # Hypothetical tokenizer and limit for LLaMA
        tokenizer = None
        max_tokens = 4096  # Replace with actual limit
    else:
        raise ValueError(f"Unknown model: {model_name}")
    return tokenizer, max_tokens


def count_tokens(text, model_name):
    """Count tokens for a given text and model."""
    tokenizer, _ = get_tokenizer_and_limit(model_name)

    if tokenizer:
        if model_name.startswith("gpt"):
            # OpenAI models
            return len(tokenizer.encode(text))
        elif model_name.startswith("claude"):
            # Anthropic models - use their tokenizer
            client = Anthropic()
            return client.count_tokens(text)
    else:
        # Fallback approximation for models without tokenizers
        return len(text) // 4


def count_message_tokens(messages, model_name):
    """Count tokens for a list of messages."""
    tokenizer, _ = get_tokenizer_and_limit(model_name)

    if tokenizer and model_name.startswith("gpt"):
        # OpenAI models with proper message formatting
        total_tokens = 0
        for message in messages:
            total_tokens += len(tokenizer.encode(message.content))
            total_tokens += 4  # Message overhead (role, formatting, etc.)
        total_tokens += 2  # Conversation overhead
        return total_tokens
    elif model_name.startswith("claude"):
        # Anthropic models
        client = Anthropic()
        # Combine all message content
        combined_text = " ".join([msg.content for msg in messages])
        return client.count_tokens(combined_text)
    else:
        # Fallback for other models
        combined_text = " ".join([msg.content for msg in messages])
        return len(combined_text) // 4


def tokenize_input(input_text, model_name):
    tokenizer, max_tokens = get_tokenizer_and_limit(model_name)
    if tokenizer:
        tokenized_input = tokenizer.encode(input_text)
        token_count = len(tokenized_input)
        if token_count > max_tokens:
            print(f"Warning: Input exceeds maximum token limit of {max_tokens} tokens. Truncating input.")
            tokenized_input = tokenized_input[:max_tokens]
            input_text = tokenizer.decode(tokenized_input)
    return input_text


def create_llm(model_name="gpt-4"):
    timeout = 6000
    if model_name.startswith("gpt"):
        llm = OpenAI(model=model_name, timeout=timeout)
    elif model_name.startswith("claude"):
        llm = Anthropic(model=model_name, timeout=timeout, max_tokens=4000)
    elif model_name.startswith("gemini"):
        llm = Gemini(model="models/" + model_name)
    elif model_name.startswith("ollama_"):
        m_name = model_name[7:]  # strip the prefix ollama_
        llm = Ollama(model=m_name, request_timeout=timeout)
    else:
        raise ValueError(f"Unknown model: {model_name}")
    return llm


def query_remote_llm(input_text, llm, model_name=None):
    system_message = "You are an AI assistant tasked with learning logical rules (horn rules) based on a given Knowledge Graph (KG) schema.Your goal is to generate closed rules, assess their confidence, and provide counter-examples"

    messages = [
        ChatMessage(role="system", content=system_message),
        ChatMessage(role="user", content=input_text),
    ]

    # Count input tokens if model_name is provided
    if model_name:
        input_tokens = count_message_tokens(messages, model_name)
        print(f"Input tokens ({model_name}): {input_tokens}")

    response = llm.chat(messages)

    # Count output tokens if model_name is provided
    if model_name:
        output_tokens = count_tokens(response.message.content, model_name)
        total_tokens = input_tokens + output_tokens
        print(f"Output tokens ({model_name}): {output_tokens}")
        print(f"Total tokens ({model_name}): {total_tokens}")

    return response

def create_agent_llms(agent_models):
    """Create dictionary of agent LLMs from model names."""
    agents = {}
    for i, model_name in enumerate(agent_models):
        agent_name = f"Agent{i + 1}_{model_name}"
        agents[agent_name] = create_llm(model_name)
    return agents
