#!/usr/bin/env python3
import argparse
import csv
import os
import random
import re
from pathlib import Path
from typing import Dict, List, Tuple

from quality_llm.common.RuleExtractor import RuleExtractor


def load_sampled(sample_csv: Path) -> List[Tuple[str, str]]:
    pairs = []
    with open(sample_csv, 'r', encoding='utf-8') as f:
        r = csv.DictReader(f)
        for row in r:
            pairs.append((row['dataset'], row['predicate']))
    return pairs


def canonicalize_rule(rule_text: str) -> str:
    # Normalize whitespace, remove markdown artifacts
    t = rule_text.strip()
    t = t.replace('**', '').replace('`', '')
    t = re.sub(r"\s+", " ", t)
    return t


def body_length(rule_text: str) -> int:
    if ':-' not in rule_text:
        return 0
    _, body = rule_text.split(':-', 1)
    # split by commas outside parentheses (simple heuristic)
    depth = 0
    parts = []
    cur = []
    for ch in body:
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
        if ch == ',' and depth == 0:
            parts.append(''.join(cur).strip())
            cur = []
        else:
            cur.append(ch)
    if cur:
        parts.append(''.join(cur).strip())
    return len([p for p in parts if p])


def collect_from_dir(method_dir: Path, dataset: str, predicate: str, max_rules: int) -> List[Dict]:
    out = []
    if not method_dir.exists():
        return out
    # Expect per-predicate files like <predicate>_consensus.txt; fallback by scanning all .txt
    candidates = list(method_dir.glob(f"{predicate}*.txt"))
    if not candidates:
        candidates = list(method_dir.glob("*.txt"))

    extractor = RuleExtractor(method_dir)
    # Temporarily process only this file set
    rules = []
    for f in candidates:
        rules.extend(extractor.extract_rules_from_file(f))

    # Fallback: plain pattern "head(...) :- body(...)" lines
    if not rules:
        pat = re.compile(r"\b\w+\s*\([^)]+\)\s*:-\s*[^\n]+")
        for f in candidates:
            text = f.read_text(encoding='utf-8', errors='ignore')
            for m in pat.finditer(text):
                rules.append({'full_rule': m.group(0), 'file': f.name})

    # Filter by predicate head
    filtered = []
    for r in rules:
        fr = canonicalize_rule(r['full_rule'])
        head = fr.split(':-', 1)[0].strip()
        if head.lower().startswith(predicate.lower() + '('):
            filtered.append({'rule_text': fr, 'source_file': r.get('file', '')})

    # Deduplicate by canonical text
    seen = set()
    unique = []
    for r in filtered:
        key = r['rule_text']
        if key not in seen:
            seen.add(key)
            unique.append(r)
    return unique[:max_rules]


def balanced_sample(rules: List[Dict], target_n: int, seed: int) -> List[Dict]:
    # Length target proportions: 1->20%, 2->50%, 3->30%
    random.seed(seed)
    by_len: Dict[int, List[Dict]] = {}
    for r in rules:
        bl = body_length(r['rule_text'])
        by_len.setdefault(bl, []).append(r)

    targets = {1: int(round(target_n * 0.2)), 2: int(round(target_n * 0.5)), 3: int(round(target_n * 0.3))}
    # Fix rounding
    diff = target_n - sum(targets.values())
    if diff != 0:
        targets[2] = targets.get(2, 0) + diff

    selected = []
    for L, n in targets.items():
        pool = by_len.get(L, [])[:]
        random.shuffle(pool)
        selected.extend(pool[:n])

    # Backfill if short
    if len(selected) < target_n:
        rest = []
        for L, pool in by_len.items():
            rest.extend(pool)
        random.shuffle(rest)
        need = target_n - len(selected)
        selected.extend([r for r in rest if r not in selected][:need])
    return selected[:target_n]


def main():
    ap = argparse.ArgumentParser(description='Collect rules for human annotation.')
    ap.add_argument('--sample', type=str, required=True, help='sampled_predicates.csv path')
    ap.add_argument('--consensus-dir', type=str, required=True, help='Consensus rules directory')
    ap.add_argument('--pool-dir', type=str, required=True, help='Pool rules directory')
    ap.add_argument('--baseline-dir', type=str, default=None, help='Baseline rules directory (optional)')
    ap.add_argument('--per-method', type=int, default=5, help='Rules per method per predicate')
    ap.add_argument('--seed', type=int, default=2025)
    ap.add_argument('--out', type=str, default='human_evaluation/out/rules_for_annotation.csv')
    args = ap.parse_args()

    pairs = load_sampled(Path(args.sample))
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    rows = []
    for dataset, predicate in pairs:
        for method, mdir in [
            ('solar_consensus', Path(args.consensus_dir)),
            ('solar_pool', Path(args.pool_dir)),
        ]:
            rules = collect_from_dir(mdir, dataset, predicate, max_rules=100)
            chosen = balanced_sample(rules, args.per_method, args.seed)
            for r in chosen:
                rows.append([
                    dataset, predicate, method, body_length(r['rule_text']), r['rule_text'], r['source_file']
                ])

        if args.baseline_dir:
            rules = collect_from_dir(Path(args.baseline_dir), dataset, predicate, max_rules=100)
            chosen = balanced_sample(rules, args.per_method, args.seed)
            for r in chosen:
                rows.append([
                    dataset, predicate, 'baseline', body_length(r['rule_text']), r['rule_text'], r['source_file']
                ])

    with open(out_path, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['dataset', 'predicate', 'method', 'body_len', 'rule_text', 'source_file'])
        w.writerows(rows)
    print(f"Wrote {out_path} with {len(rows)} rules")


if __name__ == '__main__':
    main()
