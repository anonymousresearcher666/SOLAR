#!/usr/bin/env python3
import argparse
import csv
import random
from collections import defaultdict
from pathlib import Path
from typing import List, Dict, Callable


def read_stats(path: Path):
    rows = []
    with open(path, 'r', encoding='utf-8') as f:
        r = csv.DictReader(f)
        for row in r:
            rows.append(row)
    return rows


def read_triples(path: Path):
    triples = []
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            s = line.strip().split()
            if len(s) != 3:
                continue
            h, r, t = s
            triples.append((h, r, t))
    return triples


def build_id_to_name_mapper(ds_root: Path, ds_name: str) -> Callable[[str], str]:
    rels_file = (ds_root / ds_name / 'relations.txt')
    mapping = None
    if rels_file.exists():
        names = [line.strip() for line in rels_file.read_text(encoding='utf-8').splitlines()]
        mapping = {str(i): n for i, n in enumerate(names)}

    def mapper(pred: str) -> str:
        if mapping is not None and pred.isdigit() and pred in mapping:
            return mapping[pred]
        return pred

    return mapper


def compute_stats(triples):
    counts: Dict[str, int] = defaultdict(int)
    heads_per_r: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
    tails_per_r: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
    for h, r, t in triples:
        counts[r] += 1
        heads_per_r[r][h] += 1
        tails_per_r[r][t] += 1
    stats = {}
    for r in set(counts.keys()):
        num_facts = counts[r]
        tph = num_facts / max(1, len(heads_per_r[r]))
        hpt = num_facts / max(1, len(tails_per_r[r]))
        stats[r] = {'num_facts': num_facts, 'avg_tph': round(tph, 4), 'avg_hpt': round(hpt, 4)}
    return stats


def degree_type(avg_tph: float, avg_hpt: float, eps: float = 1.2) -> str:
    tph_many = avg_tph > eps
    hpt_many = avg_hpt > eps
    if not tph_many and not hpt_many:
        return '1-1'
    if tph_many and not hpt_many:
        return '1-N'
    if not tph_many and hpt_many:
        return 'N-1'
    return 'N-N'


def quartiles(values: List[int]):
    if not values:
        return (0, 0, 0)
    sorted_vals = sorted(values)
    k = len(sorted_vals)
    def qpos(p):
        return sorted_vals[int(p * (k - 1))]
    return (qpos(0.25), qpos(0.5), qpos(0.75))


def sample_buckets(rows, target_n, seed, allow_repeats=False):
    # buckets by degree_type x freq_quartile
    random.seed(seed)
    buckets = defaultdict(list)
    for row in rows:
        key = (row['degree_type'], row['freq_quartile'])
        buckets[key].append(row)

    # Desired distribution of degree types (approx) within dataset
    degree_weights = {
        '1-1': 0.10,
        '1-N': 0.25,
        'N-1': 0.25,
        'N-N': 0.40,
    }

    # First allocate by degree type
    degree_targets = {dt: int(round(target_n * w)) for dt, w in degree_weights.items()}
    # Fix rounding to sum exactly target_n
    diff = target_n - sum(degree_targets.values())
    if diff != 0:
        # add/remove from the largest bucket
        max_dt = max(degree_targets, key=lambda k: degree_targets[k])
        degree_targets[max_dt] += diff

    # Within each degree type, select across quartiles as evenly as possible
    selected = []
    for dt, n_dt in degree_targets.items():
        # collect quartile subsets
        quart_keys = [(dt, q) for q in ['Q1', 'Q2', 'Q3', 'Q4']]
        pool = {k: buckets.get(k, [])[:] for k in quart_keys}
        # simple round-robin over quartiles
        order = []
        qi = 0
        while len(order) < n_dt and sum(len(pool[k]) for k in quart_keys) > 0:
            k = quart_keys[qi % 4]
            if pool[k]:
                order.append(k)
                pool[k].pop(random.randrange(len(pool[k])))  # reserve spot
            qi += 1
        # Now actually sample from buckets for real rows
        # Rebuild pools
        pool = {k: buckets.get(k, [])[:] for k in quart_keys}
        count_dt = 0
        for k in order:
            if pool[k]:
                row = random.choice(pool[k])
                # remove chosen
                pool[k].remove(row)
                buckets[k].remove(row)
                selected.append(row)
                count_dt += 1
                if count_dt >= n_dt:
                    break

    # If still under target (sparse buckets), fill from remaining
    if len(selected) < target_n:
        remaining = []
        for lst in buckets.values():
            remaining.extend(lst)
        random.shuffle(remaining)
        need = target_n - len(selected)
        selected.extend(remaining[:need])
    # If still under and repeats allowed, sample with replacement
    if len(selected) < target_n and allow_repeats and rows:
        need = target_n - len(selected)
        for _ in range(need):
            selected.append(random.choice(rows))

    return selected[:target_n]


def main():
    ap = argparse.ArgumentParser(description='Sample predicates with stratification per dataset.')
    ap.add_argument('--use-stats', action='store_true',default=True, help='If set, sample from a precomputed stats CSV (recommended)')
    ap.add_argument('--stats', type=str, default='./sampling/predicate_stats.csv', help='Path to predicate_stats.csv (used when --use-stats is set)')
    ap.add_argument('--dataset-root', type=str, default='dataset', help='Dataset root (absolute or relative to repo root; used if --stats not provided)')
    ap.add_argument('--datasets', nargs='*', default=None, help='Datasets to include; if omitted, auto-detect under dataset root (supports nested like no_schema/wn-18rr)')
    ap.add_argument('--seed', type=int, default=2025)
    ap.add_argument('--quota', action='append', default=None,
                    help="Per-dataset quotas as 'dataset:n'. Repeat --quota for multiple. Example: --quota yago:9 --quota fb15k187:50")
    ap.add_argument('--wn18rr', type=int, default=3)
    ap.add_argument('--fb15k', type=int, default=50)
    ap.add_argument('--yago3-10', type=int, default=9)
    ap.add_argument('--min-facts', type=int, default=1, help='Minimum number of facts required to include a predicate')
    ap.add_argument('--exact', action='store_true', help='Meet exact quota by sampling with replacement when pool is small')
    ap.add_argument('--out', type=str, default='./sampling/sampled_predicates.csv')
    args = ap.parse_args()

    # Resolve dataset root relative to repo root if needed
    repo_root = Path(__file__).resolve().parents[1]
    ds_root = Path(args.dataset_root)
    if not ds_root.is_absolute():
        ds_root = repo_root / ds_root

    # Auto-detect datasets if not provided and not using stats
    datasets = args.datasets
    if not datasets and not args.use_stats:
        candidates = set()
        for p in list(ds_root.glob('*/predicates.txt')) + list(ds_root.glob('*/*/predicates.txt')):
            candidates.add(str(p.parent.relative_to(ds_root)))
        for patt in ['*/train.txt', '*/*/train.txt', '*/facts.txt', '*/*/facts.txt']:
            for p in ds_root.glob(patt):
                candidates.add(str(p.parent.relative_to(ds_root)))
        datasets = sorted(candidates) if candidates else []
        if not datasets:
            datasets = ['yago']

    if args.use_stats:
        stats_path = Path(args.stats)
        if not stats_path.exists():
            raise SystemExit(f"Stats file not found: {stats_path}. Run human_evaluation/predicate_stats.py first or disable --use-stats.")
        stats_rows = read_stats(stats_path)
        by_dataset = defaultdict(list)
        mappers: Dict[str, Callable[[str], str]] = {}
        for row in stats_rows:
            try:
                nf = int(row.get('num_facts', '0'))
            except ValueError:
                nf = 0
            if nf >= args.min_facts:
                ds = row['dataset']
                if ds not in mappers:
                    mappers[ds] = build_id_to_name_mapper(ds_root, ds)
                rmapped = dict(row)
                rmapped['predicate'] = mappers[ds](row['predicate'])
                by_dataset[ds].append(rmapped)
    else:
        # Compute stats directly from dataset root and predicates.txt
        by_dataset = defaultdict(list)
        for ds in datasets:
            root = ds_root / ds
            # Load predicates list
            pred_file = root / 'predicates.txt'
            preds = []
            if pred_file.exists():
                preds = [line.strip() for line in pred_file.read_text(encoding='utf-8').splitlines() if line.strip()]
            # Load triples
            triples = None
            for name in ['train.txt', 'facts.txt']:
                p = root / name
                if p.exists():
                    triples = read_triples(p)
                    break
            if triples is None:
                # Search recursively
                for p in list(root.glob('**/train.txt')) + list(root.glob('**/facts.txt')):
                    triples = read_triples(p)
                    break
            stats_map = compute_stats(triples) if triples else {}
            # Compute quartiles for this dataset
            freqs = [v['num_facts'] for v in stats_map.values()] if stats_map else []
            q1, q2, q3 = quartiles(freqs)
            # Fill rows for all predicates (ensure zero-count preds included)
            for pr in preds:
                v = stats_map.get(pr, {'num_facts': 0, 'avg_tph': 0.0, 'avg_hpt': 0.0})
                dt = degree_type(v['avg_tph'], v['avg_hpt'])
                fq = v['num_facts']
                if fq <= q1:
                    fq_q = 'Q1'
                elif fq <= q2:
                    fq_q = 'Q2'
                elif fq <= q3:
                    fq_q = 'Q3'
                else:
                    fq_q = 'Q4'
                by_dataset[ds].append({
                    'dataset': ds,
                    'predicate': pr,
                    'num_facts': str(v['num_facts']),
                    'avg_tph': str(v['avg_tph']),
                    'avg_hpt': str(v['avg_hpt']),
                    'degree_type': dt,
                    'freq_quartile': fq_q,
                })

    # Build quotas
    quotas: Dict[str, int] = {}
    if args.quota:
        for entry in args.quota:
            # Allow comma-separated list in one flag
            for token in entry.split(','):
                token = token.strip()
                if not token:
                    continue
                if ':' not in token:
                    print(f"Warning: invalid --quota entry '{token}', expected 'dataset:n'")
                    continue
                ds_key, num = token.split(':', 1)
                try:
                    quotas[ds_key.strip()] = int(num)
                except ValueError:
                    print(f"Warning: invalid number in --quota '{token}'")
        if not datasets:
            datasets = list(quotas.keys())
    else:
        def quota_for(ds_name: str) -> int:
            name = ds_name.lower()
            if 'wn' in name:
                return args.wn18rr
            if 'fb15k' in name:
                return args.fb15k
            if 'yago' in name:
                return args.yago3_10 if hasattr(args, 'yago3_10') else args.__dict__['yago3-10']
            return 0

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)

    rows = []
    for ds in (datasets if datasets else by_dataset.keys()):
        n = quotas.get(ds) if quotas else None
        if n is None:
            # fallback quotas if none provided explicitly
            name = ds.lower()
            if 'wn' in name:
                n = args.wn18rr
            elif 'fb15k' in name:
                n = args.fb15k
            elif 'yago' in name:
                n = args.yago3_10 if hasattr(args, 'yago3_10') else args.__dict__['yago3-10']
            else:
                n = 0
        if ds not in by_dataset or n <= 0:
            continue
        pool = by_dataset[ds]
        if not pool:
            continue
        sel = sample_buckets(pool, n, args.seed, allow_repeats=args.exact)
        for r in sel:
            rows.append([ds, r['predicate'], r['num_facts'], r['avg_tph'], r['avg_hpt'], r['degree_type'], r['freq_quartile'], args.seed])

    with open(out, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['dataset', 'predicate', 'num_facts', 'avg_tph', 'avg_hpt', 'degree_type', 'freq_quartile', 'seed'])
        w.writerows(rows)
    print(f"Wrote {out} with {len(rows)} predicates")


if __name__ == '__main__':
    main()
