# Annotation Instructions for Knowledge Graph Rule Evaluation

## Overview
You will evaluate logical rules generated for knowledge graph predicates. Each rule follows the format: `head(X,Y) :- body1(X,Z), body2(Z,Y)` and represents a potential logical relationship.

## Task Description
For each predicate, you will receive **exactly 5 rules** to evaluate. Your task is to **rank these 5 rules from 1 to 5**, where:
- **Rank 1** = Most plausible/useful rule
- **Rank 5** = Least plausible/useful rule

## Evaluation Criteria
Please consider three key dimensions when ranking:

1. **Logical Soundness**: Does the rule make logical sense? Are the variable bindings and relationships coherent?

2. **Semantic Plausibility**: Does the rule reflect realistic relationships that could exist in the real world?

3. **Practical Utility**: Would this rule be useful for knowledge graph completion or reasoning tasks?

## Important Notes
- **Blind Evaluation**: You will not know which system generated each rule
- **Within-Predicate Ranking**: Rank only the 5 rules provided for each predicate relative to each other
- **Independent Assessment**: Complete your rankings independently without consulting other evaluators
- **No Ties**: Each rule must receive a unique rank from 1 to 5

## Example Format
**Predicate**: `actedIn`

**Rule**: `actedIn(X,Y) :- isLeaderOf(X,Z), created(Z,Y)`

**Explanation**: A person who is a leader of an organization that created a creative work is likely to have acted in that work, especially if the organization is a production company. Counter-example: The leader of an organization might not necessarily be an actor or have acted in the creative work. Assessment: The rule is logically coherent but may not always hold true in practice, as organizational leaders are not always actors.

**Your Ranking**: [Assign rank 1-5 based on the criteria above]