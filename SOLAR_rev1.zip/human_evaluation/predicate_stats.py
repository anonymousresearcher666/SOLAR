#!/usr/bin/env python3
import argparse
import csv
from collections import defaultdict
from pathlib import Path


def read_triples(path: Path):
    triples = []
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            s = line.strip().split()
            if len(s) != 3:
                continue
            h, r, t = s
            triples.append((h, r, t))
    return triples


def compute_stats(triples):
    # Count facts per predicate
    counts = defaultdict(int)
    heads_per_r = defaultdict(lambda: defaultdict(int))
    tails_per_r = defaultdict(lambda: defaultdict(int))

    for h, r, t in triples:
        counts[r] += 1
        heads_per_r[r][h] += 1
        tails_per_r[r][t] += 1

    stats = {}
    for r in counts:
        num_facts = counts[r]
        # average tails per head (tph)
        tph = num_facts / max(1, len(heads_per_r[r]))
        # average heads per tail (hpt)
        hpt = num_facts / max(1, len(tails_per_r[r]))
        stats[r] = {
            'num_facts': num_facts,
            'avg_tph': round(tph, 4),
            'avg_hpt': round(hpt, 4),
        }
    return stats


def degree_type(avg_tph: float, avg_hpt: float, eps: float = 1.2) -> str:
    # Standard heuristic thresholds
    tph_many = avg_tph > eps
    hpt_many = avg_hpt > eps
    if not tph_many and not hpt_many:
        return '1-1'
    if tph_many and not hpt_many:
        return '1-N'
    if not tph_many and hpt_many:
        return 'N-1'
    return 'N-N'


def quartiles(values):
    if not values:
        return []
    sorted_vals = sorted(values)
    k = len(sorted_vals)
    def qpos(p):
        return sorted_vals[int(p * (k - 1))]
    return [qpos(0.25), qpos(0.5), qpos(0.75)]


def main():
    ap = argparse.ArgumentParser(description='Compute predicate stats (frequency, degree type, quartiles).')
    ap.add_argument('--dataset-root', type=str, default='dataset', help='Dataset root directory (absolute or relative to repo root)')
    ap.add_argument('--datasets', nargs='*', default=None, help='Dataset names (e.g., WN18RR FB15k YAGO3-10). If omitted, auto-detect under dataset root.')
    ap.add_argument('--out', type=str, default='./sampling/predicate_stats.csv')
    args = ap.parse_args()

    # Resolve dataset root relative to repo root if not absolute
    repo_root = Path(__file__).resolve().parents[1]
    ds_root = Path(args.dataset_root)
    if not ds_root.is_absolute():
        ds_root = repo_root / ds_root

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    # Determine dataset list
    datasets = args.datasets
    if not datasets:
        root_dir = ds_root
        candidates = set()
        if root_dir.exists():
            # Prefer directories with predicates.txt (one or two levels deep)
            for p in list(root_dir.glob('*/predicates.txt')) + list(root_dir.glob('*/*/predicates.txt')):
                rel = p.parent.relative_to(root_dir)
                candidates.add(str(rel))
            # Add dirs with train/facts if not already captured
            for patt in ['*/train.txt', '*/*/train.txt', '*/facts.txt', '*/*/facts.txt']:
                for p in root_dir.glob(patt):
                    rel = p.parent.relative_to(root_dir)
                    candidates.add(str(rel))
        datasets = sorted(candidates) if candidates else []
        if not datasets:
            datasets = ['yago']

    rows = []
    for ds in datasets:
        # Allow nested dataset directories (e.g., no_schema/wn-18rr)
        root = ds_root / ds
        # Guess train file; fallback to facts.txt if present; otherwise search recursively
        train = None
        for name in ['train.txt', 'facts.txt']:
            p = root / name
            if p.exists():
                train = p
                break
        if train is None:
            for p in list(root.glob('**/train.txt')) + list(root.glob('**/facts.txt')):
                train = p
                break
        if train is None:
            print(f"Warning: no train/facts file found for '{ds}' under {root}")
            continue
        triples = read_triples(train)
        st = compute_stats(triples)
        # Compute quartiles on num_facts
        freqs = [v['num_facts'] for v in st.values()]
        q1, q2, q3 = quartiles(freqs) if len(freqs) >= 4 else (0, 0, 0)

        for r, v in st.items():
            dt = degree_type(v['avg_tph'], v['avg_hpt'])
            fq = v['num_facts']
            if fq <= q1:
                fq_q = 'Q1'
            elif fq <= q2:
                fq_q = 'Q2'
            elif fq <= q3:
                fq_q = 'Q3'
            else:
                fq_q = 'Q4'
            rows.append([ds, r, v['num_facts'], v['avg_tph'], v['avg_hpt'], dt, fq_q])

    with open(out_path, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['dataset', 'predicate', 'num_facts', 'avg_tph', 'avg_hpt', 'degree_type', 'freq_quartile'])
        w.writerows(rows)
    print(f"Wrote {out_path} with {len(rows)} rows")


if __name__ == '__main__':
    main()
