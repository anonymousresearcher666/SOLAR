#!/usr/bin/env python3
import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Tuple


def read_stats(path: Path) -> List[dict]:
    rows: List[dict] = []
    with open(path, 'r', encoding='utf-8') as f:
        r = csv.DictReader(f)
        for row in r:
            rows.append(row)
    return rows


def compute_U_and_eff(rows: List[dict], min_facts: int) -> Tuple[Dict[str, int], Dict[str, float], Dict[str, int]]:
    """Return per-dataset usable predicate counts U_d, effective counts N_eff_d, and total facts per dataset."""
    # Aggregate per dataset
    facts_by_ds: Dict[str, int] = defaultdict(int)
    facts_per_pred: Dict[str, List[int]] = defaultdict(list)
    usable_counts: Dict[str, int] = defaultdict(int)

    for row in rows:
        ds = row['dataset']
        try:
            nf = int(row.get('num_facts', '0'))
        except ValueError:
            nf = 0
        if nf >= min_facts:
            usable_counts[ds] += 1
            facts_by_ds[ds] += nf
            facts_per_pred[ds].append(nf)

    eff: Dict[str, float] = {}
    for ds, lst in facts_per_pred.items():
        total = facts_by_ds[ds]
        if total <= 0 or not lst:
            eff[ds] = 0.0
            continue
        # Simpson/Herfindahl effective count: 1 / sum p_i^2
        p2_sum = 0.0
        for nf in lst:
            p = nf / total
            p2_sum += p * p
        eff[ds] = (1.0 / p2_sum) if p2_sum > 0 else 0.0

    return usable_counts, eff, facts_by_ds


def normalize(d: Dict[str, float]) -> Dict[str, float]:
    s = sum(d.values())
    if s <= 0:
        return {k: 0.0 for k in d}
    return {k: v / s for k, v in d.items()}


def compute_quotas(
    U: Dict[str, int],
    eff: Dict[str, float],
    total: int,
    lam: float,
) -> Tuple[Dict[str, int], Dict[str, float], Dict[str, float], Dict[str, float]]:
    # Normalize components
    u_hat = normalize({k: float(U.get(k, 0)) for k in U.keys()})
    # Ensure eff has entries for all U keys
    eff_full = {k: eff.get(k, 0.0) for k in U.keys()}
    n_hat = normalize(eff_full)

    # Blend weights
    w = {k: lam * u_hat.get(k, 0.0) + (1.0 - lam) * n_hat.get(k, 0.0) for k in U.keys()}

    # Hamilton apportionment with caps at U_d
    raw = {k: total * w[k] for k in U.keys()}
    floor_q = {k: min(U[k], int(math.floor(raw[k]))) for k in U.keys()}
    sum_floor = sum(floor_q.values())
    rema = {k: (raw[k] - math.floor(raw[k])) if floor_q[k] < U[k] else 0.0 for k in U.keys()}

    q = dict(floor_q)
    # Add remaining seats by largest remainder
    need = total - sum_floor
    if need > 0:
        for k, _ in sorted(rema.items(), key=lambda kv: kv[1], reverse=True):
            if need <= 0:
                break
            if q[k] < U[k]:
                q[k] += 1
                need -= 1
    # If still need due to caps, try another pass (assign to any with capacity)
    if need > 0:
        for k in sorted(U.keys(), key=lambda kk: w[kk], reverse=True):
            if need <= 0:
                break
            if q[k] < U[k]:
                q[k] += 1
                need -= 1
    return q, u_hat, n_hat, w


def main():
    ap = argparse.ArgumentParser(description='Compute dataset quotas from predicate stats.')
    ap.add_argument('--stats', type=str, default='./sampling/predicate_stats.csv', help='Path to predicate_stats.csv')
    ap.add_argument('--min-facts', type=int, default=1, help='Minimum facts per predicate to count as usable')
    ap.add_argument('--lambda', dest='lam', type=float, default=0.6, help='Blend factor λ in w = λ·û + (1−λ)·n̂')
    ap.add_argument('--total', type=int, default=62, help='Total number of predicates to allocate')
    ap.add_argument('--fit-target', action='append', default=None,
                    help="Reverse-engineer λ to match a target split. Format 'dataset:q' (repeatable or comma-separated).")
    ap.add_argument('--out', type=str, default='', help='Optional CSV to write quotas and components')
    args = ap.parse_args()

    stats_path = Path(args.stats)
    if not stats_path.exists():
        raise SystemExit(f"Stats file not found: {stats_path}")

    rows = read_stats(stats_path)
    U, eff, facts_by_ds = compute_U_and_eff(rows, args.min_facts)
    # Default lambda
    lam = args.lam

    # Optionally fit lambda to match a target split (reverse engineering)
    if args.fit_target:
        target_q: Dict[str, int] = {}
        for entry in args.fit_target:
            for token in entry.split(','):
                token = token.strip()
                if not token:
                    continue
                if ':' not in token:
                    raise SystemExit(f"Invalid --fit-target entry '{token}', expected 'dataset:q'")
                ds, qs = token.split(':', 1)
                try:
                    target_q[ds] = int(qs)
                except ValueError:
                    raise SystemExit(f"Invalid quota number in --fit-target '{token}'")

        # Restrict to overlap between stats datasets and targets
        S = [ds for ds in target_q.keys() if ds in U]
        if not S:
            raise SystemExit("No overlapping datasets between --fit-target and stats")

        target_total = sum(target_q[ds] for ds in S)
        t_hat = {ds: target_q[ds] / target_total for ds in S}

        # Build normalized u_hat and n_hat over S
        u_sub = {ds: float(U.get(ds, 0)) for ds in S}
        eff_sub = {ds: eff.get(ds, 0.0) for ds in S}

        def norm_sub(dsub: Dict[str, float]) -> Dict[str, float]:
            s = sum(dsub.values())
            return {k: (dsub[k] / s if s > 0 else 0.0) for k in dsub}

        u_hat_sub = norm_sub(u_sub)
        n_hat_sub = norm_sub(eff_sub)

        # Fit lambda* = ((t_hat - n̂)·(û - n̂)) / ||û - n̂||², clipped to [0,1]
        num = 0.0
        den = 0.0
        for ds in S:
            du = u_hat_sub[ds] - n_hat_sub[ds]
            num += (t_hat[ds] - n_hat_sub[ds]) * du
            den += du * du
        lam = 0.0 if den <= 0 else max(0.0, min(1.0, num / den))

    q, u_hat, n_hat, w = compute_quotas(U, eff, args.total, lam)

    # Print summary
    header = [
        'dataset', 'U_usable', 'facts_total', 'N_eff', 'u_hat', 'n_hat', 'weight', 'quota'
    ]
    print('\t'.join(header))
    for ds in sorted(U.keys(), key=lambda k: q.get(k, 0), reverse=True):
        print('\t'.join([
            ds,
            str(U[ds]),
            str(facts_by_ds.get(ds, 0)),
            f"{eff.get(ds, 0.0):.3f}",
            f"{u_hat.get(ds, 0.0):.3f}",
            f"{n_hat.get(ds, 0.0):.3f}",
            f"{w.get(ds, 0.0):.3f}",
            str(q.get(ds, 0)),
        ]))
    print(f"Total allocated: {sum(q.values())} / {args.total}")
    print(f"Lambda used: {lam:.4f}")

    if args.out:
        outp = Path(args.out)
        outp.parent.mkdir(parents=True, exist_ok=True)
        with open(outp, 'w', newline='', encoding='utf-8') as f:
            wcsv = csv.writer(f)
            wcsv.writerow(header)
            for ds in sorted(U.keys(), key=lambda k: q.get(k, 0), reverse=True):
                wcsv.writerow([
                    ds,
                    U[ds],
                    facts_by_ds.get(ds, 0),
                    f"{eff.get(ds, 0.0):.6f}",
                    f"{u_hat.get(ds, 0.0):.6f}",
                    f"{n_hat.get(ds, 0.0):.6f}",
                    f"{w.get(ds, 0.0):.6f}",
                    q.get(ds, 0),
                ])
        print(f"Wrote quota summary to {outp}")


if __name__ == '__main__':
    main()
