import argparse
import os
import json
from datetime import datetime
import time
from functools import partial
from multiprocessing.pool import ThreadPool
from tqdm import tqdm
from data import *
from extract_subschema import extract_subschema
from llm import call_models
from llm.consensus_llms import simulate_consensus_discussion
try:
    from rag import retrieve as rag_retrieve
except Exception:
    rag_retrieve = None


def assign_variables_to_prompt(head, predicates, k, m, schema, prompt_with_variables, examples_text: str = ""):
    final_prompt = ""
    # Convert template to f-string format
    final_prompt = prompt_with_variables.replace("{{head}}", str(head)) \
        .replace("{{k}}", str(k)) \
        .replace("{{schema}}", str(schema)) \
        .replace("{{number}}", str(m)) \
        .replace("{{examples}}", str(examples_text)) \
        # .replace("{{number}}", str(m))

    # Substitute the variables using an f-string
    final_prompt = final_prompt.format(
        head=head,
        k=k,
        schema=schema,
        predicates=predicates,
        examples=examples_text
    )

    return final_prompt


def _format_rule_from_path(head_pred: str, path: str) -> str:
    # Build a chain head(X,Y) :- r1(X,V1), r2(V1,V2), ..., rn(V{n-1},Y)
    parts = [p.strip() for p in str(path).split('|') if p.strip()]
    if not parts:
        return ""
    atoms = []
    prev = 'X'
    for i, rel in enumerate(parts):
        base = rel
        inv = False
        if rel.startswith('inv_'):
            base = rel[len('inv_'):]
            inv = True
        nxt = 'Y' if i == len(parts) - 1 else f"V{i+1}"
        if inv:
            atoms.append(f"{base}({nxt},{prev})")
        else:
            atoms.append(f"{base}({prev},{nxt})")
        prev = nxt
    return f"{head_pred}(X,Y) :- {', '.join(atoms)}"


def build_fs_examples_block(repo_root: str, dataset: str, head_pred: str, max_examples: int) -> str:
    """Read sampled_path/<dataset>/closed_rel_paths.jsonl and build an Examples block for the head predicate.

    Returns a string with numbered example rules, or empty string if unavailable.
    """
    import json as _json
    from pathlib import Path as _P
    try:
        p = _P(repo_root) / 'sampled_path' / dataset / 'closed_rel_paths.jsonl'
        if not p.exists():
            return ""
        lines = p.read_text(encoding='utf-8', errors='ignore').splitlines()
        for ln in lines:
            ln = ln.strip()
            if not ln:
                continue
            try:
                obj = _json.loads(ln)
            except Exception:
                continue
            if str(obj.get('head', '')) != str(head_pred):
                continue
            paths = obj.get('paths', []) or []
            if not paths:
                return ""
            ex_rules = []
            for path in paths[:max(0, int(max_examples))]:
                r = _format_rule_from_path(head_pred, path)
                if r:
                    ex_rules.append(r)
            if not ex_rules:
                return ""
            # Build Examples section
            lines_out = ["Examples (structural patterns; YOU must type variables in outputs):"]
            for i, r in enumerate(ex_rules, 1):
                lines_out.append(f"{i}) {r}")
            return "\n".join(lines_out)
        return ""
    except Exception:
        return ""


def build_rag_context(args, head_predicate: str, schema_text: str) -> str:
    """Optionally retrieve RAG context for a domain and return a formatted string."""
    if not getattr(args, 'rag_domain', '') or rag_retrieve is None:
        return ''
    # Compose a simple query from head predicate and schema neighborhood
    q = f"Target predicate: {head_predicate}\nSchema snippet:\n{schema_text[:2000]}"
    # Determine dataset-scoped RAG store: <dataset[/language]>/rag_data
    # Fall back to args.rag_store if explicitly set to a non-default value
    default_store = 'rag_store'
    configured_store = getattr(args, 'rag_store', default_store)
    # Compute dataset path (same logic as used in main())
    data_root = os.path.join(args.data_path, args.dataset)
    if getattr(args, 'language', ''):
        data_root = os.path.join(data_root, args.language)
    dataset_scoped_store = os.path.join(data_root, 'rag_data')
    store_root = dataset_scoped_store if configured_store == default_store else configured_store

    try:
        hits = rag_retrieve(
            args.rag_domain,
            q,
            top_k=getattr(args, 'rag_top_k', 3),
            model_name=getattr(args, 'rag_model', 'all-MiniLM-L6-v2'),
            store_root=store_root,
        )
    except Exception:
        return ''
    if not hits:
        return ''
    # Filtering and truncation controls
    min_score = float(getattr(args, 'rag_min_score', 0.0))
    max_total = int(getattr(args, 'rag_max_total_chars', 2000))
    max_doc = int(getattr(args, 'rag_max_doc_chars', 800))

    used = 0
    parts = ["RAG Context (top documents):"]
    for i, h in enumerate(hits, 1):
        score = float(h.get('score', 0.0))
        if score < min_score:
            continue
        doc = h.get('doc', '')
        txt = str(h.get('text', ''))[:max_doc]
        block = f"[{i}] {doc}:\n{txt}"
        if used + len(block) > max_total:
            # stop before exceeding total budget
            break
        parts.append(block)
        used += len(block)
    return ("\n\n".join(parts) + "\n") if len(parts) > 1 else ''


def standardize_rules_text(initial_response_text: str) -> str:
    """
    Build a standardized rule set R from the generator output.
    Heuristic: keep unique lines that look like Horn rules (contain ':-' and parentheses),
    trim whitespace, preserve first-seen order. Fallback to raw text if none match.
    """
    seen = set()
    ordered = []
    for line in str(initial_response_text).splitlines():
        ln = line.strip()
        if ':-' in ln and '(' in ln and ')' in ln:
            if ln not in seen:
                seen.add(ln)
                ordered.append(ln)
    return "\n".join(ordered) if ordered else str(initial_response_text)


def create_directory_with_progressive_number(base_path, dir_name):
    # Initialize the counter
    counter = 1
    new_dir_name = dir_name
    # Check if the directory already exists and increment the counter if it does
    while os.path.exists(os.path.join(base_path, new_dir_name)):
        new_dir_name = f"{dir_name}_{counter}"
        counter += 1
    # Create the new directory
    new_dir_path = os.path.join(base_path, new_dir_name)
    os.makedirs(new_dir_path)
    return new_dir_path

def generate_rule_consensus(input_predicate, schema_predicates, schema, rule_path, args, prompt_with_variables,
                            coordinator_llm, prompt_path, agent_llms):
    start_ts = time.time()
    start_utc = datetime.utcnow().isoformat() + "Z"
    status = "ok"
    rule_head = input_predicate

    # Extract a head-centered subschema (return in the same format as that in input)
    _, schema = extract_subschema(schema=schema, input_predicate=rule_head, max_length=args.numbodyatoms)

    # Build prompt; include few-shot examples if fs prompt
    examples_block = ""
    if args.prompt_type == 'fs':
        repo_root = os.path.abspath(os.path.join(args.data_path, os.pardir))
        examples_block = build_fs_examples_block(repo_root, args.dataset, rule_head, getattr(args, 'numex', 0))
    current_prompt = assign_variables_to_prompt(
        rule_head, schema_predicates, args.numbodyatoms, args.m, schema, prompt_with_variables, examples_text=examples_block)
    # Append optional RAG context
    rag_ctx = build_rag_context(args, rule_head, schema)
    if rag_ctx:
        current_prompt = f"{current_prompt}\n\n{rag_ctx}"

    if args.is_zero:  # For zero-shot setting
        file_suffix = f"_zero_shot_{args.spca_mode}"
        with open(os.path.join(rule_path, f"{rule_head}{file_suffix}.query"), "w") as f:
            f.write(current_prompt + "\n")
            f.close()

        if not args.dry_run:
            # First generate initial rules with coordinator
            initial_response = call_models.query_remote_llm(current_prompt, llm=coordinator_llm)

            # Persist coordinator artifacts under Coordinator_<model>
            safe_coord = str(args.coordinator_model).replace('/', '-').replace(':', '-')
            coord_dir = os.path.join(rule_path, f"Coordinator_{safe_coord}")
            os.makedirs(coord_dir, exist_ok=True)
            safe_name = rule_head.replace("/", "-")
            with open(os.path.join(coord_dir, f"{safe_name}_prompt.query"), "w") as qp:
                qp.write(current_prompt + "\n")
            with open(os.path.join(coord_dir, f"{safe_name}_initial.txt"), "w") as qi:
                qi.write(str(initial_response))
            with open(os.path.join(coord_dir, f"{safe_name}_schema.txt"), "w") as qs:
                qs.write(schema)
            # Standardize candidate rules for downstream tools
            std_rules = standardize_rules_text(str(initial_response))
            with open(os.path.join(coord_dir, f"{safe_name}_candidates.rules"), "w") as fr:
                fr.write(std_rules)

            # Choose evaluation method based on SPCA mode
            if args.spca_mode == "consensus":
                # SPCA^{cons}: Multi-agent consensus discussion
                evaluation_response = simulate_consensus_discussion(
                    coordinator_llm=coordinator_llm,
                    agents=agent_llms,
                    rules=str(initial_response),
                    schema=schema,
                    rounds=args.consensus_rounds,
                    prompt_path=prompt_path,
                    predicate_id=rule_head,
                    base_prompt_name=args.prompt_type,
                    base_prompt_text=prompt,
                    out_root=rule_path,
                    coordinator_model_name=args.coordinator_model
                )
                evaluation_header = "=== CONSENSUS DISCUSSION ==="

            elif args.spca_mode == "pool":
                # This function is consensus-specific; pool generation handled in generate_rule_pool.
                # Keep behavior consistent if accidentally called with pool.
                coord_dir = os.path.join(rule_path, f"Coordinator_{args.coordinator_model}")
                os.makedirs(coord_dir, exist_ok=True)
                safe_name = rule_head.replace("/", "-")
                with open(os.path.join(coord_dir, f"{safe_name}_pool.txt"), "w") as fc:
                    fc.write(str(initial_response))
                std_rules = standardize_rules_text(str(initial_response))
                with open(os.path.join(coord_dir, f"{safe_name}_candidates.rules"), "w") as fr:
                    fr.write(std_rules)
                with open(os.path.join(coord_dir, f"{safe_name}_schema.txt"), "w") as fs:
                    fs.write(schema)
                evaluation_response = ""
                evaluation_header = "=== INDEPENDENT RANKINGS (DEFERRED) ==="

            else:
                raise ValueError(f"Unknown SPCA mode: {args.spca_mode}")

            with open(os.path.join(rule_path, f"{rule_head}{file_suffix}.txt"), "w") as f:
                f.write("=== INITIAL RESPONSE ===\n")
                f.write(str(initial_response) + "\n\n")
                f.write(f"{evaluation_header}\n")
                f.write(evaluation_response + "\n")
                f.close()

    else:
        file_name = rule_head.replace("/", "-")
        file_suffix = f"_{args.spca_mode}"

        with open(os.path.join(rule_path, f"{file_name}{file_suffix}.txt"), "w") as rule_file, open(
                os.path.join(rule_path, f"{file_name}{file_suffix}.query"), "w"
        ) as query_file:
            rule_file.write(f"Rule_head: {rule_head}\n")
            prompt = current_prompt

            query_file.write(prompt + "\n")

            if not args.dry_run:
                # First generate initial rules with coordinator
                initial_response = call_models.query_remote_llm(current_prompt, llm=coordinator_llm)

                # Persist coordinator artifacts under Coordinator_<model>
                safe_coord = str(args.coordinator_model).replace('/', '-').replace(':', '-')
                coord_dir = os.path.join(rule_path, f"Coordinator_{safe_coord}")
                os.makedirs(coord_dir, exist_ok=True)
                with open(os.path.join(coord_dir, f"{file_name}_prompt.query"), "w") as qp:
                    qp.write(current_prompt + "\n")
                with open(os.path.join(coord_dir, f"{file_name}_initial.txt"), "w") as qi:
                    qi.write(str(initial_response))
                with open(os.path.join(coord_dir, f"{file_name}_schema.txt"), "w") as qs:
                    qs.write(schema)
                # Standardize candidate rules for downstream tools
                std_rules = standardize_rules_text(str(initial_response))
                with open(os.path.join(coord_dir, f"{file_name}_candidates.rules"), "w") as fr:
                    fr.write(std_rules)

                # Choose evaluation method based on SPCA mode
                if args.spca_mode == "consensus":
                    # SPCA^{cons}: Multi-agent consensus discussion
                    evaluation_response = simulate_consensus_discussion(
                        coordinator_llm=coordinator_llm,
                        agents=agent_llms,
                        rules=str(initial_response),
                        schema=schema,
                        rounds=args.consensus_rounds,
                        prompt_path=prompt_path,
                        predicate_id=rule_head,
                        base_prompt_name=args.prompt_type,
                        base_prompt_text=prompt,
                        out_root=rule_path,
                        coordinator_model_name=args.coordinator_model
                    )
                    evaluation_header = "=== CONSENSUS DISCUSSION ==="

                elif args.spca_mode == "pool":
                    # This function is consensus-specific; pool generation handled in generate_rule_pool.
                    coord_dir = os.path.join(rule_path, f"Coordinator_{args.coordinator_model}")
                    os.makedirs(coord_dir, exist_ok=True)
                    with open(os.path.join(coord_dir, f"{file_name}_pool.txt"), "w") as fc:
                        fc.write(str(initial_response))
                    std_rules = standardize_rules_text(str(initial_response))
                    with open(os.path.join(coord_dir, f"{file_name}_candidates.rules"), "w") as fr:
                        fr.write(std_rules)
                    with open(os.path.join(coord_dir, f"{file_name}_schema.txt"), "w") as fs:
                        fs.write(schema)
                    evaluation_response = ""
                    evaluation_header = "=== INDEPENDENT RANKINGS (DEFERRED) ==="

                else:
                    raise ValueError(f"Unknown SPCA mode: {args.spca_mode}")

                # Persist initial + evaluation outputs for this predicate
                rule_file.write("=== INITIAL RESPONSE ===\n")
                rule_file.write(str(initial_response) + "\n\n")
                rule_file.write(f"{evaluation_header}\n")
                rule_file.write(evaluation_response + "\n")
    try:
        elapsed = time.time() - start_ts
        timings_dir = os.path.join(rule_path, "timings")
        os.makedirs(timings_dir, exist_ok=True)
        safe_pred = rule_head.replace("/", "-")
        timing = {
            "predicate": rule_head,
            "spca_mode": args.spca_mode,
            "start_utc": start_utc,
            "end_utc": datetime.utcnow().isoformat() + "Z",
            "elapsed_sec": elapsed,
            "coordinator_model": args.coordinator_model,
            "agent_models": args.agent_models if isinstance(args.agent_models, list) else [args.agent_models],
            "consensus_rounds": getattr(args, 'consensus_rounds', None),
            "status": status,
        }
        with open(os.path.join(timings_dir, f"{safe_pred}.json"), "w", encoding="utf-8") as tf:
            json.dump(timing, tf, ensure_ascii=False, indent=2)
    except Exception:
        pass

def generate_rule_pool(input_predicate, schema_predicates, schema, rule_path, args, prompt_with_variables,
                       coordinator_llm, prompt_path):
    """Phase 1 for SPCA^{pool}: a single LLM (the coordinator) generates candidate rules.

    We save standardized candidates and schema under:
      <rule_path>/Coordinator_<coordinator_model>/
        - <predicate>_candidates.rules
        - <predicate>_schema.txt
        - <predicate>_pool.txt (raw)
    and write the prompt/outputs to predicate-level files for traceability.
    """
    start_ts = time.time()
    start_utc = datetime.utcnow().isoformat() + "Z"
    status = "ok"
    rule_head = input_predicate

    # Extract a head-centered subschema of bounded length
    _, schema = extract_subschema(schema=schema, input_predicate=rule_head, max_length=args.numbodyatoms)

    # Build prompt (no prior rules in pool stage); include few-shot examples if fs prompt
    examples_block = ""
    if args.prompt_type == 'fs':
        repo_root = os.path.abspath(os.path.join(args.data_path, os.pardir))
        examples_block = build_fs_examples_block(repo_root, args.dataset, rule_head, getattr(args, 'numex', 0))
    current_prompt = assign_variables_to_prompt(
        rule_head, schema_predicates, args.numbodyatoms, args.m, schema, prompt_with_variables, examples_text=examples_block)
    rag_ctx = build_rag_context(args, rule_head, schema)
    if rag_ctx:
        current_prompt = f"{current_prompt}\n\n{rag_ctx}"

    file_name = rule_head.replace("/", "-")
    file_suffix = "_pool"

    # Persist the prompt
    with open(os.path.join(rule_path, f"{file_name}{file_suffix}.query"), "w") as f:
        f.write(current_prompt + "\n")

    if args.dry_run:
        initial_response = "[DRY RUN]"
    else:
        initial_response = call_models.query_remote_llm(current_prompt, llm=coordinator_llm)

    # Save raw and standardized candidates under Coordinator_<model>
    coord_dir = os.path.join(rule_path, f"Coordinator_{args.coordinator_model}")
    os.makedirs(coord_dir, exist_ok=True)
    with open(os.path.join(coord_dir, f"{file_name}_pool.txt"), "w") as fc:
        fc.write(str(initial_response))
    std_rules = standardize_rules_text(str(initial_response))
    with open(os.path.join(coord_dir, f"{file_name}_candidates.rules"), "w") as fr:
        fr.write(std_rules)
    with open(os.path.join(coord_dir, f"{file_name}_schema.txt"), "w") as fs:
        fs.write(schema)

    # Persist a summary file at predicate level
    with open(os.path.join(rule_path, f"{file_name}{file_suffix}.txt"), "w") as f:
        f.write("=== INITIAL RESPONSE (POOL PHASE 1) ===\n")
        f.write(str(initial_response) + "\n")
        f.write("=== RANKINGS WILL BE PRODUCED IN PHASE 2 ===\n")
    try:
        elapsed = time.time() - start_ts
        timings_dir = os.path.join(rule_path, "timings")
        os.makedirs(timings_dir, exist_ok=True)
        timing = {
            "predicate": rule_head,
            "spca_mode": args.spca_mode,
            "start_utc": start_utc,
            "end_utc": datetime.utcnow().isoformat() + "Z",
            "elapsed_sec": elapsed,
            "coordinator_model": args.coordinator_model,
            "status": status,
        }
        with open(os.path.join(timings_dir, f"{file_name}.json"), "w", encoding="utf-8") as tf:
            json.dump(timing, tf, ensure_ascii=False, indent=2)
    except Exception:
        pass


def main(args):
    # Prompts now live under <repo_root>/prompt/
    repo_root = os.path.abspath(os.path.join(args.data_path, os.pardir))
    prompt_path = os.path.join(repo_root, "prompt") + "/"
    dataset_root = os.path.join(args.data_path, args.dataset) + "/"
    data_path = os.path.join(dataset_root, args.language) + "/" if getattr(args, 'language', '') else dataset_root

    dataset = Dataset(data_root=data_path, prompt_path=prompt_path, dataset_name=args.dataset)
    schema = dataset.read_schema(args.schema_type)
    schema_predicates = dataset.read_predicates()
    prompt_with_variables = dataset.read_prompt(args.prompt_type)

    # Save paths
    out_prefix = "consensus_" if args.spca_mode == "consensus" else "pool_"
    # Sanitize coordinator model for filesystem safety (e.g., replace ':' or '/')
    safe_coordinator = str(args.coordinator_model).replace('/', '-').replace(':', '-')
    # Final directory name, optionally prefixed with 'rag_' when RAG is enabled
    last_segment = f"{args.prefix}{out_prefix}{safe_coordinator}"
    if getattr(args, 'rag_domain', ''):
        last_segment = f"rag_" + last_segment
    rule_path = os.path.join(
        args.rule_path,
        args.dataset + "/" + f"{args.prompt_type}" + "/" + f"{args.schema_type}" + "/" + f"{args.numbodyatoms}",
        last_segment,
    )
    # Ensure unique output directory by incrementing suffix if exists
    base_dir = os.path.dirname(rule_path)
    dir_name = os.path.basename(rule_path)
    rule_path = create_directory_with_progressive_number(base_dir, dir_name)

    # Persist experiment configuration in the run directory
    try:
        cfg = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "spca_mode": args.spca_mode,
            "dataset": args.dataset,
            "language": getattr(args, 'language', ''),
            "prompt_type": args.prompt_type,
            "schema_type": args.schema_type,
            "numbodyatoms": args.numbodyatoms,
            "m": args.m,
            "num_threads": args.n,
            "samples_per_predicate": args.l,
            "coordinator_model": args.coordinator_model,
            "agent_models": args.agent_models if isinstance(args.agent_models, list) else [args.agent_models],
            "consensus_rounds": getattr(args, 'consensus_rounds', None),
            "dry_run": bool(getattr(args, 'dry_run', False)),
            "prefix": getattr(args, 'prefix', ''),
            "paths": {
                "data_path": args.data_path,
                "dataset_root": dataset_root,
                "prompt_dir": prompt_path,
                "output_dir": rule_path,
                "rule_path_root": args.rule_path,
            },
            "rag": {
                "domain": getattr(args, 'rag_domain', ''),
                "top_k": getattr(args, 'rag_top_k', None),
                "model": getattr(args, 'rag_model', ''),
                "store": getattr(args, 'rag_store', ''),
                "min_score": getattr(args, 'rag_min_score', None),
                "max_total_chars": getattr(args, 'rag_max_total_chars', None),
                "max_doc_chars": getattr(args, 'rag_max_doc_chars', None),
            },
        }
        with open(os.path.join(rule_path, "experiment_config.json"), "w", encoding="utf-8") as cf:
            json.dump(cfg, cf, ensure_ascii=False, indent=2)
    except Exception:
        # Non-fatal: continue if config cannot be written
        pass

    # Create LLMs
    coordinator_llm = call_models.create_llm(args.coordinator_model)
    agent_llms = None
    if args.spca_mode == "consensus":
        agent_llms = call_models.create_agent_llms(args.agent_models)

    print(f"Coordinator: {args.coordinator_model}")
    if args.spca_mode == "consensus":
        print(f"Agents: {args.agent_models}")

    if args.spca_mode == "consensus":
        print(f"Consensus rounds: {args.consensus_rounds}")

    # Generate rules based on selected SPCA mode
    if args.spca_mode == "consensus":
        generator_fn = partial(
            generate_rule_consensus,
            schema_predicates=schema_predicates,
            rule_path=rule_path,
            args=args,
            schema=schema,
            prompt_with_variables=prompt_with_variables,
            coordinator_llm=coordinator_llm,
            prompt_path=prompt_path,
            agent_llms=agent_llms,
        )
    elif args.spca_mode == "pool":
        generator_fn = partial(
            generate_rule_pool,
            schema_predicates=schema_predicates,
            rule_path=rule_path,
            args=args,
            schema=schema,
            prompt_with_variables=prompt_with_variables,
            coordinator_llm=coordinator_llm,
            prompt_path=prompt_path,
        )
        print("SPCA^{pool}: Phase 1 generation with single coordinator model.")
        print("After generation, run Phase 2 ranking, e.g.:\n"
              f"  python -m quality_llm.pool.pool_llm_quality_full {rule_path} \\\n+               --dataset-root {os.path.join(args.data_path)} \\\n+               --agent-models {' '.join(args.agent_models)} \\\n+               --out aggregated_pool.csv")
    else:
        raise ValueError(f"Unknown spca_mode: {args.spca_mode}")
    with ThreadPool(args.n) as p:
        for _ in tqdm(
            p.imap_unordered(generator_fn, schema_predicates),
            total=len(schema_predicates),
        ):
            pass

    # Aggregate predicate timings into a single JSON for convenience
    try:
        timings_dir = os.path.join(rule_path, "timings")
        if os.path.isdir(timings_dir):
            summary = {}
            for name in os.listdir(timings_dir):
                if not name.endswith('.json'):
                    continue
                try:
                    with open(os.path.join(timings_dir, name), 'r', encoding='utf-8') as f:
                        info = json.load(f)
                    pred = info.get('predicate') or name[:-5]
                    summary[pred] = info
                except Exception:
                    continue
            with open(os.path.join(rule_path, 'predicate_timings.json'), 'w', encoding='utf-8') as out:
                json.dump(summary, out, ensure_ascii=False, indent=2)
    except Exception:
        pass


if __name__ == "__main__":
    import os

    base_path = "/Volumes/DATI/"
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--data_path", type=str, default=base_path + "GitHub/SOLAR/dataset", help="data directory"
    )
    parser.add_argument(
        "--prompt_type", type=str, default="fs",
        help="Type of prompt (base,zs,fs,cot,c2r,c2rcl,c2r_counter,c2r_confidence)"
    )

    parser.add_argument(
        "--schema_type", type=str, default="line", help="Type of schema graph (domain_range,graph,line)"
    )

    parser.add_argument("--dataset", type=str, default="family",
                        help="dataset")  # family,dbpedia, yago3, fb15k187, airgraph,yago26K906, schemadotorg
    parser.add_argument(
        "--language", type=str, default="",
        help="Optional language subfolder under dataset (e.g., family/spanish). Default: dataset root."
    )

    parser.add_argument(
        "--rule_path", type=str, default=base_path + "GitHub/SOLAR/gen_rules", help="path to rule file"
    )


    parser.add_argument(
        "--spca_mode", type=str, default="consensus", help="SPCA ranking strategy" #consensus or pool
    )
    # Optional RAG configuration
    parser.add_argument("--rag_domain", type=str, default="", help="RAG domain name (if set, retrieve context)")
    parser.add_argument("--rag_top_k", type=int, default=3, help="RAG: number of docs")
    parser.add_argument("--rag_model", type=str, default="all-MiniLM-L6-v2", help="RAG embedding model")
    parser.add_argument("--rag_store", type=str, default="rag_store", help="RAG store root directory")
    parser.add_argument("--rag_min_score", type=float, default=0.0, help="RAG: minimum similarity score filter")
    parser.add_argument("--rag_max_total_chars", type=int, default=2000, help="RAG: max total characters appended")
    parser.add_argument("--rag_max_doc_chars", type=int, default=800, help="RAG: max characters per document")

    #ollama_gpt-oss:20b ollama_qwen3:30b-a3b ollama_gemma3:27b ollama_qwen2.5:72b ollama_deepseek-r1:70b ollama_qwen2.5:latest ollama_deepseek-r1:1.5b ollama_codellama:7b-code ollama_llama3.2:latest ollama_llama3:latest
    # Consensus-specific arguments
    parser.add_argument("--coordinator_model", type=str, default="ollama_gpt-oss:20b",
                        help="Model to use as coordinator") #gpt-oss:20b


    parser.add_argument("--agent_models", type=str, nargs='+',
                        default=["ollama_deepseek-r1:1.5b", "ollama_gemma3:27b", "ollama_llama3:latest"],
                        help="Models to use as debate agents")
    parser.add_argument("--consensus_rounds", type=int, default=3,
                        help="Number of consensus debate rounds")

    parser.add_argument(
        "--is_zero",
        action="store_true",
        help="Enable this for zero-shot rule generation",
    )
    parser.add_argument(
        "-m",
        type=int,
        default=10,
        help="Number of generated rules, 0 denotes as much as possible",
    )

    parser.add_argument(
        "-numbodyatoms",
        type=int,
        default=2,
        help="Number of atoms in the body",
    )

    parser.add_argument(
        "-numex",
        type=int,
        default=10,
        help="Number of examples",
    )

    parser.add_argument("-n", type=int, default=1, help="multi thread number")
    parser.add_argument(
        "-l", type=int, default=3, help="sample l times for generating k rules"
    )

    parser.add_argument("--prefix", type=str, default="", help="prefix")
    parser.add_argument("--dry_run", action="store_true", help="dry run")
    args, _ = parser.parse_known_args()
    args = parser.parse_args()

    main(args)
