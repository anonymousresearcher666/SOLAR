#!/usr/bin/env python3
"""Concrete RAG use case for SOLAR with dataset-scoped storage.

You pass a dataset name (and optional language). The script checks for a
persistent LlamaIndex under:

  dataset/<dataset>[/<language>]/rag_data/<domain>/llama_index/

If missing, it tries to build it from documents under a generic folder:

  dataset/<dataset>[/<language>]/rag_data/docs/

Then it demonstrates a query and how to attach retrieved context to a
SOLAR prompt stub.
"""

import os
from pathlib import Path
from typing import List
import subprocess
import sys

try:
    from rag import build_index, retrieve
except Exception:
    # Fallback when executed in a way that doesn't include repo root on sys.path
    import sys
    repo_root = Path(__file__).resolve().parents[1]
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))
    from rag import build_index, retrieve  # type: ignore
import argparse


def ensure_index(store_root: Path, domain: str, docs_dir: Path) -> Path:
    persist_dir = store_root / domain / "llama_index"
    if persist_dir.exists():
        print(f"Index already present at {persist_dir}")
        return persist_dir.parent
    print(f"Building index for domain '{domain}' from {docs_dir} ...")
    p = build_index(domain, str(docs_dir), backend="llama", store_root=str(store_root))
    print(f"Built index at {p}")
    return p


def demo_query(store_root: Path, domain: str, query: str, top_k: int = 3) -> List[str]:
    print(f"\nQuery: {query}")
    hits = retrieve(domain, query, top_k=top_k, store_root=str(store_root))
    out = []
    for i, h in enumerate(hits, 1):
        print(f"[{i}] score={h['score']:.4f} doc={h['doc']}")
        print(h['text'][:500])
        print("---")
        out.append(h['text'])
    return out


def demo_solar_prompt(head: str, schema_snippet: str, rag_texts: List[str]) -> str:
    base = (
        f"Target predicate: {head}\n"
        f"Schema (snippet):\n{schema_snippet}\n\n"
        "Using the schema above, propose plausible Horn rules for the target predicate."
    )
    if rag_texts:
        rag_block = "\n\nRAG Context (top documents):\n" + "\n\n".join(rag_texts)
    else:
        rag_block = ""
    return base + rag_block


def main():
    ap = argparse.ArgumentParser(description="Build/query dataset-scoped RAG index for SOLAR")
    ap.add_argument("--dataset", default="family", help="Dataset name (e.g., family). Default: family")
    ap.add_argument("--language", default="", help="Optional language subfolder (e.g., spanish)")
    ap.add_argument("--domain", default="", help="Optional domain name; default: <dataset>[_<language>]")
    ap.add_argument("--top_k", type=int, default=3, help="Top-k results to show")
    # Optional: run SOLAR generation immediately after building/indexing
    ap.add_argument("--run-solar", action="store_true", default=True,help="Run SOLAR generation after RAG is ready")
    ap.add_argument("--spca_mode", choices=["consensus","pool"], default="pool", help="SOLAR mode")
    ap.add_argument("--schema_type", default="line", help="Schema type for SOLAR (line/graph/domain_range)")
    ap.add_argument("--prompt_type", default="c2r_new", help="Prompt type for SOLAR")
    ap.add_argument("--coordinator_model", default="ollama_qwen2.5:latest", help="Coordinator model for SOLAR")
    args = ap.parse_args()

    # Compute repo root and dataset-scoped rag_data root (independent of CWD)
    repo_root = Path(__file__).resolve().parents[1]
    ds_path = repo_root / "dataset" / args.dataset
    if args.language:
        ds_path = ds_path / args.language
    store_root = ds_path / "rag_data"
    store_root.mkdir(parents=True, exist_ok=True)

    domain = args.domain or (f"{args.dataset}_{args.language}" if args.language else args.dataset)
    docs_dir = store_root / "docs"

    if not docs_dir.exists():
        print(f"Docs directory not found: {docs_dir} (abs={docs_dir.resolve()})\n"
              f"Create it and add .txt/.md/.pdf files, then rerun.")
        return

    # Ensure index exists (build if missing)
    ensure_index(store_root, domain, docs_dir)

    # Demo query and prompt
    query = "parent relation gender role"
    hits = demo_query(store_root, domain, query, top_k=args.top_k)

    schema_example = "<nodes>\nparent[Person,Person]\nchild[Person,Person]\n</nodes>\n<edges>\n[parent,Person,child]\n</edges>"
    prompt = demo_solar_prompt("parent", schema_example, hits)
    print("\n=== SOLAR Prompt Example ===")
    print(prompt)

    if args.run_solar:
        # Compose a SOLAR run with dataset-scoped paths and RAG enabled
        main_solar = repo_root / "main_SOLAR.py"
        data_path = (repo_root / "dataset").as_posix()
        rule_path = (repo_root / "gen_rules").as_posix()
        cmd = [
            sys.executable,
            str(main_solar),
            "--data_path", data_path,
            "--dataset", args.dataset,
            "--schema_type", args.schema_type,
            "--prompt_type", args.prompt_type,
            "--spca_mode", args.spca_mode,
            "--coordinator_model", args.coordinator_model,
            "--rule_path", rule_path,
            "--rag_domain", domain,
        ]
        if args.language:
            cmd += ["--language", args.language]
        print("\nRunning SOLAR:")
        print(" ", " ".join(cmd))
        try:
            subprocess.run(cmd, check=True)
        except subprocess.CalledProcessError as e:
            print(f"SOLAR run failed: {e}")


if __name__ == "__main__":
    main()
