"""Lightweight RAG utilities for SOLAR.

Two backends are supported:

1) LlamaIndex persistent index (default) — supports PDFs and text.
   - Stored under: rag_store/<domain>/llama_index/
   - Build: vector index over .txt/.md/.pdf; persist to disk.
   - Query: load persisted index and retrieve top-k nodes.

2) Sentence-Transformers (fallback, text only) — simple local embeddings.
   - Stored under: rag_store/<domain>/{meta.json, embeddings.npy}
   - Build: chunk text, encode, and save numpy arrays.
   - Query: cosine similarity over saved vectors.

Use the default LlamaIndex backend when possible, as it natively handles PDFs
and provides robust persistence. The ST backend remains for minimal installs.
"""

from pathlib import Path
from typing import List, Tuple, Dict, Optional
import json
import numpy as np
import os
import warnings
# Reduce noisy transformer warnings when available
try:
    from transformers.utils import logging as hf_logging  # type: ignore
    os.environ.setdefault('TRANSFORMERS_VERBOSITY', 'error')
    hf_logging.set_verbosity_error()
    warnings.filterwarnings(
        "ignore",
        message=r".*clean_up_tokenization_spaces.*",
        category=FutureWarning,
    )
except Exception:
    pass


def _load_embeddings(store_dir: Path) -> Tuple[np.ndarray, Dict]:
    emb = np.load(store_dir / "embeddings.npy")
    meta = json.loads((store_dir / "meta.json").read_text(encoding="utf-8"))
    return emb, meta


def _encode(texts: List[str], model_name: str):
    # Lazy import to avoid mandatory dependency when unused
    from sentence_transformers import SentenceTransformer
    import os
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
    model = SentenceTransformer(model_name)
    return model.encode(texts, show_progress_bar=False)


def _retrieve_st(store_dir: Path, query: str, top_k: int, model_name: str) -> List[Dict]:
    emb, meta = _load_embeddings(store_dir)
    index_model = meta.get("model", model_name)
    q_emb = _encode([query], index_model)[0]
    denom = (np.linalg.norm(emb, axis=1) * (np.linalg.norm(q_emb) + 1e-12) + 1e-12)
    sims = (emb @ q_emb) / denom
    idx = np.argsort(-sims)[: max(1, top_k)]
    chunks = meta.get("chunks", [])
    out = []
    for i in idx:
        ch = chunks[int(i)]
        out.append({"text": ch.get("text", ""), "doc": ch.get("doc", ""), "score": float(sims[int(i)])})
    return out


def _build_index_st(domain: str, docs_dir: str, model_name: str, store_root: str,
                    exts: Tuple[str, ...] = (".txt", ".md"), chunk_chars: int = 800, chunk_overlap: int = 100) -> Path:
    dpath = Path(docs_dir)
    files = [p for p in dpath.rglob("*") if p.suffix.lower() in exts]
    chunks = []
    for f in files:
        text = f.read_text(encoding="utf-8", errors="ignore")
        start = 0
        while start < len(text):
            end = min(len(text), start + chunk_chars)
            if end < len(text):
                nl = text.rfind("\n\n", start, end)
                if nl != -1 and nl > start + 200:
                    end = nl
            chunk = text[start:end].strip()
            if chunk:
                chunks.append({"doc": str(f.relative_to(dpath)), "start": start, "end": end, "text": chunk})
            start = max(end - chunk_overlap, 0)
            if start == end:
                start = end + 1
    if not chunks:
        raise SystemExit(f"No text chunks found under {docs_dir}")
    embeddings = _encode([c["text"] for c in chunks], model_name)
    store_dir = Path(store_root) / domain
    store_dir.mkdir(parents=True, exist_ok=True)
    np.save(store_dir / "embeddings.npy", embeddings.astype(np.float32))
    (store_dir / "meta.json").write_text(json.dumps({"model": model_name, "chunks": chunks}, ensure_ascii=False), encoding="utf-8")
    return store_dir


def build_index(domain: str, docs_dir: str, model_name: str = "all-MiniLM-L6-v2", store_root: str = "rag_store",
                exts: Tuple[str, ...] = (".txt", ".md", ".pdf"), chunk_chars: int = 800, chunk_overlap: int = 100,
                backend: str = "llama") -> Path:
    """Build an embedding index over docs for a domain.

    backend:
      - 'llama' (default): persistent LlamaIndex under rag_store/<domain>/llama_index/
      - 'st': sentence-transformers numpy arrays (text-only)
    """
    if backend == "st":
        return _build_index_st(domain, docs_dir, model_name, store_root,
                               exts=tuple(e for e in exts if e != ".pdf"),
                               chunk_chars=chunk_chars, chunk_overlap=chunk_overlap)
    # LlamaIndex backend (supports PDFs)
    try:
        from llama_index.core import VectorStoreIndex, StorageContext, Settings
        from llama_index.core import SimpleDirectoryReader
        try:
            # Prefer simple, regex-based splitter to avoid NLTK corpora downloads
            from llama_index.core.node_parser import SentenceSplitter  # type: ignore
            Settings.text_splitter = SentenceSplitter(chunk_size=chunk_chars, chunk_overlap=chunk_overlap)
        except Exception:
            pass
        try:
            # Prefer local HF embeddings to avoid OpenAI dependency
            from llama_index.embeddings.huggingface import HuggingFaceEmbedding  # type: ignore
            Settings.embed_model = HuggingFaceEmbedding(model_name=model_name)
        except Exception as ee:
            print(
                "Warning: HuggingFace embedding backend not available (llama-index-embeddings-huggingface). "
                "Install it or pass backend='st'. Falling back to ST backend."
            )
            raise ee
    except Exception as e:
        print(f"Warning: LlamaIndex unavailable ({e}); falling back to ST backend.")
        return _build_index_st(domain, docs_dir, model_name, store_root,
                               exts=tuple(e for e in exts if e != ".pdf"),
                               chunk_chars=chunk_chars, chunk_overlap=chunk_overlap)
    # Load documents (txt/md/pdf)
    reader = SimpleDirectoryReader(input_dir=docs_dir, recursive=True, required_exts=list(exts), errors='ignore')
    docs = reader.load_data()
    if not docs:
        raise SystemExit(f"No supported documents found under {docs_dir}")
    index = VectorStoreIndex.from_documents(docs)
    persist_dir = Path(store_root) / domain / "llama_index"
    persist_dir.mkdir(parents=True, exist_ok=True)
    index.storage_context.persist(persist_dir=str(persist_dir))
    # Record the embedding model used for llama backend
    try:
        (persist_dir.parent / "llama_meta.json").write_text(
            json.dumps({"model": model_name}, ensure_ascii=False), encoding="utf-8"
        )
    except Exception:
        pass
    return persist_dir.parent


def retrieve(domain: str, query: str, top_k: int = 3, model_name: str = "all-MiniLM-L6-v2",
             store_root: str = "rag_store", backend: Optional[str] = None) -> List[Dict]:
    """Retrieve top_k relevant chunks for a domain given a query.

    Auto-detects backend from store on disk unless explicitly provided.
    Returns a list of {"text":..., "doc":..., "score": float} sorted by score desc.
    """
    store_dir = Path(store_root) / domain
    if not store_dir.exists():
        return []
    # Prefer llama index if present
    llama_dir = store_dir / "llama_index"
    use_llama = (backend == "llama") or (backend is None and llama_dir.exists())
    if use_llama:
        try:
            from llama_index.core import StorageContext, load_index_from_storage, Settings
            # Try to set HF embedding model to avoid OpenAI requirement
            try:
                from llama_index.embeddings.huggingface import HuggingFaceEmbedding  # type: ignore
                # If there's a recorded model for this index, prefer that
                meta_path = llama_dir.parent / "llama_meta.json"
                model_to_use = model_name
                if meta_path.exists():
                    try:
                        model_to_use = json.loads(meta_path.read_text(encoding="utf-8")).get("model", model_to_use)
                    except Exception:
                        pass
                Settings.embed_model = HuggingFaceEmbedding(model_name=model_to_use)
            except Exception as ee:
                print(
                    "Warning: missing HF embedding backend for llama index (install llama-index-embeddings-huggingface); "
                    "falling back to ST backend."
                )
                raise ee
            storage_context = StorageContext.from_defaults(persist_dir=str(llama_dir))
            index = load_index_from_storage(storage_context)
            retriever = index.as_retriever(similarity_top_k=top_k)
            nodes = retriever.retrieve(query)
            out = []
            for n in nodes:
                # n can be NodeWithScore
                text = n.text if hasattr(n, 'text') else getattr(n.node, 'text', '')
                docid = getattr(n, 'node', None)
                doc = ''
                if docid is not None and hasattr(docid, 'metadata'):
                    doc = docid.metadata.get('file_path', docid.metadata.get('doc_id', ''))
                out.append({"text": text, "doc": doc, "score": float(getattr(n, 'score', 0.0))})
            return out
        except Exception as e:
            print(f"Warning: failed to query LlamaIndex store ({e}); falling back to ST backend.")
            # fallthrough to ST
    # ST backend
    meta_path = store_dir / "meta.json"
    emb_path = store_dir / "embeddings.npy"
    if not (meta_path.exists() and emb_path.exists()):
        return []
    return _retrieve_st(store_dir, query, top_k, model_name)
