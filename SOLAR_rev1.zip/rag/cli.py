#!/usr/bin/env python3
"""Simple CLI to build/query SOLAR RAG indices.

Usage:
  python -m rag.cli build --domain family_es --docs dataset/family/spanish_docs
  python -m rag.cli query --domain family_es --q "isParentOf(X,Y) and gender" --top_k 3
"""

import argparse
from pathlib import Path
from . import build_index, retrieve


def main():
    ap = argparse.ArgumentParser(description="SOLAR RAG utility")
    sub = ap.add_subparsers(dest="cmd", required=True)

    b = sub.add_parser("build", help="Build index for a domain")
    b.add_argument("--domain", required=True, help="Domain name (store under rag_store/<domain>)")
    b.add_argument("--docs", required=True, help="Directory with .txt/.md documents")
    b.add_argument("--model", default="all-MiniLM-L6-v2", help="Embedding model for ST backend (ignored by llama)")
    b.add_argument("--store", default="rag_store", help="Root store directory (default rag_store)")
    b.add_argument("--backend", choices=["llama","st"], default="llama", help="Backend: llama (persistent) or st (numpy)")

    q = sub.add_parser("query", help="Query an existing domain index")
    q.add_argument("--domain", required=True)
    q.add_argument("--q", required=True, help="Query text")
    q.add_argument("--top_k", type=int, default=3)
    q.add_argument("--model", default="all-MiniLM-L6-v2")
    q.add_argument("--store", default="rag_store")
    q.add_argument("--backend", choices=["llama","st"], default=None, help="Force backend; default auto-detect")

    args = ap.parse_args()
    if args.cmd == "build":
        p = build_index(args.domain, args.docs, model_name=args.model, store_root=args.store, backend=args.backend)
        print(f"Built index at {p}")
    else:
        hits = retrieve(args.domain, args.q, top_k=args.top_k, model_name=args.model, store_root=args.store, backend=args.backend)
        for i, h in enumerate(hits, 1):
            print(f"[{i}] score={h['score']:.4f} doc={h['doc']}")
            print(h["text"][:500])
            print("---")


if __name__ == "__main__":
    main()
