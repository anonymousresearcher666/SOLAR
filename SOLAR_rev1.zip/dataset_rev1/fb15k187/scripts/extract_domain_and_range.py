import pickle


def load_pickle(file_path):
    """
    Utility function to load a pickle file.

    :param file_path: str, the path to the .pkl file.
    :return: The data loaded from the pickle file.
    """
    with open(file_path, 'rb') as file:
        data = pickle.load(file)
    return data


def map_relations_to_ranges(class_file, relation_file, relation_to_range_file):
    """
    Maps each relation to its range expressed as a class name.

    :param class_file: str, path to the class2id.pkl file.
    :param relation_file: str, path to the rel2id.pkl file.
    :param relation_to_range_file: str, path to the r2id2range2id.pkl file.
    """
    # Load all the necessary data from pickle files
    class2id = load_pickle(class_file)
    rel2id = load_pickle(relation_file)
    r2id2range2id = load_pickle(relation_to_range_file)

    # Invert the class2id dictionary to get id2class
    id2class = {v: k for k, v in class2id.items()}

    # Map relation names to range classes
    for rel_name, rel_id in rel2id.items():
        if rel_id in r2id2range2id:
            range_id = r2id2range2id[rel_id]
            if range_id in id2class:
                range_class = id2class[range_id]
                print(f"'{rel_name}' range {range_class}")
            else:
                print(f"Range ID {range_id} for relation '{rel_name}' is not in class2id")
        else:
            print(f"Relation ID {rel_id} for relation '{rel_name}' is not in r2id2range2id")


# Example usage:
class_file = '/dataset/fb15k187/scripts/class2id.pkl'
relation_file = '/dataset/fb15k187/scripts/rel2id.pkl'
relation_to_range_file = '/dataset/fb15k187/scripts/r2id2range2id.pkl'
map_relations_to_ranges(class_file, relation_file, relation_to_range_file)
