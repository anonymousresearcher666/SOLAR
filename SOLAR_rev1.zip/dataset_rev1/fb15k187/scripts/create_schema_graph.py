def transform_triples(file_path):
    # Dictionary to hold the domain and range for each predicate
    predicate_mapping = {}

    try:
        # Read from the file
        with open(file_path, 'r') as file:
            for line in file:
                # Remove unnecessary characters and split
                parts = line.strip().strip('()').split()
                if len(parts) == 3:
                    predicate, rel_type, clazz = parts
                    if predicate not in predicate_mapping:
                        predicate_mapping[predicate] = {}
                    predicate_mapping[predicate][rel_type] = clazz

        # Process the dictionary to format the triples as 'C1 p1 C2'
        transformed_triples = []
        for predicate, mappings in predicate_mapping.items():
            if 'domain' in mappings and 'range' in mappings:
                new_triple = f"{mappings['domain']} {predicate} {mappings['range']}"
                transformed_triples.append(new_triple)
            else:
                print(f"Missing domain or range for predicate {predicate}")

        return transformed_triples

    except FileNotFoundError:
        print("The specified file does not exist.")
        return []

    except Exception as e:
        print(f"An error occurred: {e}")
        return []


# Example usage:
file_path = 'domain_and_range_schema_original.txt'
triples = transform_triples(file_path)
for triple in triples:
    print(triple)
