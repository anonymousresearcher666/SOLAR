def write_schema_graph(file_path: str, output_path: str):
    predicate_mapping = {}
    subclass_lines = []

    try:
        with open(file_path, 'r') as file:
            for line in file:
                parts = line.strip().split()
                if len(parts) == 3:
                    predicate, rel_type, clazz = parts

                    if rel_type == "subClass":
                        subclass_lines.append(f"{predicate} subClass {clazz}\n")
                    else:
                        if predicate not in predicate_mapping:
                            predicate_mapping[predicate] = {'domain': set(), 'range': set()}
                        predicate_mapping[predicate][rel_type].add(clazz)

        with open(output_path, 'w') as out:
            for predicate, mappings in predicate_mapping.items():
                domains = mappings.get('domain', set())
                ranges = mappings.get('range', set())

                if not domains or not ranges:
                    print(f"Missing domain or range for predicate {predicate}")
                    continue

                for d in domains:
                    for r in ranges:
                        out.write(f"{d} {predicate} {r}\n")

            for line in subclass_lines:
                out.write(line)

        print(f"Schema graph written to {output_path}")

    except FileNotFoundError:
        print("The specified file does not exist.")
    except Exception as e:
        print(f"An error occurred: {e}")


# Example usage:
file_path = 'domain_and_range.txt'
write_schema_graph(file_path, "schema_graph.txt")

