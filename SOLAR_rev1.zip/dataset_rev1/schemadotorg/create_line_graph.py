from collections import defaultdict

def compute_transitive_closure(subclass_map):
    closure = defaultdict(set)

    # Initialize with direct subclass relations
    for subclass, superclasses in subclass_map.items():
        closure[subclass].update(superclasses)

    # Floyd-Warshall-style transitive closure
    changed = True
    while changed:
        changed = False
        for a in list(closure):
            for b in list(closure[a]):
                if not closure[b].issubset(closure[a]):
                    closure[a].update(closure[b])
                    changed = True

    return closure

def compute_line_graph(schema_triples, subclass_map):
    # Compute full transitive subclass closure
    subclass_closure = compute_transitive_closure(subclass_map)

    # Map each predicate to its (domain, range)
    predicate_to_nodes = {}
    for subj, pred, obj in schema_triples:
        if pred != "subClass":
            predicate_to_nodes[pred] = (subj, obj)

    # Build adjacency list (line graph)
    line_graph = defaultdict(set)
    predicates = list(predicate_to_nodes.keys())

    def are_related(a, b):
        return (
            a == b
            or b in subclass_closure.get(a, set())
            or a in subclass_closure.get(b, set())
        )

    for i in range(len(predicates)):
        for j in range(i + 1, len(predicates)):
            p1, p2 = predicates[i], predicates[j]
            s1, o1 = predicate_to_nodes[p1]
            s2, o2 = predicate_to_nodes[p2]

            # Check if they share domain or range or are subclasses
            if are_related(s1, s2) or are_related(s1, o2) or are_related(o1, s2) or are_related(o1, o2):
                line_graph[p1].add(p2)
                line_graph[p2].add(p1)

    return predicate_to_nodes, line_graph

# === Read from input file ===
input_path = 'schema_graph.txt'
triples = []
subclass_map = defaultdict(set)

with open(input_path, 'r') as file:
    for line in file:
        triple = line.strip().split()
        if len(triple) == 3:
            subj, pred, obj = triple
            if pred == 'subClass':
                subclass_map[subj].add(obj)
            else:
                triples.append((subj, pred, obj))

# === Process triples ===
predicate_nodes, line_graph = compute_line_graph(triples, subclass_map)

# === Write to output file ===
output_path = 'line_graph.txt'
with open(output_path, 'w') as out:
    out.write("<nodes>\n")
    for pred, (subj, obj) in sorted(predicate_nodes.items()):
        out.write(f"{pred}[{subj},{obj}]\n")
    out.write("</nodes>\n")

    out.write("<edges>\n")
    printed = set()
    for pred, neighbors in line_graph.items():
        for neighbor in neighbors:
            if (neighbor, pred) not in printed:
                shared = set(predicate_nodes[pred]) & set(predicate_nodes[neighbor])
                for element in shared:
                    out.write(f"[{pred},{element},{neighbor}]\n")
                printed.add((pred, neighbor))
    out.write("</edges>\n")

print(f"\u2705 Line graph saved to {output_path}")
