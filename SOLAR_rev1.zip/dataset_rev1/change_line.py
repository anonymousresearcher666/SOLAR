# Function to parse the schema file and return nodes and edges
def parse_schema_file(file_path):
    nodes = []
    edges = []
    in_nodes_section = False
    in_edges_section = False

    with open(file_path, 'r') as file:
        for line in file:
            line = line.strip()
            if line == "<nodes>":
                in_nodes_section = True
            elif line == "</nodes>":
                in_nodes_section = False
            elif line == "<edges>":
                in_edges_section = True
            elif line == "</edges>":
                in_edges_section = False
            elif in_nodes_section:
                if line:
                    nodes.append(line)
            elif in_edges_section:
                if line:
                    edges.append(line)

    return nodes, edges


# Function to map node names to their descriptions
def create_node_dict(nodes):
    node_dict = {}
    for node in nodes:
        name, args = node.split("[")
        node_dict[name] = args[:-1]  # Remove the trailing ']'
    return node_dict


# Function to replace edge names with their full descriptions
def replace_edges_with_full_names(edges, node_dict):
    new_edges = []
    for edge in edges:
        elements = edge[1:-1].split(",")
        # Replace the relation names in edges with their corresponding full names from nodes
        replaced_elements = [
            f"{elements[0]}[{node_dict[elements[0]]}]",  # Relation and its argument types
            elements[1],  # First entity type (unchanged)
            f"{elements[2]}[{node_dict[elements[2]]}]"  # Second relation and its argument types
        ]
        new_edges.append(f"[{', '.join(replaced_elements)}]")
    return new_edges


# Main function to run the entire process
def main(file_path):
    nodes, edges = parse_schema_file(file_path)
    node_dict = create_node_dict(nodes)
    new_edges = replace_edges_with_full_names(edges, node_dict)

    # Output the new edges
    for edge in new_edges:
        print(edge)


# Example usage
file_path = '/Volumes/DATI 1/GITHUB/KGRL/dataset/airgraph/line_graph.txt'  # Replace with your schema file path
main(file_path)
