import json
import re
from pathlib import Path
from typing import Dict, List, Tuple, Iterable

Rule = Tuple[str, List[str]]  # (head_pred, [body_predicates])


def load_mapping(path: str) -> Dict[str, List[str]]:
    """Load predicate mapping JSON. Supports values as string or list.

    Example:
      {
        "parent": ["father", "mother"],
        "child": ["son", "daughter"],
        "spouse": ["husband", "wife"],
        "sibling": ["brother", "sister"]
      }
    """
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    out: Dict[str, List[str]] = {}
    for k, v in data.items():
        if isinstance(v, list):
            out[k] = [str(x) for x in v]
        else:
            out[k] = [str(v)]
    return out


_HEAD_RE = re.compile(r"^(\w+)\s*\(([^)]*)\)\s*:\-\s*(.*)$")
_ATOM_RE = re.compile(r"(\w+)\s*\(([^)]*)\)")


def parse_rule_text(rule_text: str) -> Rule:
    s = rule_text.strip()
    m = _HEAD_RE.match(s)
    if not m:
        # try fact-like head without body
        m2 = _ATOM_RE.match(s)
        if not m2:
            raise ValueError(f"Invalid rule: {rule_text}")
        head_pred = m2.group(1)
        return head_pred, []
    head_pred = m.group(1)
    body = m.group(3)
    body_preds = [p.group(1) for p in _ATOM_RE.finditer(body)]
    return head_pred, body_preds


def map_rule_text(rule_text: str, pred_map: Dict[str, List[str]], *, expand_head: bool = True) -> List[str]:
    """Map a rule's predicates using pred_map. Returns one or more mapped rules.

    - If the head maps to multiple targets and expand_head=True, returns one rule per target head.
    - Body predicates are mapped 1:1 using the first mapped value when a list is provided;
      if no mapping, they are kept as-is.
    """
    head, body = parse_rule_text(rule_text)
    head_targets = pred_map.get(head, [head])
    mapped_rules: List[str] = []
    for h in (head_targets if expand_head else [head_targets[0]]):
        mapped_body = []
        for b in body:
            mapped_b = pred_map.get(b, [b])[0]
            mapped_body.append(mapped_b)
        # Rebuild text with original variables unchanged by design
        # Simple replacement of predicate names only
        s = rule_text
        s = re.sub(rf"\b{re.escape(head)}\s*(\()", h + r"\1", s, count=1)
        for b, mb in zip(body, mapped_body):
            s = re.sub(rf"\b{re.escape(b)}\s*(\()", mb + r"\1", s, count=1)
        mapped_rules.append(s)
    return mapped_rules


def map_rules_in_text(text: str, pred_map: Dict[str, List[str]], *, expand_head: bool = True) -> List[str]:
    out: List[str] = []
    for ln in text.splitlines():
        s = ln.strip()
        if not s:
            continue
        try:
            mapped = map_rule_text(s, pred_map, expand_head=expand_head)
        except Exception:
            # skip invalid lines quietly
            continue
        out.extend(mapped)
    return out


def read_target_predicates_from_line_graph(path: str) -> List[str]:
    """Parse <nodes> of line_graph.txt and return predicate names."""
    p = Path(path)
    if not p.exists():
        return []
    content = p.read_text(encoding="utf-8", errors="ignore")
    in_nodes = False
    preds: List[str] = []
    for raw in content.splitlines():
        line = raw.strip()
        if line == "<nodes>":
            in_nodes = True
            continue
        if line == "</nodes>":
            in_nodes = False
            continue
        if in_nodes:
            m = re.match(r"^(\w+)\[", line)
            if m:
                preds.append(m.group(1))
    return preds


def validate_mapped_rules(rules: Iterable[str], target_predicates: List[str]) -> List[str]:
    """Keep only rules whose head predicate exists in target predicates."""
    keep: List[str] = []
    tset = set(target_predicates)
    for r in rules:
        try:
            head, _ = parse_rule_text(r)
        except Exception:
            continue
        if head in tset:
            keep.append(r)
    return keep


# --- Schema matching to compute predicate mappings once ---

def parse_line_graph_nodes(path: str) -> Dict[str, Tuple[str, str]]:
    """Parse line_graph.txt and return {predicate: (domain, range)}"""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(path)
    text = p.read_text(encoding='utf-8', errors='ignore')
    in_nodes = False
    out: Dict[str, Tuple[str, str]] = {}
    for raw in text.splitlines():
        line = raw.strip()
        if line == '<nodes>':
            in_nodes = True
            continue
        if line == '</nodes>':
            in_nodes = False
            continue
        if in_nodes and '[' in line and ']' in line:
            try:
                name, rest = line.split('[', 1)
                dom, rng = rest.rstrip(']').split(',')
                out[name.strip()] = (dom.strip(), rng.strip())
            except Exception:
                continue
    return out


def _normalize_tokens(s: str) -> List[str]:
    s = s.strip().lower()
    s = re.sub(r"[^a-z0-9_]+", " ", s)
    toks = [t for t in s.split() if t]
    # Simple stemming for plural forms
    norm = []
    for t in toks:
        if t.endswith('s') and len(t) > 3:
            t = t[:-1]
        norm.append(t)
    return norm


_SYNONYMS = {
    'parent': {'parent', 'father', 'mother'},
    'child': {'child', 'son', 'daughter'},
    'spouse': {'spouse', 'husband', 'wife'},
    'sibling': {'sibling', 'brother', 'sister'},
}


def _name_similarity(a: str, b: str) -> float:
    at = set(_normalize_tokens(a))
    bt = set(_normalize_tokens(b))
    if not at or not bt:
        return 0.0
    # expand with synonyms
    ax = set(at)
    bx = set(bt)
    for base, syns in _SYNONYMS.items():
        if base in at:
            ax |= syns
        if base in bt:
            bx |= syns
    inter = len(ax & bx)
    uni = len(ax | bx)
    return inter / uni if uni else 0.0


def _embed_sim(a: List[str], b: List[str], model_name: str) -> List[List[float]]:
    try:
        from sentence_transformers import SentenceTransformer
        import numpy as np  # ensure local scope
    except Exception:
        # Fallback: compute name similarity only
        return [[_name_similarity(x, y) for y in b] for x in a]
    model = SentenceTransformer(model_name)
    va = model.encode(a, show_progress_bar=False)
    vb = model.encode(b, show_progress_bar=False)
    va = np.asarray(va)
    vb = np.asarray(vb)
    va = va / (np.linalg.norm(va, axis=1, keepdims=True) + 1e-12)
    vb = vb / (np.linalg.norm(vb, axis=1, keepdims=True) + 1e-12)
    sims = va @ vb.T
    return sims.tolist()


def compute_schema_mapping(src_line_graph: str, tgt_line_graph: str, *, model_name: str = 'all-MiniLM-L6-v2',
                           top_k: int = 1, threshold: float = 0.35) -> Dict[str, List[str]]:
    """Compute a predicate mapping from source to target schema.

    Scoring combines name/embedding similarity and domain-range compatibility.
    Returns a dict: {src_pred: [tgt_pred, ...]} filtered by threshold and limited to top_k.
    """
    src = parse_line_graph_nodes(src_line_graph)
    tgt = parse_line_graph_nodes(tgt_line_graph)
    src_preds = list(src.keys())
    tgt_preds = list(tgt.keys())
    # Embedding/name similarities
    sims = _embed_sim(src_preds, tgt_preds, model_name)
    out: Dict[str, List[str]] = {}
    for i, sp in enumerate(src_preds):
        sc = []
        for j, tp in enumerate(tgt_preds):
            score = sims[i][j]
            # domain-range compatibility bonus
            if src[sp][0].lower() == tgt[tp][0].lower():
                score += 0.05
            if src[sp][1].lower() == tgt[tp][1].lower():
                score += 0.05
            sc.append((tp, score))
        sc.sort(key=lambda x: x[1], reverse=True)
        kept = [tp for tp, s in sc if s >= threshold][:max(1, top_k)]
        out[sp] = kept
    return out


def save_mapping(mapping: Dict[str, List[str]], out_path: str) -> None:
    # write values as list or string for singletons
    serial: Dict[str, object] = {}
    for k, v in mapping.items():
        if not v:
            continue
        serial[k] = v[0] if len(v) == 1 else v
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    Path(out_path).write_text(json.dumps(serial, ensure_ascii=False, indent=2), encoding='utf-8')


# --- Domain/Range-driven mappings (classes + predicates) ---

def parse_domain_and_range(path: str) -> Tuple[Dict[str, Tuple[str, str]], List[str]]:
    """Parse domain_and_range.txt -> ({pred: (domain, range)}, classes)."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(path)
    dom: Dict[str, str] = {}
    rng: Dict[str, str] = {}
    classes = set()
    for raw in p.read_text(encoding='utf-8', errors='ignore').splitlines():
        parts = raw.strip().split()
        if len(parts) != 3:
            continue
        pred, kind, cls = parts
        if kind.lower() == 'domain':
            dom[pred] = cls
            classes.add(cls)
        elif kind.lower() == 'range':
            rng[pred] = cls
            classes.add(cls)
    pr: Dict[str, Tuple[str, str]] = {}
    for pred in set(dom) | set(rng):
        pr[pred] = (dom.get(pred, ''), rng.get(pred, ''))
    return pr, sorted(classes)


def compute_class_mapping(src_classes: List[str], tgt_classes: List[str], *, model_name: str = 'all-MiniLM-L6-v2',
                          top_k: int = 1, threshold: float = 0.35) -> Dict[str, List[str]]:
    sims = _embed_sim(src_classes, tgt_classes, model_name)
    out: Dict[str, List[str]] = {}
    for i, sc in enumerate(src_classes):
        row = [(tgt_classes[j], sims[i][j]) for j in range(len(tgt_classes))]
        row.sort(key=lambda x: x[1], reverse=True)
        kept = [t for t, s in row if s >= threshold][:max(1, top_k)]
        out[sc] = kept
    return out


def compute_predicate_mapping_from_dr(src_pr: Dict[str, Tuple[str, str]], tgt_pr: Dict[str, Tuple[str, str]],
                                      class_map: Dict[str, List[str]], *,
                                      model_name: str = 'all-MiniLM-L6-v2', top_k: int = 1,
                                      threshold: float = 0.30) -> Dict[str, List[str]]:
    src_preds = list(src_pr.keys())
    tgt_preds = list(tgt_pr.keys())
    name_sims = _embed_sim(src_preds, tgt_preds, model_name)
    out: Dict[str, List[str]] = {}
    for i, sp in enumerate(src_preds):
        s_dom, s_rng = src_pr.get(sp, ('', ''))
        dom_targets = class_map.get(s_dom, [s_dom]) if s_dom else [s_dom]
        rng_targets = class_map.get(s_rng, [s_rng]) if s_rng else [s_rng]
        scored = []
        for j, tp in enumerate(tgt_preds):
            t_dom, t_rng = tgt_pr.get(tp, ('', ''))
            score = name_sims[i][j]
            if t_dom in dom_targets:
                score += 0.15
            if t_rng in rng_targets:
                score += 0.15
            scored.append((tp, score))
        scored.sort(key=lambda x: x[1], reverse=True)
        kept = [tp for tp, sc in scored if sc >= threshold][:max(1, top_k)]
        out[sp] = kept
    return out


def compute_schema_mappings_dr(src_domain_range: str, tgt_domain_range: str, *,
                               model_name: str = 'all-MiniLM-L6-v2',
                               class_top_k: int = 1, class_threshold: float = 0.35,
                               pred_top_k: int = 1, pred_threshold: float = 0.30) -> Dict[str, Dict[str, List[str]]]:
    """Compute both class and predicate mappings from domain_and_range.txt files."""
    src_pr, src_classes = parse_domain_and_range(src_domain_range)
    tgt_pr, tgt_classes = parse_domain_and_range(tgt_domain_range)
    class_map = compute_class_mapping(src_classes, tgt_classes, model_name=model_name,
                                      top_k=class_top_k, threshold=class_threshold)
    pred_map = compute_predicate_mapping_from_dr(src_pr, tgt_pr, class_map, model_name=model_name,
                                                 top_k=pred_top_k, threshold=pred_threshold)
    return {"classes": class_map, "predicates": pred_map}


def save_mappings(mappings: Dict[str, Dict[str, List[str]]], out_path: str) -> None:
    """Write only non-empty mappings for classes and predicates."""
    classes = mappings.get("classes", {}) or {}
    preds = mappings.get("predicates", {}) or {}
    filtered_classes = {k: v for k, v in classes.items() if v}
    filtered_preds = {k: v for k, v in preds.items() if v}
    serial = {"classes": filtered_classes, "predicates": filtered_preds}
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    Path(out_path).write_text(json.dumps(serial, ensure_ascii=False, indent=2), encoding='utf-8')

