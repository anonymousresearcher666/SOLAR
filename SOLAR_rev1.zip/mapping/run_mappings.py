#!/usr/bin/env python3
"""Compute and store class + predicate schema mappings for SOLAR datasets.

This script reads domain_and_range.txt from a source and a target dataset,
computes:
  - class mappings (src class -> [tgt class, ...])
  - predicate mappings (src pred -> [tgt pred, ...]) leveraging class mapping

It stores the result in the source dataset directory so it can be reused,
with the file name convention:
  dataset/<src>/<src>_to_<tgt>_mappings.json

No rule mapping is performed here. Use mapping/cli.py later with the saved
JSON to map rules as needed.
"""

import argparse
from pathlib import Path
try:
    from mapping import (
        compute_schema_mappings_dr,
        save_mappings,
    )
except Exception:
    import sys
    repo_root_fallback = Path(__file__).resolve().parents[1]
    if str(repo_root_fallback) not in sys.path:
        sys.path.insert(0, str(repo_root_fallback))
    from mapping import (  # type: ignore
        compute_schema_mappings_dr,
        save_mappings,
    )


def compute_or_load_mappings(repo_root: Path, src_dataset: str, tgt_dataset: str,
                             model_name: str,
                             class_top_k: int, class_threshold: float,
                             pred_top_k: int, pred_threshold: float) -> Path:
    """Store mappings JSON (classes+predicates) inside SOURCE dataset directory.

    Path: dataset/<src>/<src>_to_<tgt>_mappings.json
    Uses domain_and_range.txt from both datasets.
    """
    src_ds_dir = repo_root / 'dataset' / src_dataset
    src_ds_dir.mkdir(parents=True, exist_ok=True)
    out_path = src_ds_dir / f"{src_dataset}_to_{tgt_dataset}_mappings.json"
    if out_path.exists():
        print(f"Using existing mappings: {out_path}")
        return out_path
    src_dr = src_ds_dir / 'domain_and_range.txt'
    tgt_dr = repo_root / 'dataset' / tgt_dataset / 'domain_and_range.txt'
    print(f"Computing mappings from {src_dr} -> {tgt_dr} (model={model_name})")
    mappings = compute_schema_mappings_dr(
        str(src_dr), str(tgt_dr),
        model_name=model_name,
        class_top_k=class_top_k, class_threshold=class_threshold,
        pred_top_k=pred_top_k, pred_threshold=pred_threshold,
    )
    save_mappings(mappings, str(out_path))
    print(f"Saved mappings to {out_path}")
    return out_path


    # No rule mapping here by design; this step only computes and stores schema mappings


def main():
    ap = argparse.ArgumentParser(description='Compute and store class + predicate mappings for SOLAR datasets')
    ap.add_argument('--src-dataset', default='schemadotorg', help='Source dataset (default: schemadotorg)')
    ap.add_argument('--tgt-dataset', default='fb15k187', help='Target dataset (default: family)')
    ap.add_argument('--model', default='all-MiniLM-L6-v2', help='SentenceTransformer model (default miniLM)')
    ap.add_argument('--class_top_k', type=int, default=1, help='Max target classes per source (default: 1)')
    ap.add_argument('--class_threshold', type=float, default=0.55, help='Class similarity threshold (default: 0.35)')
    ap.add_argument('--pred_top_k', type=int, default=1, help='Max target predicates per source (default: 1)')
    ap.add_argument('--pred_threshold', type=float, default=0.50, help='Predicate similarity threshold (default: 0.30)')
    args = ap.parse_args()

    repo_root = Path(__file__).resolve().parents[1]

    mappings_path = compute_or_load_mappings(
        repo_root, args.src_dataset, args.tgt_dataset,
        args.model,
        args.class_top_k, args.class_threshold,
        args.pred_top_k, args.pred_threshold,
    )
    print("\nMappings ready for reuse:")
    print(" ", mappings_path)
    print("Use mapping/cli.py to map rules with the saved JSON.")


if __name__ == '__main__':
    main()
