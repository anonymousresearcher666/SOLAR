This folder stores JSON predicate mappings for cross-schema rule transfer.

File format: a JSON object mapping source predicates to target predicate(s).

Example (schemadotorg -> family):
{
  "parent": ["father", "mother"],
  "child": ["son", "daughter"],
  "spouse": ["husband", "wife"],
  "sibling": ["brother", "sister"],
  "aunt": "aunt",
  "uncle": "uncle",
  "niece": "niece",
  "nephew": "nephew"
}

Notes:
- Values may be a string (1:1) or a list (1:many). The mapper will expand rules when the head maps to many.
- Body predicates prefer the first target in a list; unmatched body predicates are kept as-is.

