#!/usr/bin/env python3
"""Map rule files from a source dataset to a target dataset using precomputed schema mappings.

If the schema mappings JSON does not exist yet, this script will compute it
first from domain_and_range.txt and store it under the source dataset:

  dataset/<src>/<src>_to_<tgt>_mappings.json

Then it will map all *.txt rule files found under --src-rules, and write the
mapped versions under a subfolder of the same source results directory:

  <src-rules>/mapped_to_<tgt>/

Mapped files preserve the relative structure and names, and can optionally be
validated against the target dataset schema (line_graph.txt) to drop rules whose
head predicate is not present in the target.
"""

import argparse
from pathlib import Path
from typing import List, Dict, Any, Optional

try:
    from mapping import (
        compute_schema_mappings_dr,
        save_mappings,
        map_rule_text,
        read_target_predicates_from_line_graph,
        validate_mapped_rules,
        parse_rule_text,
    )
except Exception:
    import sys
    repo_root_fallback = Path(__file__).resolve().parents[1]
    if str(repo_root_fallback) not in sys.path:
        sys.path.insert(0, str(repo_root_fallback))
    from mapping import (  # type: ignore
        compute_schema_mappings_dr,
        save_mappings,
        map_rule_text,
        read_target_predicates_from_line_graph,
        validate_mapped_rules,
        parse_rule_text,
    )
import json


def ensure_mappings(repo_root: Path, src_dataset: str, tgt_dataset: str,
                    model_name: str, class_top_k: int, class_threshold: float,
                    pred_top_k: int, pred_threshold: float) -> Path:
    """Ensure dataset-scoped mappings JSON exists; compute and store if missing.

    Returns the mappings JSON path.
    """
    src_ds_dir = repo_root / 'dataset' / src_dataset
    src_ds_dir.mkdir(parents=True, exist_ok=True)
    out_path = src_ds_dir / f"{src_dataset}_to_{tgt_dataset}_mappings.json"
    if out_path.exists():
        print(f"Using existing mappings: {out_path}")
        return out_path
    src_dr = src_ds_dir / 'domain_and_range.txt'
    tgt_dr = repo_root / 'dataset' / tgt_dataset / 'domain_and_range.txt'
    print(f"Computing mappings from {src_dr} -> {tgt_dr} (model={model_name})")
    mappings = compute_schema_mappings_dr(
        str(src_dr), str(tgt_dr),
        model_name=model_name,
        class_top_k=class_top_k, class_threshold=class_threshold,
        pred_top_k=pred_top_k, pred_threshold=pred_threshold,
    )
    save_mappings(mappings, str(out_path))
    print(f"Saved mappings to {out_path}")
    return out_path


def load_predicate_map(mapping_path: Path) -> Dict[str, List[str]]:
    """Extract the predicate mapping dict from the saved mappings JSON."""
    data: Dict[str, Any] = json.loads(mapping_path.read_text(encoding='utf-8', errors='ignore'))
    if 'predicates' in data:
        pred_map = data['predicates'] or {}
    else:
        # Fallback: assume predicate-only file
        pred_map = data
    # Normalize: ensure every value is a list
    norm: Dict[str, List[str]] = {}
    for k, v in pred_map.items():
        if not v:
            continue
        if isinstance(v, list):
            norm[k] = [str(x) for x in v]
        else:
            norm[k] = [str(v)]
    return norm


def map_directory_to_json(src_root: Path, pred_map: Dict[str, List[str]],
                          target_preds: List[str], strict: bool = True,
                          source_preds: Optional[List[str]] = None, strict_source: bool = False) -> Dict[str, Any]:
    files = list(src_root.rglob('*.txt'))
    if not files:
        print(f"No rule files found under {src_root}")
        return {"source_root": str(src_root), "entries": []}
    entries: List[Dict[str, Any]] = []
    sset = set(source_preds or [])
    for f in files:
        for line in f.read_text(encoding='utf-8', errors='ignore').splitlines():
            s = line.strip()
            if not s:
                continue
            try:
                head, _ = parse_rule_text(s)
            except Exception:
                continue
            if strict_source and sset and head not in sset:
                continue
            mapped = map_rule_text(s, pred_map, expand_head=True)
            if strict and target_preds and mapped:
                mapped = validate_mapped_rules(mapped, target_preds)
            if mapped:
                entries.append({
                    "source_file": str(f.relative_to(src_root)),
                    "source_rule": s,
                    "mapped_rules": mapped,
                })
    return {"source_root": str(src_root), "entries": entries}


def main():
    ap = argparse.ArgumentParser(description='Map rules across datasets using stored schema mappings')
    ap.add_argument('--src-dataset', default='family', help='Source dataset (default: family)')
    ap.add_argument('--tgt-dataset', default='schemadotorg', help='Target dataset (default: schemadotorg)')
    ap.add_argument('--src-rules', default='', help='Source rules root directory to map (default: gen_rules/<src-dataset>)')
    ap.add_argument('--out', default='', help='Output dir (default: <src-rules>/mapped_to_<tgt>)')
    ap.add_argument('--strict', action='store_true', help='Keep only rules with head in target schema')
    ap.add_argument('--strict-source', action='store_true', help='Keep only input rules whose head exists in the source schema')
    # If mapping is missing, compute it
    ap.add_argument('--model', default='all-MiniLM-L6-v2', help='Model for mapping computation when needed')
    ap.add_argument('--class_top_k', type=int, default=1)
    ap.add_argument('--class_threshold', type=float, default=0.35)
    ap.add_argument('--pred_top_k', type=int, default=1)
    ap.add_argument('--pred_threshold', type=float, default=0.30)
    args = ap.parse_args()

    repo_root = Path(__file__).resolve().parents[1]
    mappings_path = ensure_mappings(
        repo_root, args.src_dataset, args.tgt_dataset,
        args.model, args.class_top_k, args.class_threshold,
        args.pred_top_k, args.pred_threshold,
    )
    pred_map = load_predicate_map(mappings_path)

    src_root = Path(args.src_rules) if args.src_rules else (repo_root / 'gen_rules' / args.src_dataset)
    if not src_root.exists():
        raise SystemExit(f"Source rules directory not found: {src_root}")
    out_root = Path(args.out) if args.out else (src_root / f"mapped_to_{args.tgt_dataset}")
    out_root.mkdir(parents=True, exist_ok=True)
    out_json = out_root / "rule_mappings.json"

    target_line_graph = repo_root / 'dataset' / args.tgt_dataset / 'line_graph.txt'
    target_preds = read_target_predicates_from_line_graph(str(target_line_graph)) if args.strict else []
    source_line_graph = repo_root / 'dataset' / args.src_dataset / 'line_graph.txt'
    source_preds = read_target_predicates_from_line_graph(str(source_line_graph)) if args.strict_source else []

    result = map_directory_to_json(src_root, pred_map, target_preds, strict=args.strict,
                                   source_preds=source_preds, strict_source=args.strict_source)
    out_json.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f"\nDone. Wrote mappings JSON with {len(result.get('entries', []))} entries -> {out_json}")


if __name__ == '__main__':
    main()
