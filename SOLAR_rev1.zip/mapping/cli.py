#!/usr/bin/env python3
"""Map rules learned on one schema (e.g., schemadotorg) to a target dataset.

Examples:
  # Map a directory of rules using a JSON predicate map
  python -m mapping.cli dir \
    --src gen_rules/schemadotorg/c2r_new/line/2/consensus_* \
    --map mapping/maps/schemadotorg_to_family.json \
    --out mapped_rules/family

  # Validate against target dataset schema
  python -m mapping.cli dir \
    --src gen_rules/schemadotorg/... \
    --map mapping/maps/schemadotorg_to_family.json \
    --target-line-graph dataset/family/line_graph.txt \
    --out mapped_rules/family --strict
"""

import argparse
from pathlib import Path
from typing import List
try:
    from . import (
        load_mapping,
        map_rules_in_text,
        read_target_predicates_from_line_graph,
        validate_mapped_rules,
        compute_schema_mapping,
        save_mapping,
        parse_rule_text,
    )
except Exception:
    import sys
    repo_root = Path(__file__).resolve().parents[1]
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))
    from mapping import (  # type: ignore
        load_mapping,
        map_rules_in_text,
        read_target_predicates_from_line_graph,
        validate_mapped_rules,
        compute_schema_mapping,
        save_mapping,
        parse_rule_text,
    )


def map_file(src_file: Path, pred_map, target_preds: List[str], strict: bool,
             source_preds: List[str], strict_source: bool) -> List[str]:
    text = src_file.read_text(encoding='utf-8', errors='ignore')
    lines: List[str] = []
    if strict_source and source_preds:
        sset = set(source_preds)
        for ln in text.splitlines():
            s = ln.strip()
            if not s:
                continue
            try:
                head, _ = parse_rule_text(s)
            except Exception:
                continue
            if head in sset:
                lines.append(s)
    else:
        lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    # map preserving expansion
    mapped: List[str] = []
    for s in lines:
        mapped.extend(map_rules_in_text(s, pred_map, expand_head=True))
    if strict and target_preds:
        mapped = validate_mapped_rules(mapped, target_preds)
    return mapped


def main():
    ap = argparse.ArgumentParser(description="Map rules across schemas using a predicate mapping JSON")
    sub = ap.add_subparsers(dest='cmd', required=True)

    p_dir = sub.add_parser('dir', help='Map all *.txt rules in a directory')
    p_dir.add_argument('--src', required=True, help='Source directory (glob ok)')
    p_dir.add_argument('--map', required=True, help='JSON mapping file')
    p_dir.add_argument('--out', required=True, help='Output directory')
    p_dir.add_argument('--source-line-graph', default='', help='Optional source dataset line_graph.txt to validate input rules belong to source schema')
    p_dir.add_argument('--target-line-graph', default='', help='Optional target dataset line_graph.txt for validation')
    p_dir.add_argument('--strict-source', action='store_true', help='Keep only rules whose head exists in source predicates')
    p_dir.add_argument('--strict', action='store_true', help='Keep only mapped rules with head in target predicates')

    p_file = sub.add_parser('file', help='Map a single rule file')
    p_file.add_argument('--src', required=True, help='Source rule file')
    p_file.add_argument('--map', required=True, help='JSON mapping file')
    p_file.add_argument('--out', required=True, help='Output file')
    p_file.add_argument('--source-line-graph', default='', help='Optional source dataset line_graph.txt to validate input rule belongs to source schema')
    p_file.add_argument('--target-line-graph', default='', help='Optional target dataset line_graph.txt for validation')
    p_file.add_argument('--strict-source', action='store_true')
    p_file.add_argument('--strict', action='store_true')

    p_match = sub.add_parser('match', help='Compute a predicate mapping from source schema to target schema')
    p_match.add_argument('--src-line-graph', required=True, help='Source line_graph.txt')
    p_match.add_argument('--tgt-line-graph', required=True, help='Target line_graph.txt')
    p_match.add_argument('--out', required=True, help='Output JSON mapping path')
    p_match.add_argument('--model', default='all-MiniLM-L6-v2', help='SentenceTransformer model (optional)')
    p_match.add_argument('--top_k', type=int, default=1, help='Max targets per source predicate')
    p_match.add_argument('--threshold', type=float, default=0.35, help='Similarity threshold to keep a mapping')

    p_report = sub.add_parser('report', help='Summarize a saved mapping JSON')
    p_report.add_argument('--mapping', required=True, help='Path to mappings JSON (classes+predicates or predicates only)')
    p_report.add_argument('--limit', type=int, default=10, help='How many sample entries to show per section')

    args = ap.parse_args()
    if args.cmd == 'match':
        mapping = compute_schema_mapping(args.src_line_graph, args.tgt_line_graph, model_name=args.model, top_k=args.top_k, threshold=args.threshold)
        save_mapping(mapping, args.out)
        print(f"Saved mapping to {args.out}")
        return
    if args.cmd == 'report':
        p = Path(args.mapping)
        if not p.exists():
            raise SystemExit(f"Mapping file not found: {p}")
        import json
        data = json.loads(p.read_text(encoding='utf-8', errors='ignore'))
        if "classes" in data or "predicates" in data:
            classes = data.get('classes', {})
            preds = data.get('predicates', {})
            print(f"Classes mapped: {len(classes)}")
            for i, (k, v) in enumerate(classes.items()):
                if i >= args.limit:
                    break
                print(f"  {k} -> {v}")
            print(f"Predicates mapped: {len(preds)}")
            for i, (k, v) in enumerate(preds.items()):
                if i >= args.limit:
                    break
                print(f"  {k} -> {v}")
        else:
            print(f"Predicates mapped: {len(data)}")
            for i, (k, v) in enumerate(data.items()):
                if i >= args.limit:
                    break
                print(f"  {k} -> {v}")
        return

    pred_map = load_mapping(args.map)
    target_preds: List[str] = []
    source_preds: List[str] = []
    if getattr(args, 'target_line_graph', ''):
        target_preds = read_target_predicates_from_line_graph(args.target_line_graph)
    if getattr(args, 'source_line_graph', ''):
        source_preds = read_target_predicates_from_line_graph(args.source_line_graph)

    if args.cmd == 'dir':
        out_dir = Path(args.out)
        out_dir.mkdir(parents=True, exist_ok=True)
        paths: List[Path] = []
        p = Path(args.src)
        if '*' in args.src or '?' in args.src or '[' in args.src:
            paths = [Path(x) for x in sorted(list(p.parent.glob(p.name)))]
        else:
            paths = [pp for pp in p.iterdir() if pp.suffix.lower() == '.txt'] if p.is_dir() else ([p] if p.exists() else [])
        if not paths:
            raise SystemExit(f"No input files found under {args.src}")
        for f in paths:
            mapped = map_file(f, pred_map, target_preds, args.strict, source_preds, args.strict_source)
            if not mapped:
                continue
            out_path = out_dir / f.name
            out_path.write_text('\n'.join(mapped) + '\n', encoding='utf-8')
            print(f"Wrote {out_path} with {len(mapped)} mapped rules")
    else:  # file
        src = Path(args.src)
        mapped = map_file(src, pred_map, target_preds, args.strict, source_preds, args.strict_source)
        Path(args.out).write_text('\n'.join(mapped) + '\n', encoding='utf-8')
        print(f"Wrote {args.out} with {len(mapped)} mapped rules")


if __name__ == '__main__':
    main()
