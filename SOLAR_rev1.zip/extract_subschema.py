import os

from data import *


def parse_schema(schema):
    """Parse schema string into nodes and edges."""
    nodes_section = False
    edges_section = False
    nodes = []
    edges = []

    for line in schema.strip().splitlines():
        line = line.strip()
        if line == "<nodes>":
            nodes_section = True
            continue
        elif line == "</nodes>":
            nodes_section = False
            continue
        elif line == "<edges>":
            edges_section = True
            continue
        elif line == "</edges>":
            edges_section = False
            continue

        if nodes_section and line:
            nodes.append(line)
        elif edges_section and line:
            # Parse edge while preserving the relationship type
            line = line.strip("[]")
            src, rel, dst = [item.strip() for item in line.split(",")]
            edges.append([src, rel, dst])

    return nodes, edges


def build_graph(edges):
    """Build directed graph with edge information."""
    graph = defaultdict(list)
    edge_info = {}  # Store edge relationship types

    for src, rel, dst in edges:
        graph[src].append(dst)
        edge_info[(src, dst)] = rel

    return graph, edge_info


def bfs_paths(graph, start_node, max_length):
    """BFS to find all paths up to max_length."""
    visited_paths = set()
    queue = deque([(start_node, [start_node], 0)])
    all_paths = []

    while queue:
        current_node, path, depth = queue.popleft()

        if depth <= max_length:
            all_paths.append(path)

            if depth < max_length:
                for neighbor in graph[current_node]:
                    new_path = path + [neighbor]
                    path_key = tuple(new_path)

                    if path_key not in visited_paths:
                        visited_paths.add(path_key)
                        queue.append((neighbor, new_path, depth + 1))

    return all_paths


def extract_subgraph_edges(paths, edge_info):
    """Extract edges from paths while preserving relationship types."""
    subgraph_edges = set()

    for path in paths:
        for i in range(len(path) - 1):
            src, dst = path[i], path[i + 1]
            rel = edge_info.get((src, dst))
            if rel:
                subgraph_edges.add((src, rel, dst))

    return subgraph_edges


def extract_subschema(schema, input_predicate, max_length):
    """Extract subschema centered on input_predicate up to max_length."""
    nodes, edges = parse_schema(schema)
    graph, edge_info = build_graph(edges)

    # Find all paths starting from input_predicate
    all_paths = bfs_paths(graph, input_predicate, max_length)

    # Extract relevant edges with relationship types
    subgraph_edges = extract_subgraph_edges(all_paths, edge_info)

    # Collect nodes that appear in the subgraph
    nodes_in_subgraph = {node.split("[")[0] for edge in subgraph_edges for node in (edge[0], edge[2])}
    sub_nodes = [node for node in nodes if node.split("[")[0] in nodes_in_subgraph]

    # Format subschema
    sub_nodes_str = "<nodes>\n" + "\n".join(sorted(sub_nodes)) + "\n</nodes>"
    sub_edges_str = "<edges>\n" + "\n".join(
        f"[{src}, {rel}, {dst}]" for src, rel, dst in sorted(subgraph_edges)) + "\n</edges>"

    return subgraph_edges,  sub_nodes_str + "\n" + sub_edges_str


def printRules(head, paths):
    print("Possible rule bodies:")
    seen_rules = set()  # To avoid duplicate rules
    for path in paths:
        rule_body = format_rule_body(path)
        if rule_body not in seen_rules:
            print(f"{head} <- {rule_body}")
            seen_rules.add(rule_body)


def format_rule_body(path):
    """Format a path as a logical rule body."""
    # Create variable mappings
    var_mapping = {}
    var_counter = 0
    rule_parts = []

    for src, dst, pred in path:
        # Create/get variables for source and destination
        if src not in var_mapping:
            var_mapping[src] = f'X{var_counter}'
            var_counter += 1
        if dst not in var_mapping:
            var_mapping[dst] = f'X{var_counter}'
            var_counter += 1

        # Format predicate with variables
        rule_parts.append(f"{pred}({var_mapping[src]},{var_mapping[dst]})")

    return ', '.join(rule_parts)


def find_paths_length_2(graph, edge_info, target_predicate='almaMater'):
    """Find all possible paths of length 2 that could form rule bodies."""
    paths = []
    # For each starting node in the graph
    for start in graph:
        # Get middle nodes
        for mid in graph[start]:
            # Get edge type for first hop
            first_hop_type = edge_info.get((start, mid))
            if first_hop_type == target_predicate:
                continue

            # Get end nodes
            for end in graph[mid]:
                # Get edge type for second hop
                second_hop_type = edge_info.get((mid, end))
                if second_hop_type == target_predicate:
                    continue

                # Store the path with its predicates
                path = [
                    (start, mid, first_hop_type),
                    (mid, end, second_hop_type)
                ]
                paths.append(path)

    return paths


def test_extractor(schema, predicate, depth):
    """Test the subschema extractor with sample data."""
    result = extract_subschema(schema, input_predicate=predicate, max_length=depth)
    print(f'Extracted subschema for the input predicate {predicate}:')
    print(result)


def format_rule(path, head_predicate='almaMater'):
    """Format a path as a logical rule."""
    variables = {}
    var_counter = 0

    # Format each predicate in the path
    rule_parts = []
    for src, dst, pred in path:
        # Assign variables if not already assigned
        if src not in variables:
            variables[src] = f'X{var_counter}'
            var_counter += 1
        if dst not in variables:
            variables[dst] = f'X{var_counter}'
            var_counter += 1

        rule_parts.append(f"{pred}({variables[src]},{variables[dst]})")

    body = ', '.join(rule_parts)
    return f"{head_predicate}(X,Y) <- {body}"


if __name__ == "__main__":
    data_path = "/Volumes/DATI/" + "GitHub/SOLAR/dataset"
    dataset_name = "schemadotorg"
    # Prompts now live under <repo_root>/prompt/
    repo_root = os.path.abspath(os.path.join(data_path, os.pardir))
    prompt_path = os.path.join(repo_root, "prompt") + "/"
    data_path = os.path.join(data_path, data_path) + "/" + dataset_name + "/"
    schema_type = "line"

    ###
    head = "workFeatured"
    rule_lenght = 2
    dataset = Dataset(data_root=data_path, prompt_path=prompt_path, dataset_name=dataset_name)
    schema = dataset.read_schema(schema_type)

    nodes, edges = parse_schema(schema)
    graph, edge_info = build_graph(edges)

    head_centered_subschema = extract_subschema(schema, input_predicate=head, max_length=rule_lenght)

    print(head_centered_subschema)
    exit()
    # Find and format paths
    paths = find_paths_length_2(graph, edge_info, target_predicate=head)
    seen_rules = set()
    print("Generated Rules:")
    for path in paths:
        rule = format_rule(path, head_predicate=head)
        if rule not in seen_rules:
            print(rule)
            seen_rules.add(rule)

# test_extractor(schema,predicate="almaMater",depth=1)
