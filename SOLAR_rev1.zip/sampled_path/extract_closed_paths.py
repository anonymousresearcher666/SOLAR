#!/usr/bin/env python3
"""
extract_closed_paths.py

Script to extract bounded-length relational paths between subject-object pairs for each predicate in a knowledge graph dataset.
Generates a JSONL file of entries:
  {"head": predicate_name, "paths": ["p1|p2|...", ...]}

Works for datasets with either textual facts.txt (predicate names) or numeric facts.txt (predicate IDs),
using rel2id.pkl for ID-to-name mapping when available.
"""
import argparse
import json
import pickle
from collections import defaultdict, deque
from pathlib import Path
import os

def load_graph(dataset_dir):
    """
    Load triples from facts.txt and build a bidirectional graph.
    Returns:
      graph: dict[node, list of (relation, neighbor)]
      edges: dict[relation, list of (subject, object)]
    """
    facts_path = dataset_dir / "facts.txt"
    if not facts_path.exists():
        raise FileNotFoundError(f"Missing facts.txt in {dataset_dir}")

    # Detect numeric vs textual predicates
    first = facts_path.open().readline().strip().split()
    is_numeric = all(tok.isdigit() for tok in first) and len(first) == 3

    # Prepare ID-to-relation mapping if numeric
    id2rel = {}
    if is_numeric:
        rel2id_pkl = dataset_dir / "scripts" / "rel2id.pkl"
        if not rel2id_pkl.exists():
            raise FileNotFoundError(f"Expected relation ID mapping at {rel2id_pkl}")
        rel2id = pickle.load(rel2id_pkl.open('rb'))
        # invert mapping
        id2rel = {v: k for k, v in rel2id.items()}

    graph = defaultdict(list)
    edges = defaultdict(list)
    with facts_path.open() as f:
        for line in f:
            toks = line.strip().split()
            if len(toks) != 3:
                continue
            s0, p0, o0 = toks
            if is_numeric:
                s, p, o = int(s0), int(p0), int(o0)
                rel = id2rel.get(p, str(p))
            else:
                s, rel, o = s0, p0, o0
            # record directed edge
            graph[s].append((rel, o))
            # record inverse edge
            inv = f"inv_{rel}"
            graph[o].append((inv, s))
            # track original edges for head predicates
            edges[rel].append((s, o))
    return graph, edges

def find_paths(graph, start, end, max_length):
    """
    Find simple paths of exactly max_length edges from start to end.
    Returns list of relation-sequence strings (with '|' sep).
    """
    results = set()
    # DFS stack: (current_node, depth_left, path_so_far, visited_set)
    stack = [(start, max_length, [], {start})]
    while stack:
        node, d, path, visited = stack.pop()
        if d == 0:
            if node == end:
                results.add("|".join(path))
            continue
        for rel, nbr in graph.get(node, []):
            if nbr in visited:
                continue
            stack.append((nbr, d-1, path + [rel], visited | {nbr}))
    return list(results)

def main():
    parser = argparse.ArgumentParser(
        description="Extract bounded-length relational paths for each predicate"
    )
    parser.add_argument(
        "--dataset",
        default="fb15k187",
        help="Dataset name under data-dir/ (default: fb15k187)"
    )
    parser.add_argument(
        "--data-dir",
        default="dataset",
        help="Root directory where datasets are stored"
    )
    parser.add_argument(
        "--max-length",
        type=int,
        default=3,
        help="Exact number of hops in each path (default: 3)"
    )
    parser.add_argument(
        "--max-pairs",
        type=int,
        default=100,
        help="Max number of subject-object pairs per predicate to sample"
    )
    parser.add_argument(
        "--limit",
        type=int,
        default=50,
        help="Max number of paths to record per predicate"
    )
    parser.add_argument(
        "--output",
        help="Output JSONL file path"
    )
    args = parser.parse_args()

    # Resolve data root robustly: support relative to CWD or repo root
    def get_repo_root() -> Path:
        env = os.environ.get("REPO_ROOT")
        if env:
            return Path(env).resolve()
        # this file lives under <repo_root>/sampled_path
        return Path(__file__).resolve().parents[1]

    raw_data_root = Path(args.data_dir)
    candidates = []
    # Absolute path
    if raw_data_root.is_absolute():
        candidates.append(raw_data_root)
    else:
        candidates.append(Path.cwd() / raw_data_root)
        candidates.append(get_repo_root() / raw_data_root)
    data_root = next((p for p in candidates if p.exists()), candidates[-1])

    dataset_dir = data_root / args.dataset
    if not dataset_dir.exists():
        # Try one more fallback: if args.dataset looks like nested path already
        alt = get_repo_root() / args.dataset
        if alt.exists():
            dataset_dir = alt
        else:
            tried = ", ".join(str(p / args.dataset) for p in candidates)
            raise FileNotFoundError(f"Dataset directory not found: {dataset_dir}. Tried: {tried}")

    # Load original graph (with full predicate names)
    graph_orig, edges_orig = load_graph(dataset_dir)
    # Ensure stripped predicate mapping exists in dataset directory
    mapping_path = dataset_dir / 'predicate_stripped_map.json'
    if mapping_path.exists():
        orig2str = json.loads(mapping_path.read_text(encoding='utf-8'))
    else:
        # Build mapping original->stripped (take last segment after '/')
        orig2str = {rel: rel.split('/')[-1] for rel in edges_orig.keys()}
        # Save mapping for future reuse
        mapping_path.write_text(json.dumps(orig2str, ensure_ascii=False, indent=2), encoding='utf-8')

    # Build stripped-edge lists and graph
    graph = defaultdict(list)
    edges = defaultdict(list)
    for orig_rel, pairs in edges_orig.items():
        stripped_rel = orig2str.get(orig_rel, orig_rel.split('/')[-1])
        # collect direct edges under stripped head
        for s, o in pairs:
            edges[stripped_rel].append((s, o))
            # directed graph with inverse edges
            graph[s].append((stripped_rel, o))
            graph[o].append((f'inv_{stripped_rel}', s))

    # Determine output path
    out_file = Path(args.output) if args.output else Path(args.data_dir) / 'sampled_path' / args.dataset / 'closed_rel_paths.jsonl'
    out_file.parent.mkdir(parents=True, exist_ok=True)

    with out_file.open('w') as wf:
        for head, pairs in edges.items():
            # sample a limited number of pairs
            sample_pairs = pairs[: args.max_pairs]
            paths = set()
            for s, o in sample_pairs:
                ps = find_paths(graph, s, o, args.max_length)
                for p in ps:
                    paths.add(p)
                    if len(paths) >= args.limit:
                        break
                if len(paths) >= args.limit:
                    break
            if paths:
                entry = {"head": head, "paths": list(paths)}
                wf.write(json.dumps(entry) + "\n")
                print(f"Head {head}: extracted {len(paths)} paths")
    print(f"Done. Paths written to {out_file}")

if __name__ == '__main__':
    main()
