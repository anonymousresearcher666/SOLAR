"""Quality LLM utilities: rule extraction and schema-based evaluation."""

