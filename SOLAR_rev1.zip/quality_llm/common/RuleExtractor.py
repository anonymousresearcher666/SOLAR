#!/usr/bin/env python3
"""
Rule Extractor Script - WITH JUSTIFICATIONS
Extracts logical rules and their justifications from all files in a specified folder.
Rules should be in format: "RULE X: head(X,Y) :- body1(X,Z), body2(Z,Y)"
Followed by: "Justification: explanation text..."
"""

import os
import re
import argparse
from pathlib import Path
from collections import defaultdict
import csv
import json


class RuleExtractor:
    def __init__(self, folder_path, output_format='txt'):
        self.folder_path = Path(folder_path)
        self.output_format = output_format.lower()
        self.rules_data = []
        self.stats = defaultdict(int)

        # Regex pattern to match rules, tolerant to markdown prefixes (e.g., '### RULE')
        # Matches variants like:
        #   'RULE 1: head(X,Y) :- body(...)'
        #   '### RULE 1: head(X,Y) :- body(...)'
        #   'assistant: ### RULE 1: head(X,Y) :- body(...)'
        self.rule_pattern = re.compile(
            r"(?:^|\n)\s*(?:assistant:\s*)?(?:[#>*\-\s]*)?RULE\s+(\d+):\s*([^\n:]+?)\s*:-\s*(.+)",
            re.IGNORECASE | re.MULTILINE
        )

        # Pattern to extract predicate name from rule head
        self.predicate_pattern = re.compile(r'(\w+)\s*\([^)]+\)')

        # Fallback heuristic: capture head(args) <arrow> body possibly across wrapped lines
        # Accept arrows: ':-', '<-', '<=', '⇐', '←'
        self.arrow_variants = [':-', '<-', '<=', '⇐', '←']

        # Pattern to match justifications, tolerant to markdown bolding
        # Matches: 'Justification: ...' or '**Justification:** ...'
        self.justification_pattern = re.compile(
            r"(?:\*\*)?Justification:(?:\*\*)?\s*(.+?)(?=\n\s*(?:[#>*\-\s]*RULE\s+\d+:|\Z))",
            re.IGNORECASE | re.DOTALL
        )

    def extract_predicate_from_filename(self, filename):
        """Extract predicate name from filename."""
        name_without_ext = filename.replace('.txt', '')
        if '_' not in name_without_ext and '-' not in name_without_ext:
            return name_without_ext
        if '_' in name_without_ext:
            parts = name_without_ext.split('_')
            for part in parts:
                if part and not part.isdigit():
                    return part
        if '-' in name_without_ext:
            parts = name_without_ext.split('-')
            for part in parts:
                if part and not part.isdigit():
                    return part
        return name_without_ext

    def extract_rules_from_file(self, file_path):
        rules_found = []
        file_predicate = self.extract_predicate_from_filename(file_path.name)
        try:
            for encoding in ['utf-8', 'latin-1', 'cp1252']:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        content = f.read()
                    break
                except UnicodeDecodeError:
                    continue
            else:
                print(f"Warning: Could not decode {file_path}")
                return rules_found

            # First, try RULE N: ... pattern
            rule_sections = re.split(r'(?=(?:[#>*\-\s]*RULE\s+\d+:))', content, flags=re.IGNORECASE)
            for section in rule_sections:
                if not section.strip():
                    continue
                rule_matches = self.rule_pattern.findall(section)
                if rule_matches:
                    for match in rule_matches:
                        rule_number = match[0]
                        rule_head = match[1].strip()
                        rule_body = match[2].strip()

                        def _clean_md(text: str) -> str:
                            t = text.strip()
                            t = t.replace('**', '').replace('`', '')
                            t = t.strip('*').strip('#')
                            t = re.sub(r"\s+", " ", t)
                            return t

                        rule_head = _clean_md(rule_head)
                        rule_body = _clean_md(rule_body)

                        pred_match = self.predicate_pattern.match(rule_head)
                        head_predicate = pred_match.group(1) if pred_match else "unknown"

                        justification = ""
                        justification_matches = self.justification_pattern.findall(section)
                        if justification_matches:
                            justification = justification_matches[0].strip()
                            justification = re.sub(r'\s+', ' ', justification)
                            justification = justification.replace('\n', ' ').strip()

                        rule_data = {
                            'file': file_path.name,
                            'file_predicate': file_predicate,
                            'rule_number': int(rule_number),
                            'head_predicate': head_predicate,
                            'head': rule_head,
                            'body': rule_body,
                            'full_rule': f"{rule_head} :- {rule_body}",
                            'justification': justification,
                            'original_line': f"RULE {rule_number}: {rule_head} :- {rule_body}"
                        }
                        rules_found.append(rule_data)
                        self.stats['total_rules'] += 1
                        self.stats[f'file_predicate_{file_predicate}'] += 1
                        self.stats[f'head_predicate_{head_predicate}'] += 1
                        if justification:
                            self.stats['rules_with_justifications'] += 1

            # If no RULE pattern rules found, apply heuristic extraction directly from lines
            if not rules_found:
                lines = content.splitlines()
                i = 0
                rule_idx = 1
                while i < len(lines):
                    raw = lines[i]
                    line = raw.strip()
                    # Strip bullets/numbering
                    line = re.sub(r'^\s*(?:\d+[.)]\s*|[-*+]\s*)', '', line)
                    # Merge wrapped bodies across next lines until termination or blank/new item
                    merged = line
                    j = i + 1
                    while j < len(lines):
                        nxt = lines[j].strip()
                        if not nxt:
                            break
                        # Stop on new likely rule head start
                        if re.match(r'^\s*(?:\d+[.)]\s*|[-*+]\s*)?\w+\s*\([^)]*\)\s*(?::-|<=|<-|⇐|←)', nxt):
                            break
                        # Continue body if previous ends with comma or conjunction or no period
                        if (merged and (merged.endswith(',') or merged.endswith('∧') or not merged.endswith('.'))):
                            merged += ' ' + nxt
                            j += 1
                            continue
                        break

                    def _has_rule_shape(s: str) -> bool:
                        return (re.search(r'\w+\s*\([^)]*\)', s) is not None and
                                any(a in s for a in self.arrow_variants))

                    if _has_rule_shape(merged):
                        # split head/body on first arrow occurrence
                        arrow_pos = None
                        arrow = None
                        for a in self.arrow_variants:
                            k = merged.find(a)
                            if k != -1 and (arrow_pos is None or k < arrow_pos):
                                arrow_pos = k
                                arrow = a
                        if arrow is not None and arrow_pos is not None:
                            head = merged[:arrow_pos].strip()
                            body = merged[arrow_pos + len(arrow):].strip()
                            head = re.sub(r'^\s*(?:\d+[.)]\s*|[-*+]\s*)', '', head)
                            head = head.replace('**', '').replace('`', '').strip('*').strip('#')
                            body = body.replace('**', '').replace('`', '').strip('*').strip('#')
                            body = re.sub(r'\s+', ' ', body)
                            pred_match = self.predicate_pattern.match(head)
                            head_predicate = pred_match.group(1) if pred_match else "unknown"
                            rule_data = {
                                'file': file_path.name,
                                'file_predicate': file_predicate,
                                'rule_number': int(rule_idx),
                                'head_predicate': head_predicate,
                                'head': head,
                                'body': body,
                                'full_rule': f"{head} :- {body}",
                                'justification': '',
                                'original_line': merged
                            }
                            rules_found.append(rule_data)
                            self.stats['total_rules'] += 1
                            self.stats[f'file_predicate_{file_predicate}'] += 1
                            self.stats[f'head_predicate_{head_predicate}'] += 1
                            rule_idx += 1
                        i = j
                        continue
                    i += 1

            if rules_found:
                self.stats['files_with_rules'] += 1
                justified_count = sum(1 for r in rules_found if r['justification'])
                print(f"Found {len(rules_found)} rules for predicate '{file_predicate}' in {file_path.name} ({justified_count} with justifications)")
            else:
                print(f"No rules found in {file_path.name} (predicate: {file_predicate})")
        except Exception as e:
            print(f"Error processing {file_path}: {e}")
        return rules_found

    def process_folder(self):
        if not self.folder_path.exists():
            print(f"Error: Folder {self.folder_path} does not exist")
            return
        print(f"Processing .txt files in: {self.folder_path}")
        txt_files = [f for f in self.folder_path.iterdir() if f.is_file() and f.suffix.lower() == '.txt']
        if not txt_files:
            print("No .txt files found in the folder")
            return
        print(f"Found {len(txt_files)} .txt files to process")
        self.stats['total_files'] = len(txt_files)
        for file_path in sorted(txt_files):
            print(f"Processing: {file_path.name}")
            rules = self.extract_rules_from_file(file_path)
            self.rules_data.extend(rules)
        print(f"\nProcessing complete!")
        print(f"Total .txt files processed: {self.stats['total_files']}")
        print(f"Files with rules: {self.stats['files_with_rules']}")
        print(f"Total rules extracted: {self.stats['total_rules']}")
        print(f"Rules with justifications: {self.stats.get('rules_with_justifications', 0)}")

    def get_file_predicate_stats(self):
        predicate_counts = {}
        for key, value in self.stats.items():
            if key.startswith('file_predicate_'):
                predicate = key.replace('file_predicate_', '')
                predicate_counts[predicate] = value
        return predicate_counts

    def get_head_predicate_stats(self):
        predicate_counts = {}
        for key, value in self.stats.items():
            if key.startswith('head_predicate_'):
                predicate = key.replace('head_predicate_', '')
                predicate_counts[predicate] = value
        return predicate_counts

    # The remaining methods (save_results, save_txt, save_csv, etc.) are unchanged from the original file
    # For brevity, include the original full content in your repository.
