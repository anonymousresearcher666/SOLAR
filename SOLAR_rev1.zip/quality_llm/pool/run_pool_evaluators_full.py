#!/usr/bin/env python3
import argparse
import os
from pathlib import Path
from typing import Dict, List, Tuple, Optional

try:
    from llm import call_models
except Exception:
    # Fallback if run as a script outside package context
    import sys
    repo_root = Path(__file__).resolve().parents[2]
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))
    from llm import call_models  # type: ignore


def parse_dataset_from_pool_dir(pool_dir: Path) -> str:
    parts = pool_dir.parts
    if 'gen_rules' in parts:
        i = parts.index('gen_rules')
        if i + 1 < len(parts):
            return parts[i + 1]
    # Fallback: try parent of prompts later
    return ''


def load_pool_prompt(dataset_root: Path, dataset: str) -> str:
    """Load the SPCA^{pool} prompt with robust fallbacks.

    New convention: prompts live under <repo_root>/prompt/ and NOT under dataset_name.
    Fallbacks cover historical layouts.
    """
    candidates = []
    try:
        repo_root = Path(__file__).resolve().parents[2]
    except Exception:
        repo_root = Path.cwd()

    # Primary: <repo_root>/prompt/spca_pool_prompt.txt
    candidates.append(repo_root / 'prompt' / 'spca_pool_prompt.txt')
    # If dataset_root is <repo_root>/dataset or similar, try its parent
    candidates.append(dataset_root.parent / 'prompt' / 'spca_pool_prompt.txt')
    # Legacy fallbacks
    candidates.append(dataset_root / 'prompt' / 'spca_pool_prompt.txt')                    # if dataset_root already at dataset
    candidates.append(dataset_root / dataset / 'prompt' / 'spca_pool_prompt.txt')         # old layout

    for p in candidates:
        if p.exists():
            return p.read_text(encoding='utf-8')

    raise SystemExit(
        "Pool prompt not found. Tried: " + ", ".join(str(p) for p in candidates) +
        f" (cwd={Path.cwd()})"
    )


class SafeFormatDict(dict):
    def __missing__(self, key):
        return '{' + key + '}'


def build_numbering_prompt(agent_id: int, enumerated_rules: List[str], schema_text: str) -> str:
    """Build a ranking-only prompt using numbered candidates.

    - Presents candidates as indexed list: 1) <rule>, 2) <rule>, ...
    - Asks for ONLY the ranking of indices, best→worst, as a single line
      permutation (e.g., "3 1 2") or a JSON array (e.g., [3,1,2]).
    - Includes schema once as optional context.
    """
    rubric = (
        "Ranking rubric (apply in this order):\n"
        "1) Schema-consistency/safety (domain-range, head vars appear in body).\n"
        "2) Plausibility relative to KG semantics.\n"
        "3) Specificity vs. generality (coverage vs. spurious matches).\n"
        "4) Simplicity as tie-breaker.\n"
    )
    guard = (
        f"You are Evaluator #{agent_id}.\n"
        "Rank the candidate Horn rules using ONLY the provided rules and schema.\n"
        "Constraints:\n"
        "- Do NOT generate, modify, or invent new rules.\n"
        "- Rank ALL candidates; include each index exactly once (total order).\n"
        "Output format (choose one):\n"
        "- Single line permutation:  e.g.,  3 1 2 4\n"
        "- Or JSON array of indices: e.g., [3,1,2,4]\n"
        "No commentary or extra text.\n"
        f"\n{rubric}\n"
    )
    parts = [guard]
    lines = [f"{i+1}) {r}" for i, r in enumerate(enumerated_rules)]
    parts.append("Candidate Rules (indexed):\n" + "\n".join(lines) + "\n")
    if schema_text.strip():
        parts.append("Schema Context:\n" + schema_text.strip() + "\n")
    parts.append("Return ONLY the ranking of indices as specified above.")
    return "\n".join(parts)


def parse_index_ranking(text: str, n: int) -> List[int]:
    """Parse a ranking of indices from model output. Returns [] if not a full permutation.

    Accepts: JSON array, or a single line with indices separated by spaces/commas/'>'.
    """
    import json as _json
    import re as _re
    cleaned = text.strip()
    # Try JSON
    try:
        data = _json.loads(cleaned)
        if isinstance(data, list) and all(isinstance(x, int) for x in data):
            arr = [int(x) for x in data]
        elif isinstance(data, dict) and 'ranking' in data and isinstance(data['ranking'], list):
            arr = [int(x) for x in data['ranking']]
        else:
            arr = []
    except Exception:
        # Fallback to line with separators
        line = cleaned.splitlines()[0] if cleaned else ''
        tokens = _re.split(r"[\s,>]+", line.strip()) if line else []
        arr = []
        for t in tokens:
            if t.isdigit():
                arr.append(int(t))
    # Validate permutation
    if len(arr) == n and sorted(arr) == list(range(1, n+1)):
        return arr
    return []


def find_candidates(pool_dir: Path) -> Tuple[Path, List[str]]:
    # Expect Coordinator_<coord> dir containing *_candidates.rules
    coord_dirs = [p for p in pool_dir.iterdir() if p.is_dir() and p.name.startswith('Coordinator_')]
    if not coord_dirs:
        raise SystemExit(f"No Coordinator_* directory found in {pool_dir}")
    coord_dir = coord_dirs[0]
    preds = []
    for rf in coord_dir.glob('*_candidates.rules'):
        stem = rf.name[:-len('_candidates.rules')]
        preds.append(stem)
    if not preds:
        raise SystemExit(f"No *_candidates.rules files found in {coord_dir}")
    return coord_dir, sorted(preds)


def create_agents(agent_models: List[str]) -> Dict[str, object]:
    """Create a pool of evaluator LLMs using llm/call_models.py helper."""
    try:
        return call_models.create_agent_llms(agent_models)
    except Exception:
        # Fallback: construct manually
        agents: Dict[str, object] = {}
        for i, model_name in enumerate(agent_models, start=1):
            name = f"Agent{i}_{model_name}"
            agents[name] = call_models.create_llm(model_name)
        return agents


def evaluate_pool(pool_dir: Path, dataset_root: Path, agent_models: List[str], *, do_borda: bool = True,
                  out_csv: Optional[Path] = None) -> None:
    dataset = parse_dataset_from_pool_dir(pool_dir)
    pool_prompt = load_pool_prompt(dataset_root, dataset)
    coord_dir, predicates = find_candidates(pool_dir)
    agents = create_agents(agent_models)

    for pred in predicates:
        rules_file = coord_dir / f"{pred}_candidates.rules"
        schema_file = coord_dir / f"{pred}_schema.txt"
        rules_text = rules_file.read_text(encoding='utf-8') if rules_file.exists() else ''
        schema_text = schema_file.read_text(encoding='utf-8') if schema_file.exists() else ''
        # Prepare enumerated rules and candidate list
        candidates = [ln.strip() for ln in rules_text.splitlines() if ln.strip()]

        for i, (agent_name, agent_llm) in enumerate(agents.items(), start=1):
            # Prepare ranking prompt with indices (no generation)
            prompt = build_numbering_prompt(i, candidates, schema_text)
            # Persist prompt and response in a dedicated Agent directory under the pool root
            agent_dir = pool_dir / agent_name
            agent_dir.mkdir(parents=True, exist_ok=True)
            (agent_dir / f"{pred}_pool.query").write_text(prompt, encoding='utf-8')
            response = call_models.query_remote_llm(prompt, llm=agent_llm)
            raw_text = str(response)
            (agent_dir / f"{pred}_pool.raw.txt").write_text(raw_text, encoding='utf-8')
            # Try to parse index ranking to normalized rule list; otherwise keep raw
            order = parse_index_ranking(raw_text, len(candidates))
            if order:
                ordered_rules = [candidates[k - 1] for k in order]
                (agent_dir / f"{pred}_pool.txt").write_text("\n".join(ordered_rules), encoding='utf-8')
            else:
                # Fallback: save raw text also to _pool.txt for backward heuristics
                (agent_dir / f"{pred}_pool.txt").write_text(raw_text, encoding='utf-8')

    # After all evaluators produced rankings, run Borda aggregation (with cleaning inside aggregator)
    if do_borda:
        csv_path = out_csv if out_csv else (pool_dir / 'aggregated_pool.csv')
        borda_aggregate(pool_dir, csv_path)


def borda_aggregate(pool_dir: Path, out_csv: Path = None) -> None:
    # Reuse the aggregator helper
    try:
        # Relative import when used as a package
        from .pool_borda import collect_agent_rankings, borda_aggregate
    except Exception:
        try:
            # Running directly from pool/ directory
            THIS_DIR = Path(__file__).resolve().parent
            import sys as _sys
            if str(THIS_DIR) not in _sys.path:
                _sys.path.insert(0, str(THIS_DIR))
            from pool_borda import collect_agent_rankings, borda_aggregate  # type: ignore
        except Exception:
            # Absolute import when run as a script outside package
            from quality_llm.pool.pool_borda import collect_agent_rankings, borda_aggregate  # type: ignore

    preds, rankings = collect_agent_rankings(pool_dir)
    if not preds:
        print(f"No agent rankings found under {pool_dir}")
        return

    rows = []
    for pred in preds:
        scores = borda_aggregate(rankings.get(pred, {}))
        rows.extend([[pred, r, f"{s:.6f}"] for r, s in sorted(scores.items(), key=lambda kv: kv[1], reverse=True)])

    # Print a short summary
    print("predicate\trule\tborda_score")
    for row in rows[:50]:
        print("\t".join(row))

    if out_csv:
        out_csv.parent.mkdir(parents=True, exist_ok=True)
        with open(out_csv, 'w', encoding='utf-8') as f:
            f.write('predicate,rule,borda_score\n')
            for row in rows:
                f.write(','.join(row) + '\n')
        print(f"Wrote aggregated pool scores to {out_csv}")


def main():
    ap = argparse.ArgumentParser(description='Run independent evaluators on pool candidates and aggregate via Borda.')
    ap.add_argument(
        'pool_dir', type=str, nargs='?', default='/Volumes/DATI/GitHub/SOLAR/gen_rules/yago/c2r_new/line/2/pool_ollama_qwen2.5:latest/',
        help='Path to pool_<coordinator_model> directory (Phase 1 outputs). Default: current directory'
    )
    ap.add_argument(
        '--dataset-root', type=str, default='',
        help='Dataset root for prompt/schema. Default: dataset'
    )
    ap.add_argument(
        '--agent-models', type=str, nargs='+',
        default=['ollama_deepseek-r1:1.5b', 'ollama_gemma3:27b'],
        help='Evaluator models to use. Default: three local ollama_* models'
    )
    ap.add_argument('--aggregate', action='store_true', help='[Deprecated] Aggregation runs by default')
    ap.add_argument(
        '--out', type=str, default='aggregated_pool.csv',
        help='CSV filename or absolute path for aggregated scores. Default: aggregated_pool.csv under pool_dir'
    )
    args = ap.parse_args()

    pool_path = Path(args.pool_dir)
    if not pool_path.exists():
        raise SystemExit(f"Pool directory not found: {pool_path}")

    dataset_root = Path(args.dataset_root)
    # Resolve out CSV: if relative, place under pool_dir
    out_csv = Path(args.out) if args.out else Path('aggregated_pool.csv')
    if not out_csv.is_absolute():
        out_csv = pool_path / out_csv.name
    evaluate_pool(pool_path, dataset_root, args.agent_models, do_borda=True, out_csv=out_csv)


if __name__ == '__main__':
    main()
