"""Pool-mode helpers: evaluators and aggregation."""

