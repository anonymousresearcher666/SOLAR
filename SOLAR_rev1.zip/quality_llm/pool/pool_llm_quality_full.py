#!/usr/bin/env python3
"""
Pool LLM Quality — Phase 2 entry point for SPCA^{pool}

Runs independent evaluators over the standardized candidate sets produced
by main_SOLAR.py (pool mode), then aggregates rankings via Borda count.

Usage (example):
  python -m quality_llm.pool.pool_llm_quality_full \
    gen_rules/yago/c2r_new/line/2/pool_ollama_llama3:latest \
    --dataset-root dataset \
    --agent-models ollama_qwen2.5:7b ollama_gemma:7b ollama_deepseek-r1:7b \
    --out aggregated_pool.csv
"""

import argparse
from pathlib import Path

try:
    from .run_pool_evaluators import evaluate_pool, borda_aggregate
except Exception:
    # Fallback 1: run directly from pool/
    try:
        import sys
        from pathlib import Path as _P
        _pkg = _P(__file__).resolve().parent
        if str(_pkg) not in sys.path:
            sys.path.insert(0, str(_pkg))
        from run_pool_evaluators import evaluate_pool, borda_aggregate  # type: ignore
    except Exception:
        # Fallback 2: repo root + package import
        import sys
        from pathlib import Path as _P
        _repo_root = _P(__file__).resolve().parents[2]
        if str(_repo_root) not in sys.path:
            sys.path.insert(0, str(_repo_root))
        from quality_llm.pool.run_pool_evaluators import evaluate_pool, borda_aggregate  # type: ignore


def main():
    ap = argparse.ArgumentParser(description='SPCA^{pool}: run evaluators on candidates and aggregate via Borda.')
    ap.add_argument('pool_dir', type=str, help='Path to pool_<coordinator> directory (Phase 1 outputs)')
    ap.add_argument('--dataset-root', type=str, default='dataset', help='Dataset root for prompt/schema')
    ap.add_argument('--agent-models', type=str, nargs='+', required=True, help='Evaluator models (independent assessors)')
    ap.add_argument('--out', type=str, default='', help='Optional CSV path for aggregated scores')
    args = ap.parse_args()

    pool_dir = Path(args.pool_dir)
    dataset_root = Path(args.dataset_root)

    # Phase 2: evaluate
    evaluate_pool(pool_dir, dataset_root, args.agent_models)

    # Aggregate with Borda
    out_csv = Path(args.out) if args.out else None
    borda_aggregate(pool_dir, out_csv)


if __name__ == '__main__':
    main()
