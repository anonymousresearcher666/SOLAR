#!/usr/bin/env python3
"""Entry point: run SPCA^{pool} evaluation + Borda aggregation."""

import sys
from pathlib import Path

try:
    # Run as package module
    from .pool_llm_quality_full import main as run
except Exception:
    # Run as script from repo root
    repo_root = Path(__file__).resolve().parents[2]
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))
    from quality_llm.pool.pool_llm_quality_full import main as run  # type: ignore


if __name__ == '__main__':
    run()
