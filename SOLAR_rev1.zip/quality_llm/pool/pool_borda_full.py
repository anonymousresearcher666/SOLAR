#!/usr/bin/env python3
import argparse
import json
import re
import csv
import os
import re
from pathlib import Path
from collections import defaultdict
from typing import Dict, List, Tuple


def parse_ranking_text(text: str) -> List[str]:
    """Extract an ordered list of rule strings from an agent's ranking text.
    Heuristics:
      - Prefer strict JSON: {"ranking": ["rule1", "rule2", ...]} or ["rule1", ...]
      - Otherwise, prefer lines that look like rules containing ':-'
      - Fallback: lines starting with a number/bullet and containing '(' and ')'
    """
    # 1) Try JSON parsing (strip code fences and whitespace)
    cleaned = text.strip()
    if cleaned.startswith("```") and cleaned.endswith("```"):
        cleaned = cleaned.strip('`')
    # Find the first JSON-looking segment
    try:
        # simple attempt: parse whole text
        data = json.loads(cleaned)
        if isinstance(data, dict) and 'ranking' in data and isinstance(data['ranking'], list):
            arr = [str(x).strip() for x in data['ranking'] if isinstance(x, str)]
            if arr:
                return arr
        if isinstance(data, list):
            arr = [str(x).strip() for x in data if isinstance(x, str)]
            if arr:
                return arr
    except Exception:
        # Try to extract JSON substring
        import re as _re
        m = _re.search(r"(\{.*\}|\[.*\])", cleaned, _re.DOTALL)
        if m:
            try:
                data = json.loads(m.group(1))
                if isinstance(data, dict) and 'ranking' in data and isinstance(data['ranking'], list):
                    arr = [str(x).strip() for x in data['ranking'] if isinstance(x, str)]
                    if arr:
                        return arr
                if isinstance(data, list):
                    arr = [str(x).strip() for x in data if isinstance(x, str)]
                    if arr:
                        return arr
            except Exception:
                pass

    rules = []
    # Split into lines and look for ':-'
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    for ln in lines:
        if ':-' in ln and '(' in ln and ')' in ln:
            rules.append(ln)
    if rules:
        return rules
    # Fallback: lines like '1) rule ...' or '- rule ...'
    pat = re.compile(r"^\s*(?:\d+\s*[\).:-]|[-*])\s*(.+)")
    for ln in lines:
        m = pat.match(ln)
        if m:
            candidate = m.group(1).strip()
            if '(' in candidate and ')' in candidate:
                rules.append(candidate)
    return rules


def _normalize_rule_text(s: str) -> str:
    """Normalize a rule string for matching.
    - Strip markdown artifacts (assistant:, ###, RULE n:, Rule n:, bullets)
    - Extract the first 'head(...) :- ...' segment if present
    - Collapse whitespace
    """
    t = s.strip()
    # Remove common prefixes
    t = re.sub(r"^(assistant:)?\s*", "", t, flags=re.IGNORECASE)
    t = re.sub(r"^[#*>\-\s]*", "", t)
    t = re.sub(r"^(?:RULE|Rule)\s*\d+\s*:\s*", "", t)
    # Extract head(...) :- body ...
    m = re.search(r"\b\w+\s*\([^)]+\)\s*:-\s*.+", t)
    if m:
        t = m.group(0)
    # Collapse whitespace
    t = re.sub(r"\s+", " ", t).strip()
    # Strip trailing punctuation that isn't part of rule
    t = t.rstrip(".;")
    return t


def _load_candidates(pool_dir: Path) -> Dict[str, Dict[str, str]]:
    """Load candidates per predicate from Coordinator_* folder.
    Returns mapping: pred -> { normalized_rule: original_rule } for exact mapping.
    """
    coord_dirs = [p for p in pool_dir.iterdir() if p.is_dir() and p.name.startswith('Coordinator_')]
    cand_map: Dict[str, Dict[str, str]] = {}
    if not coord_dirs:
        return cand_map
    coord_dir = coord_dirs[0]
    for rf in coord_dir.glob('*_candidates.rules'):
        pred = rf.name[:-len('_candidates.rules')]
        try:
            text = rf.read_text(encoding='utf-8', errors='ignore')
        except Exception:
            continue
        rules = [ln.strip() for ln in text.splitlines() if ln.strip()]
        norm_map: Dict[str, str] = {}
        for r in rules:
            norm_map[_normalize_rule_text(r)] = r
        cand_map[pred] = norm_map
    return cand_map


def _clean_to_candidates(pred: str, ranked_rules: List[str], cand_map: Dict[str, Dict[str, str]]) -> List[str]:
    """Map ranked textual lines to the canonical candidate rules for this predicate.
    Keeps order and removes duplicates; ignores lines that don't match any candidate.
    """
    mapping = cand_map.get(pred, {})
    seen = set()
    out: List[str] = []
    for line in ranked_rules:
        key = _normalize_rule_text(line)
        orig = mapping.get(key)
        if orig and orig not in seen:
            seen.add(orig)
            out.append(orig)
    return out


def _load_candidate_lists(pool_dir: Path) -> Dict[str, List[str]]:
    """Load candidate lists preserving original order for each predicate."""
    coord_dirs = [p for p in pool_dir.iterdir() if p.is_dir() and p.name.startswith('Coordinator_')]
    lists: Dict[str, List[str]] = {}
    if not coord_dirs:
        return lists
    coord_dir = coord_dirs[0]
    for rf in coord_dir.glob('*_candidates.rules'):
        pred = rf.name[:-len('_candidates.rules')]
        try:
            text = rf.read_text(encoding='utf-8', errors='ignore')
        except Exception:
            continue
        lists[pred] = [ln.strip() for ln in text.splitlines() if ln.strip()]
    return lists


def collect_agent_rankings(pool_dir: Path) -> Tuple[List[str], Dict[str, Dict[str, List[str]]]]:
    """Scan pool_dir for agent subdirs and per-predicate *_pool.txt files.
    Returns:
      predicates: sorted list of predicate stems found
      rankings: {predicate: {agent_name: [rule1, rule2, ...]}}
    """
    rankings: Dict[str, Dict[str, List[str]]] = defaultdict(dict)
    predicates = set()
    cand_map = _load_candidates(pool_dir)
    cand_lists = _load_candidate_lists(pool_dir)

    for agent_dir in pool_dir.iterdir():
        if not agent_dir.is_dir() or not agent_dir.name.startswith('Agent'):
            continue
        agent_name = agent_dir.name
        for f in agent_dir.glob("*_pool.txt"):
            stem = f.stem.replace('_pool', '')
            predicates.add(stem)
            text = f.read_text(encoding='utf-8', errors='ignore')
            raw_list = parse_ranking_text(text)
            cleaned = _clean_to_candidates(stem, raw_list, cand_map)
            # Ensure full permutation by appending any missing candidates in original order
            full = cleaned[:]
            appended = 0
            total_cands = len(cand_lists.get(stem, []))
            if stem in cand_lists and cand_lists[stem]:
                existing = set(full)
                for r in cand_lists[stem]:
                    if r not in existing:
                        full.append(r)
                        existing.add(r)
                        appended += 1
            # If nothing matched at all but we know candidates, default to original order
            if not full and stem in cand_lists:
                full = cand_lists[stem][:]
                print(f"[pool:borda] {agent_name}/{stem}: no valid matches parsed; using original order ({len(full)} rules)")
            else:
                if appended > 0:
                    print(f"[pool:borda] {agent_name}/{stem}: appended {appended} missing to complete {len(full)}/{total_cands}")
            rankings[stem][agent_name] = full
    return sorted(predicates), rankings


def borda_aggregate(ranked_lists: Dict[str, List[str]]) -> Dict[str, float]:
    """Compute Borda scores across agents.
    ranked_lists: agent -> list of rules in ranking order (best first)
    Score(rule) = average over agents of (|R| + 1 - rank_position)
    """
    # Universe of rules across agents
    rules = set()
    for lst in ranked_lists.values():
        rules.update(lst)
    rules = list(rules)

    E = max(1, len(ranked_lists))
    scores: Dict[str, float] = {r: 0.0 for r in rules}

    for agent, lst in ranked_lists.items():
        R = len(lst)
        # Build position map
        pos = {lst[i]: i + 1 for i in range(R)}  # 1-based rank
        for r in rules:
            if r in pos:
                s = (R + 1 - pos[r])
            else:
                # If a rule not present in an agent's list, give minimal score (0)
                s = 0
            scores[r] += s / E
    return scores


def main():
    ap = argparse.ArgumentParser(description='Aggregate pool rankings via Borda count.')
    ap.add_argument('pool_dir', type=str, nargs='?', default='/Volumes/DATI/GitHub/SOLAR/gen_rules/yago/c2r_new/line/2/pool_ollama_qwen2.5:latest', help='Path to pool_<coordinator_model> directory (default: current dir)')
    ap.add_argument('--out', type=str, default='', help='Optional CSV output for aggregated scores')
    args = ap.parse_args()

    pool_dir = Path(args.pool_dir)
    if not pool_dir.exists():
        raise SystemExit(f"Pool directory not found: {pool_dir}")

    predicates, rankings = collect_agent_rankings(pool_dir)
    if not predicates:
        print(f"No per-agent rankings found under {pool_dir}")
        return

    header = ['predicate', 'rule', 'borda_score']
    rows = []
    for pred in predicates:
        ranked_lists = rankings.get(pred, {})
        scores = borda_aggregate(ranked_lists)
        # Sort by score desc
        for r, s in sorted(scores.items(), key=lambda kv: kv[1], reverse=True):
            rows.append([pred, r, f"{s:.6f}"])

    # Print summary to stdout
    print("\t".join(header))
    for row in rows[:50]:  # print first 50 for brevity
        print("\t".join(row))

    # Write CSV (default under pool_dir if relative)
    outp: Path
    if args.out:
        outp = Path(args.out)
        if not outp.is_absolute():
            outp = pool_dir / outp.name
    else:
        outp = pool_dir / 'aggregated_pool.csv'
    outp.parent.mkdir(parents=True, exist_ok=True)
    with open(outp, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)
    print(f"Wrote aggregated pool scores to {outp}")


if __name__ == '__main__':
    main()
