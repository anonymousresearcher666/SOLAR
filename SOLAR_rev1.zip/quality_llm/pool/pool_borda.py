"""
Pool Borda aggregation: expose canonical implementation in package.
"""

from .pool_borda_full import *  # noqa: F401,F403
