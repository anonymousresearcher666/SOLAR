import os
import sys
import json
from pathlib import Path
from typing import Dict, List, Tuple

try:
    from ..common.RuleExtractor import RuleExtractor
    from ..common.SchemaQualityMeasures import (
        Predicate,
        SchemaLevelEvaluator,
        evaluate_rules_multi_models,
        get_default_similarity_models,
    )
except Exception:
    THIS_DIR = Path(__file__).resolve().parent
    # Fallback 1: running the file directly from consensus/ — import sibling 'common'
    try:
        PKG_DIR = THIS_DIR.parent  # path/to/repo/quality_llm
        if str(PKG_DIR) not in sys.path:
            sys.path.insert(0, str(PKG_DIR))
        from common.RuleExtractor import RuleExtractor  # type: ignore
        from common.SchemaQualityMeasures import (  # type: ignore
            Predicate,
            SchemaLevelEvaluator,
            evaluate_rules_multi_models,
            get_default_similarity_models,
        )
    except Exception:
        # Fallback 2: add repo root and import as package
        REPO_ROOT = THIS_DIR.parents[2]
        if str(REPO_ROOT) not in sys.path:
            sys.path.insert(0, str(REPO_ROOT))
        from quality_llm.common.RuleExtractor import RuleExtractor  # type: ignore
        from quality_llm.common.SchemaQualityMeasures import (  # type: ignore
            Predicate,
            SchemaLevelEvaluator,
            evaluate_rules_multi_models,
            get_default_similarity_models,
        )


def get_repo_root() -> Path:
    """Detect repo root; override with REPO_ROOT env var.

    Note: this file lives under quality_llm/consensus, so repo root is parents[2].
    """
    env = os.environ.get("REPO_ROOT")
    if env:
        return Path(env).resolve()
    return Path(__file__).resolve().parents[2]


def resolve_path(p: str, base: Path) -> Path:
    path = Path(p)
    return path if path.is_absolute() else (base / path)


def resolve_output_path(name: str, consensus_dir: Path) -> Path:
    """Resolve output file path. If name is absolute, use it; otherwise place inside consensus_dir."""
    p = Path(name)
    return p if p.is_absolute() else (consensus_dir / p.name)


def collect_rules_from_consensus_folder(consensus_folder: str) -> Dict[str, List[str]]:
    """
    Collect clean rule strings from a consensus output folder using RuleExtractor.

    Returns a dict: { target_predicate: ["head(X,Y) :- body(...)", ...], ... }
    """
    folder = Path(consensus_folder)
    if not folder.exists():
        raise FileNotFoundError(f"Consensus folder not found: {folder} (cwd={Path.cwd()})")

    extractor = RuleExtractor(folder_path=consensus_folder)
    extractor.process_folder()

    rules_by_pred: Dict[str, List[str]] = {}
    for r in extractor.rules_data:
        pred = r.get("file_predicate", "unknown")
        rule = r.get("full_rule")
        if not rule:
            continue
        rules_by_pred.setdefault(pred, []).append(rule)

    return rules_by_pred


def save_rules_json(rules_by_pred: Dict[str, List[str]], out_path: str) -> None:
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        json.dump(rules_by_pred, f, ensure_ascii=False, indent=2)


def build_schema_from_line_graph(line_graph_path: str) -> Dict[str, Predicate]:
    """
    Build a schema dict from a dataset line_graph.txt file.
    Expects a <nodes> section with lines like: predicate[Domain,Range]
    """
    path = Path(line_graph_path)
    if not path.exists():
        raise FileNotFoundError(f"line_graph.txt not found: {path}")

    with open(path, "r", encoding="utf-8") as f:
        content = f.read()

    in_nodes = False
    schema: Dict[str, Predicate] = {}
    for raw in content.splitlines():
        line = raw.strip()
        if line == "<nodes>":
            in_nodes = True
            continue
        if line == "</nodes>":
            in_nodes = False
            continue
        if not in_nodes or not line or "[" not in line or "]" not in line:
            continue
        try:
            name, rest = line.split("[", 1)
            dom, rng = rest.rstrip("]").split(",")
            name = name.strip()
            dom = dom.strip()
            rng = rng.strip()
            schema[name] = Predicate(name=name, domain=dom, range=rng)
        except Exception:
            # Skip malformed lines
            continue
    return schema


def parse_consensus_path(consensus_folder: str):
    """Infer dataset and schema_type from a consensus folder path like
    gen_rules/<dataset>/<prompt_type>/<schema_type>/<numbodyatoms>/<prefix...>
    Returns (dataset, schema_type) or (None, None) if not parseable.
    """
    p = Path(consensus_folder).parts
    try:
        idx = p.index('gen_rules')
        dataset = p[idx + 1]
        schema_type = p[idx + 3]
        return dataset, schema_type
    except Exception:
        return None, None  # type: ignore


def build_schema_from_dataset(dataset: str, schema_type: str, dataset_root: str = 'dataset') -> Dict[str, Predicate]:
    """Build schema dict from files in dataset/<dataset>/ depending on schema_type."""
    base = Path(dataset_root) / dataset
    if schema_type == 'line':
        return build_schema_from_line_graph(str(base / 'line_graph.txt'))
    elif schema_type == 'graph':
        # Fallback: parse nodes/edges if in same format as line
        return build_schema_from_line_graph(str(base / 'schema_graph.txt'))
    elif schema_type == 'domain_range':
        # Best-effort: parse triplet as name[Domain,Range] lines are not available; create generic predicates
        path = base / 'domain_and_range.txt'
        schema: Dict[str, Predicate] = {}
        if path.exists():
            with open(path, 'r', encoding='utf-8') as f:
                for raw in f:
                    s = raw.strip()
                    if not s or ' ' not in s:
                        continue
                    try:
                        name, dom, rng = s.split()
                        schema[name] = Predicate(name=name, domain=dom, range=rng)
                    except Exception:
                        continue
        return schema
    else:
        raise ValueError(f"Unknown schema_type: {schema_type}")


def evaluate_rules_for_predicate(
    consensus_folder: str,
    line_graph_path: str,
    target_predicate: str,
    enable_semantic: bool = False,
    model_name: str = 'all-MiniLM-L6-v2',
) -> Dict[str, float]:
    """
    Extract rules for target_predicate and evaluate SCS/SeCS/CovS using the dataset schema.
    """
    rules_by_pred = collect_rules_from_consensus_folder(consensus_folder)
    rules = rules_by_pred.get(target_predicate, [])
    schema = build_schema_from_line_graph(line_graph_path)
    evaluator = SchemaLevelEvaluator(schema, similarity_model=model_name, enable_semantic=enable_semantic)
    return evaluator.evaluate_rules_from_strings(rules, target_predicate)


def evaluate_rules_auto(
    consensus_folder: str,
    target_predicate: str,
    dataset_root: str = 'dataset',
    enable_semantic: bool = False,
    model_name: str = 'all-MiniLM-L6-v2',
) -> Dict[str, float]:
    """
    Infer dataset and schema_type from consensus path, load schema from dataset/<dataset>/..., and evaluate rules.
    """
    dataset, schema_type = parse_consensus_path(consensus_folder)
    if not dataset or not schema_type:
        raise ValueError("Could not infer dataset/schema_type from consensus folder path")
    rules_by_pred = collect_rules_from_consensus_folder(consensus_folder)
    rules = rules_by_pred.get(target_predicate, [])
    schema = build_schema_from_dataset(dataset, schema_type, dataset_root=dataset_root)
    evaluator = SchemaLevelEvaluator(schema, similarity_model=model_name, enable_semantic=enable_semantic)
    return evaluator.evaluate_rules_from_strings(rules, target_predicate)


def evaluate_all_auto(
    consensus_folder: str,
    dataset_root: str = 'dataset',
    enable_semantic: bool = False,
    model_name: str = 'all-MiniLM-L6-v2',
) -> Dict[str, Dict[str, float]]:
    """Evaluate SCS/SeCS/CovS for all predicates found in the consensus folder.
    Returns mapping predicate -> scores dict.
    """
    dataset, schema_type = parse_consensus_path(consensus_folder)
    if not dataset or not schema_type:
        raise ValueError("Could not infer dataset/schema_type from consensus folder path")

    # Build schema once
    schema = build_schema_from_dataset(dataset, schema_type, dataset_root=dataset_root)
    evaluator = SchemaLevelEvaluator(schema, similarity_model=model_name, enable_semantic=enable_semantic)

    # Collect rules once
    rules_by_pred = collect_rules_from_consensus_folder(consensus_folder)

    results: Dict[str, Dict[str, float]] = {}
    for pred, rules in sorted(rules_by_pred.items()):
        if not rules:
            continue
        results[pred] = evaluator.evaluate_rules_from_strings(rules, pred)
    return results


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Extract consensus rules for quality evaluation.")
    parser.add_argument(
        "consensus_folder",
        nargs='?',
        default="gen_rules/family/c2r_new/line/2/pool_ollama_gpt-oss-20b",
        help="Path to consensus folder under gen_rules (contains *_consensus.txt)")
    parser.add_argument("--out", dest="out", default="consensus_rules.json", help="Output JSON path")
    parser.add_argument("--line-graph", dest="line_graph", default=None,
                        help="Optional path to dataset line_graph.txt for evaluation")
    parser.add_argument("--predicate", dest="predicate", default=None,
                        help="Target predicate to evaluate; if omitted, evaluates ALL predicates")
    parser.add_argument("--auto", dest="auto", action='store_true', default=True,
                        help="Infer dataset/schema from consensus path for evaluation")
    parser.add_argument("--dataset-root", dest="dataset_root", default='dataset',
                        help="Dataset root directory (default: dataset)")
    parser.add_argument("--semantic", dest="semantic", action='store_true',
                        help="Enable semantic coherence (requires model)")
    parser.add_argument("--model", dest="model", default='all-MiniLM-L6-v2',
                        help="SentenceTransformer model for SeCS (default: all-MiniLM-L6-v2)")
    parser.add_argument("--csv-out", dest="csv_out", default="consensus_quality.csv",
                        help="CSV output path for results (default: consensus_quality.csv)")
    parser.add_argument(
        "--sim-models",
        nargs='*',
        default=get_default_similarity_models(),
        help="List of SentenceTransformer models for SeCS per model. Default: recommended set."
    )
    parser.add_argument("--multi-out", dest="multi_out", default="consensus_multi_models.csv",
                        help="CSV output for multi-model results (predicate,model,SCS,SeCS,CovS)")

    args = parser.parse_args()

    # Resolve paths relative to repo root for robustness
    repo_root = get_repo_root()
    consensus_path = resolve_path(args.consensus_folder, repo_root)
    dataset_root = resolve_path(args.dataset_root, repo_root)
    line_graph = resolve_path(args.line_graph, repo_root) if args.line_graph else None
    json_out_path = resolve_output_path(args.out, consensus_path)
    csv_out_path = resolve_output_path(args.csv_out, consensus_path)

    print(f"Repo root: {repo_root}")
    print(f"Consensus folder: {consensus_path}")
    print(f"Dataset root: {dataset_root}")

    rules = collect_rules_from_consensus_folder(str(consensus_path))
    save_rules_json(rules, str(json_out_path))
    print(f"Saved rules JSON -> {json_out_path}")

    # Decide evaluation mode: single predicate if provided, else ALL (default)
    if args.predicate is None:
        try:
            from csv import writer as csv_writer
            all_scores = evaluate_all_auto(
                str(consensus_path),
                dataset_root=str(dataset_root),
                enable_semantic=args.semantic,
                model_name=args.model,
            )
            # Write CSV
            import csv
            with open(csv_out_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(['predicate', 'SCS', 'SeCS', 'CovS'])
                for pred, scores in all_scores.items():
                    writer.writerow([pred, scores.get('SCS', ''), scores.get('SeCS', ''), scores.get('CovS', '')])
            print(f"Saved quality CSV -> {csv_out_path}")

            # Multi-model evaluation if requested
            if args.sim_models is not None:
                # Choose models: explicit list or default recommended
                models = args.sim_models if len(args.sim_models) > 0 else get_default_similarity_models()
                # Load rules once (we already have schema in scope below, ensure it's computed)
                rules_by_pred = collect_rules_from_consensus_folder(str(consensus_path))
                # Build schema once for SeCS across models
                dataset, schema_type = parse_consensus_path(str(consensus_path))
                schema = build_schema_from_dataset(dataset, schema_type, dataset_root=str(dataset_root))
                import csv as _csv
                multi_path = resolve_output_path(args.multi_out, consensus_path)
                rows = []
                for pred, rule_list in rules_by_pred.items():
                    if not rule_list:
                        continue
                    mm = evaluate_rules_multi_models(
                        schema,
                        rule_list,
                        pred,
                        models,
                        enable_semantic=True,
                    )
                    for m, sc in mm.items():
                        rows.append([pred, m, sc.get('SCS', ''), sc.get('SeCS', ''), sc.get('CovS', '')])
                with open(multi_path, 'w', newline='', encoding='utf-8') as f:
                    w = _csv.writer(f)
                    w.writerow(['predicate', 'model', 'SCS', 'SeCS', 'CovS'])
                    w.writerows(rows)
                print(f"Saved multi-model CSV -> {multi_path}")
        except Exception as e:
            print(f"Evaluation (all) failed: {e}")
    elif args.predicate and (line_graph or args.auto):
        try:
            if args.auto:
                scores = evaluate_rules_auto(
                    str(consensus_path), args.predicate,
                    dataset_root=str(dataset_root), enable_semantic=args.semantic,
                    model_name=args.model,
                )
            else:
                scores = evaluate_rules_for_predicate(
                    str(consensus_path), str(line_graph), args.predicate,
                    enable_semantic=args.semantic, model_name=args.model,
                )  # type: ignore
            print(f"Evaluation for {args.predicate}: {scores}")
            # Always produce CSV, even for single predicate runs
            import csv
            with open(csv_out_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(['predicate', 'SCS', 'SeCS', 'CovS'])
                writer.writerow([args.predicate, scores.get('SCS', ''), scores.get('SeCS', ''), scores.get('CovS', '')])
            print(f"Saved quality CSV -> {csv_out_path}")
        except Exception as e:
            print(f"Evaluation failed: {e}")
