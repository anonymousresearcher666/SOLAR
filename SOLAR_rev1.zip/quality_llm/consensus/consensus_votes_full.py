#!/usr/bin/env python3
"""Collect -1/0/+1 votes from consensus outputs and export raw and aggregated CSVs.

Input structure expected (under a consensus run folder):
- Top-level files: <predicate>_consensus.txt, <predicate>_consensus.query (optional)
- Per-participant folders:
  - Coordinator_<model>/<predicate>_final_votes.txt
  - AgentN_<model>/<predicate>_final_votes.txt

This tool reads the rule list per predicate via RuleExtractor, then parses
participant vote files and produces two CSVs in the consensus folder:
- votes_raw.csv: predicate,rule_index,participant,vote
- votes_agg.csv: predicate,rule_index,rule_text,vote_sum,voter_count

Aggregation here is limited to summing votes; downstream scoring can reuse
existing quality_llm code for final metrics as desired.
"""

from __future__ import annotations
import os
import csv
import sys
from pathlib import Path
from typing import Dict, List, Tuple
import os

try:
    from ..common.RuleExtractor import RuleExtractor
except Exception:
    # Fallback import paths
    THIS_DIR = Path(__file__).resolve().parent
    PKG_DIR = THIS_DIR.parent
    REPO_ROOT = THIS_DIR.parents[2]
    if str(PKG_DIR) not in sys.path:
        sys.path.insert(0, str(PKG_DIR))
    if str(REPO_ROOT) not in sys.path:
        sys.path.insert(0, str(REPO_ROOT))
    from quality_llm.common.RuleExtractor import RuleExtractor  # type: ignore


def get_repo_root() -> Path:
    env = os.environ.get("REPO_ROOT")
    if env:
        return Path(env).resolve()
    # This file lives under quality_llm/consensus
    return Path(__file__).resolve().parents[2]


def resolve_path(p: str, base: Path) -> Path:
    path = Path(p)
    return path if path.is_absolute() else (base / path)


def list_participant_dirs(consensus_dir: Path) -> List[Path]:
    return [p for p in consensus_dir.iterdir() if p.is_dir() and (p.name.startswith('Agent') or p.name.startswith('Coordinator_'))]


def _read_candidates_rules(consensus_dir: Path) -> Dict[str, List[str]]:
    out: Dict[str, List[str]] = {}
    # Look under Coordinator_* dirs
    for coord_dir in [p for p in consensus_dir.iterdir() if p.is_dir() and p.name.startswith('Coordinator_')]:
        for f in coord_dir.glob("*_candidates.rules"):
            pred = f.name.replace('_candidates.rules', '')
            try:
                txt = f.read_text(encoding='utf-8', errors='ignore')
            except Exception:
                continue
            lines = [ln.strip() for ln in txt.splitlines() if ln.strip()]
            # Keep only horn-like lines
            rules = []
            seen = set()
            for ln in lines:
                if ':-' in ln and '(' in ln and ')' in ln and ln not in seen:
                    seen.add(ln)
                    rules.append(ln)
            if rules:
                out[pred] = rules
    return out


def _read_rules_from_consensus_txt(consensus_dir: Path) -> Dict[str, List[str]]:
    # Fallback: parse rules by simple heuristic from <predicate>_consensus.txt
    out: Dict[str, List[str]] = {}
    arrow_variants = [':-', '<-', '<=', '⇐', '←']
    for f in consensus_dir.glob("*_consensus.txt"):
        pred = f.name.replace('_consensus.txt', '')
        try:
            txt = f.read_text(encoding='utf-8', errors='ignore')
        except Exception:
            continue
        rules: List[str] = []
        seen = set()
        lines = txt.splitlines()
        i = 0
        while i < len(lines):
            raw = lines[i]
            s = raw.strip()
            # Remove numbering/bullets
            s = re.sub(r'^\s*(?:\d+[.)]\s*|[-*+]\s*)', '', s)
            # If line includes head(args) and any arrow, capture and merge continuation lines
            def _has_shape(x: str) -> bool:
                return (re.search(r'\w+\s*\([^)]*\)', x) is not None and any(a in x for a in arrow_variants))
            if _has_shape(s):
                merged = s
                j = i + 1
                while j < len(lines):
                    nxt = lines[j].strip()
                    if not nxt:
                        break
                    nxt_norm = re.sub(r'^\s*(?:\d+[.)]\s*|[-*+]\s*)', '', nxt)
                    if _has_shape(nxt_norm):
                        break
                    # Continue body if we don't end with a terminal punctuation
                    if not merged.rstrip().endswith(('.', ';')) or merged.rstrip().endswith(','):
                        merged += ' ' + nxt_norm
                        j += 1
                        continue
                    break
                if merged not in seen:
                    seen.add(merged)
                    rules.append(merged)
                i = j
                continue
            i += 1
        if rules:
            out[pred] = rules
    return out


def collect_rules(consensus_dir: Path) -> Dict[str, List[str]]:
    # 1) Prefer standardized candidates files
    rules_by_pred = _read_candidates_rules(consensus_dir)
    if rules_by_pred:
        return rules_by_pred
    # 2) Use RuleExtractor (RULE X: ... pattern) if present
    extractor = RuleExtractor(folder_path=str(consensus_dir))
    extractor.process_folder()
    for r in extractor.rules_data:
        pred = r.get("file_predicate", "unknown")
        rule = r.get("full_rule")
        if not rule:
            continue
        rules_by_pred.setdefault(pred, []).append(rule)
    if rules_by_pred:
        return rules_by_pred
    # 3) Heuristic extraction from consensus text
    return _read_rules_from_consensus_txt(consensus_dir)


def read_votes_file(path: Path, expected_n: int) -> List[int]:
    if not path.exists():
        return []
    try:
        raw = path.read_text(encoding='utf-8', errors='ignore')
    except Exception:
        return []
    votes: List[int] = []
    for ln in raw.splitlines():
        s = ln.strip()
        if not s:
            continue
        try:
            v = int(s)
        except Exception:
            # Accept formats like "+1" or "- 1"
            s2 = s.replace(' ', '')
            if s2 in ['+1', '1']:
                v = 1
            elif s2 in ['-1']:
                v = -1
            elif s2 in ['0', '+0', '-0']:
                v = 0
            else:
                continue
        if v not in (-1, 0, 1):
            continue
        votes.append(v)
        if len(votes) >= expected_n:
            break
    # Pad with zeros if fewer votes than rules
    if len(votes) < expected_n:
        votes.extend([0] * (expected_n - len(votes)))
    return votes[:expected_n]


def collect_votes(consensus_dir: Path) -> Tuple[Dict[str, List[str]], Dict[str, Dict[str, List[int]]]]:
    rules_by_pred = collect_rules(consensus_dir)
    participants = list_participant_dirs(consensus_dir)
    votes: Dict[str, Dict[str, List[int]]] = {}
    for pred, rules in rules_by_pred.items():
        n = len(rules)
        votes[pred] = {}
        for part_dir in participants:
            vf = part_dir / f"{pred}_final_votes.txt"
            arr = read_votes_file(vf, n)
            if arr:
                votes[pred][part_dir.name] = arr
    return rules_by_pred, votes


def write_raw_csv(consensus_dir: Path, votes: Dict[str, Dict[str, List[int]]]) -> Path:
    out = consensus_dir / 'votes_raw.csv'
    with open(out, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['predicate', 'rule_index', 'participant', 'vote'])
        for pred, per_part in sorted(votes.items()):
            # Ensure consistent participants order
            for participant, arr in sorted(per_part.items()):
                for idx, v in enumerate(arr):
                    w.writerow([pred, idx, participant, v])
    return out


def write_agg_csv(consensus_dir: Path, rules_by_pred: Dict[str, List[str]], votes: Dict[str, Dict[str, List[int]]]) -> Path:
    out = consensus_dir / 'votes_agg.csv'
    with open(out, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f)
        w.writerow(['predicate', 'rule_index', 'rule_text', 'vote_sum', 'voter_count', 'avg_vote', 'SPACA_consensus'])
        for pred, rules in sorted(rules_by_pred.items()):
            per_part = votes.get(pred, {})
            n = len(rules)
            for i in range(n):
                s = 0
                c = 0
                for arr in per_part.values():
                    if i < len(arr):
                        s += int(arr[i])
                        c += 1
                avg = (s / c) if c else 0.0
                # Define SPACA_consensus as the average vote in [-1, 1]
                spaca = avg
                w.writerow([pred, i, rules[i], s, c, f"{avg:.4f}", f"{spaca:.4f}"])
    return out


def main():
    import argparse
    ap = argparse.ArgumentParser(description='Collect -1/0/+1 votes from a consensus folder and export CSVs')
    ap.add_argument(
        'consensus_folder',
        nargs='?',
        default='gen_rules/family/c2r_new/line/2/consensus_ollama_gpt-oss-20b',
        help='Path to consensus run folder (gen_rules/..../consensus_...)'
    )
    ap.add_argument('--out-raw', default='votes_raw.csv', help='Raw votes CSV path (default inside consensus folder)')
    ap.add_argument('--out-agg', default='votes_agg.csv', help='Aggregated votes CSV path (default inside consensus folder)')
    args = ap.parse_args()

    repo_root = get_repo_root()
    consensus_dir = resolve_path(args.consensus_folder, repo_root)
    if not consensus_dir.exists():
        raise SystemExit(f"Consensus folder not found: {consensus_dir}")

    rules_by_pred, votes = collect_votes(consensus_dir)
    if not votes:
        print("No votes found.")
        return

    raw_path = write_raw_csv(consensus_dir, votes)
    agg_path = write_agg_csv(consensus_dir, rules_by_pred, votes)
    print(f"Saved raw votes -> {raw_path}")
    print(f"Saved aggregated votes -> {agg_path}")


if __name__ == '__main__':
    main()
