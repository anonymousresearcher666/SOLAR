import os
import numpy as np
from typing import List, Dict, Tuple, Any, Set, Optional
from dataclasses import dataclass
from enum import Enum
import re
from collections import defaultdict
import hashlib
from pathlib import Path
import sys

# Reuse utilities from consensus package
try:
    from .consensus_llm_quality_full import (
        collect_rules_from_consensus_folder,
        parse_consensus_path,
        build_schema_from_dataset,
    )
except Exception:
    # Fallback 1: running directly from consensus/
    try:
        THIS_DIR = Path(__file__).resolve().parent
        PKG_DIR = THIS_DIR.parent
        if str(PKG_DIR) not in sys.path:
            sys.path.insert(0, str(PKG_DIR))
        from consensus.consensus_llm_quality_full import (  # type: ignore
            collect_rules_from_consensus_folder,
            parse_consensus_path,
            build_schema_from_dataset,
        )
    except Exception:
        # Fallback 2: add repo root and import as package
        import sys as _sys
        from pathlib import Path as _P
        _repo_root = _P(__file__).resolve().parents[2]
        if str(_repo_root) not in _sys.path:
            _sys.path.insert(0, str(_repo_root))
        from quality_llm.consensus.consensus_llm_quality_full import (  # type: ignore
            collect_rules_from_consensus_folder,
            parse_consensus_path,
            build_schema_from_dataset,
        )


@dataclass
class Atom:
    """Represents a single atom in a rule"""
    predicate: str
    variables: List[str]

    def __str__(self):
        return f"{self.predicate}({','.join(self.variables)})"

    def normalize_variables(self) -> 'Atom':
        """Normalize variable names to canonical form (X, Y, Z, ...)"""
        var_mapping = {}
        canonical_vars = []
        next_var_index = 0

        for var in self.variables:
            if var not in var_mapping:
                var_mapping[var] = chr(ord('X') + next_var_index)
                next_var_index += 1
            canonical_vars.append(var_mapping[var])

        return Atom(self.predicate, canonical_vars)


@dataclass
class Rule:
    """Represents a logical rule with additional LLM assessment data"""
    head: Atom
    body: List[Atom]
    rule_id: str
    source_agent: Optional[str] = None
    justification: str = ""
    counter_example: str = ""
    assessment: str = ""
    rule_text: str = ""  # Original rule text from LLM

    def __str__(self):
        if not self.body:
            return f"{self.head}"
        body_str = " ∧ ".join([str(atom) for atom in self.body])
        return f"{self.head} ⇐ {body_str}"

    def get_canonical_form(self) -> str:
        """Get canonical string representation for deduplication"""
        all_vars = []
        for atom in [self.head] + self.body:
            all_vars.extend(atom.variables)
        unique_vars = list(dict.fromkeys(all_vars))
        var_mapping = {var: chr(ord('X') + i) for i, var in enumerate(unique_vars)}
        norm_head = Atom(self.head.predicate, [var_mapping[v] for v in self.head.variables])
        norm_body = [Atom(atom.predicate, [var_mapping[v] for v in atom.variables]) for atom in self.body]
        norm_body.sort(key=lambda a: (a.predicate, tuple(a.variables)))
        if not norm_body:
            return str(norm_head)
        body_str = " ∧ ".join([str(atom) for atom in norm_body])
        return f"{norm_head} ⇐ {body_str}"

    def get_rule_hash(self) -> str:
        canonical = self.get_canonical_form()
        return hashlib.md5(canonical.encode()).hexdigest()

    def get_all_variables(self) -> Set[str]:
        variables = set(self.head.variables)
        for atom in self.body:
            variables.update(atom.variables)
        return variables

    def get_rule_length(self) -> int:
        return len(self.body)


@dataclass
class LLMRuleEntry:
    predicate: str
    rule_text: str
    justification: str
    counter_example: str
    assessment: str


class LLMOutputParser:
    def __init__(self):
        self.rule_pattern = re.compile(r'(\w+)\s*\([^)]+\)\s*:-\s*.*')
        self.atom_pattern = re.compile(r'(\w+)\s*\(([^)]+)\)')

    def parse_llm_output(self, text: str, agent_id: str) -> List[Rule]:
        rules = []
        sections = self._split_into_sections(text)
        rule_counter = 1
        for section in sections:
            try:
                llm_entries = self._parse_section(section)
                for entry in llm_entries:
                    parsed_rule = self._parse_rule_from_entry(entry, agent_id, rule_counter)
                    if parsed_rule:
                        rules.append(parsed_rule)
                        rule_counter += 1
            except Exception as e:
                print(f"Warning: Error parsing section: {e}")
                continue
        return rules

    def _split_into_sections(self, text: str) -> List[str]:
        lines = text.strip().split('\n')
        sections = []
        current_section = []
        for line in lines:
            line = line.strip()
            if not line:
                continue
            if (re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', line) and
                    not any(keyword in line.lower() for keyword in ['justification', 'counter', 'assessment'])):
                if current_section:
                    sections.append('\n'.join(current_section))
                current_section = [line]
            else:
                current_section.append(line)
        if current_section:
            sections.append('\n'.join(current_section))
        return sections

    def _parse_section(self, section: str) -> List[LLMRuleEntry]:
        lines = [l.strip() for l in section.split('\n') if l.strip()]
        if not lines:
            return []
        predicate = lines[0]
        entries = []
        i = 1
        while i < len(lines):
            rule_text = lines[i]
            justification = ''
            counter_example = ''
            assessment = ''
            j = i + 1
            while j < len(lines):
                low = lines[j].lower()
                if low.startswith('justification:'):
                    justification = lines[j][len('justification:'):].strip()
                elif low.startswith('counter'):
                    counter_example = lines[j].split(':', 1)[-1].strip()
                elif low.startswith('assessment:'):
                    assessment = lines[j][len('assessment:'):].strip()
                else:
                    break
                j += 1
            entries.append(LLMRuleEntry(predicate, rule_text, justification, counter_example, assessment))
            i = j
        return entries

    def _parse_rule_from_entry(self, entry: LLMRuleEntry, agent_id: str, rule_counter: int) -> Optional[Rule]:
        try:
            atoms = self.atom_pattern.findall(entry.rule_text)
            if not atoms:
                return None
            head_pred, head_vars = atoms[0][0], [v.strip() for v in atoms[0][1].split(',')]
            body_atoms = [Atom(p, [v.strip() for v in args.split(',')]) for p, args in atoms[1:]]
            rule_id = f"{agent_id}_R{rule_counter}"
            return Rule(head=Atom(head_pred, head_vars), body=body_atoms, rule_id=rule_id,
                        source_agent=agent_id, justification=entry.justification,
                        counter_example=entry.counter_example, assessment=entry.assessment,
                        rule_text=entry.rule_text)
        except Exception:
            return None


class RankAggregationMethod(Enum):
    BORDA = 'borda'
    MEDIAN = 'median'
    MEAN = 'mean'


def aggregate_ranks(rankings: Dict[str, Dict[str, float]], method: RankAggregationMethod = RankAggregationMethod.BORDA) -> Dict[str, float]:
    if method == RankAggregationMethod.BORDA:
        return _borda_aggregate(rankings)
    elif method == RankAggregationMethod.MEDIAN:
        return _median_aggregate(rankings)
    elif method == RankAggregationMethod.MEAN:
        return _mean_aggregate(rankings)
    else:
        raise ValueError(f"Unknown aggregation method: {method}")


def _borda_aggregate(rankings: Dict[str, Dict[str, float]]) -> Dict[str, float]:
    scores: Dict[str, float] = defaultdict(float)
    for agent, ranks in rankings.items():
        sorted_rules = sorted(ranks.items(), key=lambda kv: kv[1], reverse=True)
        n = len(sorted_rules)
        for i, (rule, _) in enumerate(sorted_rules):
            scores[rule] += (n - i - 1)
    return dict(scores)


def _median_aggregate(rankings: Dict[str, Dict[str, float]]) -> Dict[str, float]:
    positions: Dict[str, List[int]] = defaultdict(list)
    for agent, ranks in rankings.items():
        sorted_rules = [r for r, _ in sorted(ranks.items(), key=lambda kv: kv[1], reverse=True)]
        for pos, rule in enumerate(sorted_rules):
            positions[rule].append(pos)
    return {rule: float(np.median(pos_list)) for rule, pos_list in positions.items()}


def _mean_aggregate(rankings: Dict[str, Dict[str, float]]) -> Dict[str, float]:
    positions: Dict[str, List[int]] = defaultdict(list)
    for agent, ranks in rankings.items():
        sorted_rules = [r for r, _ in sorted(ranks.items(), key=lambda kv: kv[1], reverse=True)]
        for pos, rule in enumerate(sorted_rules):
            positions[rule].append(pos)
    return {rule: float(np.mean(pos_list)) for rule, pos_list in positions.items()}
