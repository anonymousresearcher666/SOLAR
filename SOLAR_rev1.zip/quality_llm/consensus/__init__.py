"""Consensus-mode helpers and entrypoints."""
