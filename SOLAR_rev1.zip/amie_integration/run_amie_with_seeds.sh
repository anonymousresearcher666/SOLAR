#!/usr/bin/env bash
set -euo pipefail

# Usage:
#   ./amie_integration/run_amie_with_seeds.sh amie_integration/out/amie_seeds.tsv dataset/family/facts.txt
#
# Requirements:
#   - AMIE built locally; set AMIE_JAR or AMIE_ROOT
#   - Your custom SeedMiningAssistant compiled into AMIE (use -bias)

SEEDS=${1:-amie_integration/out/amie_seeds.tsv}
FACTS=${2:-dataset/family/facts.txt}

if [[ -z "${AMIE_JAR:-}" ]]; then
  if [[ -n "${AMIE_ROOT:-}" && -f "$AMIE_ROOT/target/amie.jar" ]]; then
    AMIE_JAR="$AMIE_ROOT/target/amie.jar"
  else
    echo "Please set AMIE_JAR to your AMIE jar or AMIE_ROOT to your AMIE source root (with target/amie.jar)." >&2
    exit 1
  fi
fi

if [[ ! -f "$SEEDS" ]]; then
  echo "Seeds file not found: $SEEDS" >&2
  exit 1
fi
if [[ ! -f "$FACTS" ]]; then
  echo "Facts file not found: $FACTS" >&2
  exit 1
fi

# Example bias class FQN — adjust to your package
BIAS_FQN="amie.mining.assistant.SOLARMiningAssistant"

echo "Running AMIE with seeds: $SEEDS"
echo "AMIE jar: $AMIE_JAR"

java -Xmx8G -Damie.seeds="$SEEDS" -jar "$AMIE_JAR" \
  -bias "$BIAS_FQN" \
  -minhc 0.01 -mins 5 -minpca 0.01 \
  "$FACTS"
