#!/usr/bin/env python3
"""Run AMIE from Python via subprocess with a custom MiningAssistant and seeds TSV.

Usage (examples):
  # Minimal (AMIE_JAR env or AMIE_ROOT/target/amie.jar must be set)
  python amie_integration/run_amie_subprocess.py \
    --facts dataset/family/facts.txt \
    --seeds amie_integration/out/family_amie_seeds.tsv

  # Explicit jar and memory
  python amie_integration/run_amie_subprocess.py \
    --amie-jar /path/to/amie.jar \
    --facts dataset/family/facts.txt \
    --seeds amie_integration/out/family_amie_seeds.tsv \
    --java-mem 8G

  # Extra AMIE flags (appended as-is)
  python amie_integration/run_amie_subprocess.py \
    --facts dataset/family/facts.txt \
    --seeds amie_integration/out/family_amie_seeds.tsv \
    --amie-args -minhc 0.01 -mins 5 -minpca 0.01
"""

from __future__ import annotations

import argparse
import os
import shlex
import subprocess
from pathlib import Path
from typing import List, Tuple


def resolve_amie_jar(explicit: str | None = None) -> str:
    if explicit:
        return explicit
    env = os.environ.get("AMIE_JAR")
    if env:
        return env
    root = os.environ.get("AMIE_ROOT")
    if root and os.path.isfile(os.path.join(root, "target", "amie.jar")):
        return os.path.join(root, "target", "amie.jar")
    raise FileNotFoundError("AMIE jar not found. Set --amie-jar, AMIE_JAR, or AMIE_ROOT (with target/amie.jar)")


def run_amie(amie_jar: str, bias_fqn: str, seeds_tsv: str, facts_path: str,
             java_mem: str = "8G", amie_args: List[str] | None = None) -> Tuple[int, str, str]:
    if not os.path.isfile(amie_jar):
        raise FileNotFoundError(f"AMIE jar not found: {amie_jar}")
    if not os.path.isfile(seeds_tsv):
        raise FileNotFoundError(f"Seeds TSV not found: {seeds_tsv}")
    if not os.path.isfile(facts_path):
        raise FileNotFoundError(f"Facts file not found: {facts_path}")
    cmd = [
        "java",
        f"-Xmx{java_mem}",
        f"-Damie.seeds={seeds_tsv}",
        "-jar", amie_jar,
        "-bias", bias_fqn,
    ]
    if amie_args:
        cmd += list(amie_args)
    cmd.append(facts_path)
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    return proc.returncode, proc.stdout, proc.stderr


def main():
    ap = argparse.ArgumentParser(description="Run AMIE with a custom MiningAssistant and seeds TSV (subprocess)")
    ap.add_argument("--amie-jar", default=None, help="Path to AMIE jar (default: AMIE_JAR or AMIE_ROOT/target/amie.jar)")
    ap.add_argument("--facts", required=True, help="Path to facts.txt (or train.txt) for the dataset")
    ap.add_argument("--seeds", required=True, help="Path to seeds TSV (exported by export_solar_seeds.py)")
    ap.add_argument("--bias-fqn", default="amie.mining.assistant.SOLARMiningAssistant",
                    help="Fully-qualified class name of the MiningAssistant (default: SOLARMiningAssistant)")
    ap.add_argument("--java-mem", default="8G", help="Java heap memory (e.g., 8G)")
    ap.add_argument("--amie-args", nargs=argparse.REMAINDER, help="Additional AMIE flags (appended as-is)")
    ap.add_argument("--log-dir", default="amie_integration/out", help="Directory to write stdout/stderr logs")
    args = ap.parse_args()

    amie_jar = resolve_amie_jar(args.amie_jar)
    code, out, err = run_amie(amie_jar, args.bias_fqn, args.seeds, args.facts,
                              java_mem=args.java_mem, amie_args=args.amie_args)

    # Print to console
    print(out)
    if code != 0:
        print(err, file=os.sys.stderr)

    # Persist logs
    try:
        log_dir = Path(args.log_dir)
        log_dir.mkdir(parents=True, exist_ok=True)
        (log_dir / "amie_stdout.txt").write_text(out, encoding="utf-8")
        (log_dir / "amie_stderr.txt").write_text(err, encoding="utf-8")
    except Exception:
        pass

    if code != 0:
        raise SystemExit(code)


if __name__ == "__main__":
    main()

