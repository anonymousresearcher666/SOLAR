#!/usr/bin/env bash
set -euo pipefail

# Build only the SOLARMiningAssistant class into a small jar you can put on the classpath with AMIE.
# Requirements: JDK (javac/jar) and AMIE sources built or available for compilation classpath.

ROOT_DIR=$(cd "$(dirname "$0")/.." && pwd)
AMIE_SRC="$ROOT_DIR/amie_integration/AMIE"
ASSISTANT_SRC="$AMIE_SRC/mining/src/main/java"
ASSISTANT_FQN="amie/mining/assistant/SOLARMiningAssistant.java"

if ! command -v javac >/dev/null 2>&1; then
  echo "javac not found. Please install JDK." >&2
  exit 1
fi

# Prefer AMIE built jar as classpath, else include AMIE src folders directly
CP=""
if [[ -n "${AMIE_JAR:-}" && -f "$AMIE_JAR" ]]; then
  CP="$AMIE_JAR"
elif [[ -f "$AMIE_SRC/target/amie.jar" ]]; then
  CP="$AMIE_SRC/target/amie.jar"
elif [[ -f "$AMIE_SRC/amie-dev.jar" ]]; then
  CP="$AMIE_SRC/amie-dev.jar"
else
  # Fallback: compile against src trees
  CP="$AMIE_SRC/kb/target/classes:$AMIE_SRC/rules/target/classes:$AMIE_SRC/mining/target/classes"
fi

BUILD_DIR="$ROOT_DIR/amie_integration/out/build"
OUT_JAR="$ROOT_DIR/amie_integration/out/solar-assistant.jar"
mkdir -p "$BUILD_DIR"

echo "Compiling SOLARMiningAssistant against classpath: $CP"
javac -cp "$CP" -d "$BUILD_DIR" "$ASSISTANT_SRC/$ASSISTANT_FQN"
echo "Creating jar: $OUT_JAR"
jar cf "$OUT_JAR" -C "$BUILD_DIR" .
echo "Done. Use with: java -cp $CP:$OUT_JAR -Damie.seeds=... -jar $AMIE_JAR -bias amie.mining.assistant.SOLARMiningAssistant <facts>"

