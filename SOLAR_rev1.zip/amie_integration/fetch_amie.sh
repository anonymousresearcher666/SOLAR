#!/usr/bin/env bash
set -euo pipefail

# Shallow-clone AMIE into amie_integration/AMIE at a pinned commit.
# This directory is .gitignored and will not be committed.

COMMIT="45404f7d230d0e2a4f15012f86b2106f68aa8d76"
DEST="$(cd "$(dirname "$0")" && pwd)/AMIE"

if [[ -d "$DEST/.git" ]]; then
  echo "AMIE already fetched at: $DEST"
  exit 0
fi

echo "Cloning AMIE into $DEST (commit $COMMIT)..."
git clone --depth 1 https://github.com/dig-team/AMIE.git "$DEST"
cd "$DEST"
git fetch --depth 1 origin "$COMMIT"
git checkout "$COMMIT"
echo "Done. AMIE is available at: $DEST"

