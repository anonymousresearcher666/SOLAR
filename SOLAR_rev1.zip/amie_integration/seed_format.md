Seed File Format (for AMIE Assistant)

File: TSV with 2 columns (no header)
- head: textual atom with canonical vars, e.g., head(?x,?y)
- body: comma‑separated list of atoms, e.g., p1(?x,?z), p2(?z,?y)

Example
parent(?x,?y)	father(?x,?z1), mother(?z1,?y)
spouse(?x,?y)	hasChild(?x,?z1), hasChild(?y,?z1)

Conventions
- Variables are canonicalized to ?x, ?y, ?z1, ?z2, … based on the order they appear in the SOLAR rule.
- Predicates are plain identifiers; if a SOLAR rule uses inv_predicate, we keep the literal name `inv_…` so downstream code can map or interpret as needed.
- The dataset name is not included in the TSV; instead, the exporter prefixes the output filename with `<dataset>_`, e.g., `family_amie_seeds.tsv`.
