# SOLAR ↔ AMIE Integration Pipeline

This guide explains how to bias AMIE’s rule mining with SOLAR’s schema‑derived rules by seeding AMIE’s initial frontier via a custom MiningAssistant.

Contents
- What you get here
- Prerequisites
- Step 0: Produce SOLAR rules
- Step 1: Export SOLAR seeds (TSV)
- Step 2: Compile the SOLARMiningAssistant
- Step 3: Run AMIE with seeds
- How it works inside AMIE
- Troubleshooting

## What you get here
- `export_solar_seeds.py` — exports SOLAR rules from a run directory to a TSV seeds file.
- `seed_format.md` — compact TSV format (2 columns: `head\tbody`).
- `java/SOLARMiningAssistant.java` — template implementation (compiles in your AMIE repo).
- `AMIE/` — a cloned AMIE checkout at the referenced commit (for convenience).
- `run_amie_subprocess.py` — Python runner that invokes AMIE (subprocess) with seeds.
- `run_amie_with_seeds.sh` — shell wrapper to run AMIE with seeds.
- `build_solar_assistant.sh` — helper to compile the assistant into a small jar when you don’t rebuild AMIE.

## Prerequisites
- Java JDK (javac, jar) for building; Java runtime for running.
- Optionally Maven if you rebuild AMIE (`mvn -DskipTests package`).
- A SOLAR run folder with generated rules (consensus or pool).

## Step 0: Produce SOLAR rules
Generate rules with SOLAR (e.g., few‑shot + consensus):
```
python main_SOLAR.py \
  --dataset family --schema_type line \
  --spca_mode consensus \
  --coordinator_model ollama_qwen2.5:latest \
  --prompt_type fs --numex 3
```
You should see `gen_rules/<dataset>/<prompt>/<schema>/<k>/consensus_<model>_N/` with `Coordinator_*/_candidates.rules` files.

## Step 1: Export SOLAR seeds (TSV)
Export a 2‑column TSV (head, body) for AMIE:
```
python amie_integration/export_solar_seeds.py \
  --solar-run gen_rules/family/fs/line/2/consensus_ollama_gpt-oss-20b_2
```
Output (default): `amie_integration/out/family_amie_seeds.tsv`

Format (see seed_format.md):
```
head(?x,?y)\tbody1(?..,..), body2(...)
```

## Step 2: Compile the SOLARMiningAssistant
You have two options:

### A) Build AMIE (includes the assistant in the jar)
```
cd amie_integration/AMIE
mvn -DskipTests package
```
Result: `amie_integration/AMIE/target/amie.jar` containing `amie.mining.assistant.SOLARMiningAssistant`.

### B) Compile only the assistant to a tiny jar
Use the helper script (requires `AMIE_JAR` or an AMIE jar in `AMIE/`):
```
AMIE_JAR=amie_integration/AMIE/amie-dev.jar \
./amie_integration/build_solar_assistant.sh
```
Result: `amie_integration/out/solar-assistant.jar`

## Step 3: Run AMIE with seeds
### Option 1: Python subprocess runner (recommended)
```
export AMIE_JAR=amie_integration/AMIE/target/amie.jar   # or amie_integration/AMIE/amie-dev.jar
python amie_integration/run_amie_subprocess.py \
  --facts dataset/family/facts.txt \
  --seeds amie_integration/out/family_amie_seeds.tsv \
  --amie-args -minhc 0.01 -mins 5 -minpca 0.01
```
Logs: `amie_integration/out/amie_stdout.txt`, `amie_integration/out/amie_stderr.txt`.

### Option 2: Shell wrapper
```
AMIE_ROOT=$(pwd)/amie_integration/AMIE \
./amie_integration/run_amie_with_seeds.sh \
  amie_integration/out/family_amie_seeds.tsv \
  dataset/family/facts.txt
```

### Option 3: Direct Java
```
java -Xmx8G \
  -Damie.seeds=amie_integration/out/family_amie_seeds.tsv \
  -cp amie_integration/AMIE/target/amie.jar:amie_integration/out/solar-assistant.jar \
  -jar amie_integration/AMIE/target/amie.jar \
  -bias amie.mining.assistant.SOLARMiningAssistant \
  -minhc 0.01 -mins 5 -minpca 0.01 \
  dataset/family/facts.txt
```

## How it works inside AMIE
- AMIE accepts a custom bias via `-bias <FQN>`. We provide `amie.mining.assistant.SOLARMiningAssistant`.
- The assistant overrides `getInitialAtoms(minInitialSupport)` and returns a collection of full `Rule` objects built from the TSV seeds. Support is computed via `KB.countProjection(head, body)` and filtered by AMIE’s `-minis`.
- AMIE then runs its standard refinements (dangling/closing/instantiated), confidence checks, and pruning, starting from your schema‑grounded seeds.

## Troubleshooting
- “Run directory not found” in exporter: it resolves relative to repo root; use `--solar-run` explicitly or set `REPO_ROOT=$(pwd)`.
- “Seeds TSV not found”: ensure Step 1 produced `amie_integration/out/<dataset>_amie_seeds.tsv`.
- “Class not found: SOLARMiningAssistant”: either rebuild AMIE (Step 2A) or include `solar-assistant.jar` on the classpath (Step 2B/Option 3).
- Java/Maven missing: install JDK; for Maven, you only need it if you rebuild AMIE.
- Empty results: increase `-mins`/decrease thresholds or confirm seeds have non‑zero support on your facts.

## Notes
- The exporter deduplicates and normalizes rules (strips markdown/backticks, removes trailing punctuation).
- If your KB encodes inverse relations explicitly (instead of `inv_…`), map them upstream or adjust SOLAR seeds accordingly.

