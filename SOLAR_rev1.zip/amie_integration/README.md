AMIE Integration (Seeded Search from SOLAR)

Goal
- Bias AMIE’s search with SOLAR rules by seeding AMIE’s initial frontier via a custom MiningAssistant and a seeds file exported from SOLAR outputs.

What’s here
- seed format: amie_integration/seed_format.md
- exporter: amie_integration/export_solar_seeds.py — turn SOLAR rules into AMIE seed lines
- Java assistant (template): amie_integration/java/SOLARMiningAssistant.java — override AMIE’s initial candidates
- fetcher: amie_integration/fetch_amie.sh — shallow‑clone AMIE locally (ignored by git)
- helper runner: amie_integration/run_amie_with_seeds.sh — example invocation (expects AMIE built locally)
- python subprocess runner: amie_integration/run_amie_subprocess.py — run AMIE via Python

High‑level flow
1) Export seeds from a SOLAR run directory into a simple TSV format
   - Input: gen_rules/<ds>/<prompt>/<schema>/<k>/<consensus_or_pool_dir>
   - Output: amie_seeds.tsv
   - Command:
     python amie_integration/export_solar_seeds.py \
       --solar-run gen_rules/family/c2r_new/line/2/consensus_ollama_qwen2.5-latest \
       --out amie_integration/out/amie_seeds.tsv

2) Compile custom MiningAssistant in your AMIE checkout
   - Option A (recommended): keep AMIE outside this repo.
     - Clone or fetch locally: `./amie_integration/fetch_amie.sh` (creates amie_integration/AMIE, .gitignored)
     - Copy `amie_integration/java/SOLARMiningAssistant.java` into the package `amie/mining/assistant/` in that checkout.
     - Build AMIE: `cd amie_integration/AMIE && mvn -DskipTests package`
   - Option B: build only the assistant jar and keep AMIE jar external.
     - Ensure `AMIE_JAR` points to your AMIE jar (e.g., amie_integration/AMIE/amie-dev.jar).
     - Run: `./amie_integration/build_solar_assistant.sh` to produce `amie_integration/out/solar-assistant.jar`.

3) Run AMIE with the custom assistant and the seeds file
   - Example (edit paths in run_amie_with_seeds.sh):
     ./amie_integration/run_amie_with_seeds.sh amie_integration/out/<dataset>_amie_seeds.tsv dataset/family/facts.txt
   - AMIE option to plug a custom assistant is `-bias <FQN>`, e.g.:
     `-bias amie.mining.assistant.SOLARMiningAssistant -Damie.seeds=<dataset>_amie_seeds.tsv`

   Or via Python subprocess:
   ```bash
   # AMIE_JAR or AMIE_ROOT must be set, or pass --amie-jar explicitly
   python amie_integration/run_amie_subprocess.py \
     --facts dataset/family/facts.txt \
     --seeds amie_integration/out/family_amie_seeds.tsv \
     --amie-args -minhc 0.01 -mins 5 -minpca 0.01
   ```

Notes
- The Java class is a template targeting the MiningAssistant interface around commit 45404f7…. If your fork differs, adapt the method names (e.g., getInitialRuleCandidates).
- The seed parser expects a TSV format described in seed_format.md to stay decoupled from AMIE’s internal Rule serialization.
