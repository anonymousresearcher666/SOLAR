#!/usr/bin/env python3
"""Export SOLAR rules to AMIE seed TSV.

Reads a SOLAR run directory and writes a seeds file with rows:
  dataset<TAB>head(?x,?y)<TAB>body1(?..,..), body2(...)

Sources of rules (in this order):
  1) Coordinator_*/*_candidates.rules (standardized)
  2) <predicate>_consensus.txt (heuristic)
  3) Any *.txt in the run folder (via RuleExtractor)

Usage:
  python amie_integration/export_solar_seeds.py \
    --solar-run gen_rules/family/c2r_new/line/2/consensus_... \
    --dataset family \
    --out amie_integration/out/amie_seeds.tsv
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path
from typing import Dict, List, Tuple

import os
def canon_vars(head: str, body_atoms: List[str]) -> Tuple[str, List[str]]:
    """Canonicalize variable names across head+body to ?x, ?y, ?z1, ?z2, ..."""
    var_map: Dict[str, str] = {}
    ordered: List[str] = []

    def harvest_vars(atom: str):
        m = re.search(r"\(([^)]*)\)", atom)
        if not m:
            return []
        return [v.strip() for v in m.group(1).split(',') if v.strip()]

    # Gather in encounter order
    for v in harvest_vars(head):
        if v not in var_map:
            ordered.append(v)
            var_map[v] = ''
    for a in body_atoms:
        for v in harvest_vars(a):
            if v not in var_map:
                ordered.append(v)
                var_map[v] = ''

    # Assign canonical names
    if ordered:
        var_map[ordered[0]] = '?x'
    if len(ordered) > 1:
        var_map[ordered[1]] = '?y'
    next_i = 1
    for v in ordered[2:]:
        var_map[v] = f'?z{next_i}'
        next_i += 1

    def apply(atom: str) -> str:
        def repl_var(m):
            v = m.group(0)
            name = v
            if v in var_map:
                name = var_map[v]
            return name
        # Replace variable tokens (simple alnum underscore tokens)
        out = atom
        for old, new in var_map.items():
            out = re.sub(rf"\b{re.escape(old)}\b", new, out)
        # Ensure predicate(...) spacing clean
        return re.sub(r"\s+", " ", out.strip())

    return apply(head), [apply(a) for a in body_atoms]


def _strip_markdown_wrappers(s: str) -> str:
    # Extract content inside backticks if present
    if '`' in s:
        parts = s.split('`')
        # prefer the longest backticked segment containing parentheses
        candidates = [p for p in parts if '(' in p and ')' in p]
        if candidates:
            s = max(candidates, key=len)
    # Trim table-like pipes and whitespace
    s = s.strip()
    if s.startswith('|') and s.endswith('|'):
        s = s.strip('|').strip()
    # Remove simple table cell prefixes like "| 1 |"
    s = re.sub(r"^\|?\s*\d+\s*\|\s*", "", s)
    # Remove leading enumerations like "1) " or "- "
    s = re.sub(r"^\s*(?:\d+[\.)]\s+|[-*+]\s+)", "", s)
    # Drop bold markers
    s = s.replace('**', '')
    return s.strip()


def _clean_atom(atom: str) -> str:
    a = atom.strip().strip('`').strip('|').strip()
    # remove trailing punctuation
    a = re.sub(r"[\.;]+$", "", a)
    a = re.sub(r"\s+", " ", a)
    return a


def parse_rule_text(line: str) -> Tuple[str, List[str]] | None:
    s = _strip_markdown_wrappers(line)
    if ':-' not in s or '(' not in s or ')' not in s:
        return None
    head, body = s.split(':-', 1)
    head = _clean_atom(head)
    body = body.strip()
    # Split body by commas outside parentheses
    depth = 0
    cur = []
    atoms: List[str] = []
    for ch in body:
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
        if ch == ',' and depth == 0:
            atoms.append(''.join(cur).strip())
            cur = []
        else:
            cur.append(ch)
    if cur:
        atoms.append(''.join(cur).strip())
    atoms = [_clean_atom(a) for a in atoms if a]
    return head, atoms


def collect_rules(solar_run: Path) -> Dict[str, List[str]]:
    """Return {predicate: [rule_text,...]} from a SOLAR run dir.

    Prioritize standardized candidates under Coordinator_*, then fallback to per‑predicate consensus files.
    """
    out: Dict[str, List[str]] = {}
    # 1) candidates.rules
    for coord in solar_run.glob('Coordinator_*'):
        if not coord.is_dir():
            continue
        for f in coord.glob('*_candidates.rules'):
            pred = f.stem.replace('_candidates', '')
            lines = [ln.strip() for ln in f.read_text(encoding='utf-8', errors='ignore').splitlines() if ln.strip()]
            rules = [ln for ln in lines if ':-' in ln and '(' in ln and ')' in ln]
            if rules:
                out.setdefault(pred, []).extend(rules)
    if out:
        return out
    # 2) *_consensus.txt
    for f in solar_run.glob('*_consensus.txt'):
        pred = f.stem.replace('_consensus', '')
        rules = []
        for ln in f.read_text(encoding='utf-8', errors='ignore').splitlines():
            s = ln.strip()
            if ':-' in s and '(' in s and ')' in s:
                rules.append(s)
        if rules:
            out.setdefault(pred, []).extend(rules)
    if out:
        return out
    # 2b) Coordinator_*/*_initial.txt (heuristic lines that look like rules)
    for coord in solar_run.glob('Coordinator_*'):
        if not coord.is_dir():
            continue
        for f in coord.glob('*_initial.txt'):
            # Look for rule-looking lines
            pred_guess = f.stem.replace('_initial', '')
            rules = []
            for ln in f.read_text(encoding='utf-8', errors='ignore').splitlines():
                s = ln.strip()
                if ':-' in s and '(' in s and ')' in s:
                    rules.append(s)
            if rules:
                out.setdefault(pred_guess, []).extend(rules)
    if out:
        return out
    # 3) Any .txt via RuleExtractor
    try:
        from quality_llm.common.RuleExtractor import RuleExtractor
        rx = RuleExtractor(solar_run)
        rx.process_folder()
        for r in rx.rules_data:
            pred = r.get('file_predicate', 'unknown')
            rule = r.get('full_rule')
            if rule:
                out.setdefault(pred, []).append(rule)
    except Exception:
        pass
    return out


def write_seeds(rules_by_pred: Dict[str, List[str]], out_path: Path) -> int:
    n = 0
    out_path.parent.mkdir(parents=True, exist_ok=True)
    seen = set()
    with out_path.open('w', encoding='utf-8') as wf:
        for pred, rules in sorted(rules_by_pred.items()):
            for r in rules:
                parsed = parse_rule_text(r)
                if not parsed:
                    continue
                head, body_atoms = parsed
                head_c, body_c = canon_vars(head, body_atoms)
                # Normalize head predicate display to pred(?x,?y)
                # Ensure head pred string is in pred(?,?) format
                row = f"{head_c}\t{', '.join(body_c)}"
                if row in seen:
                    continue
                seen.add(row)
                wf.write(row + "\n")
                n += 1
    return n


def main():
    ap = argparse.ArgumentParser(description='Export SOLAR rules to AMIE seeds TSV')
    ap.add_argument(
        '--solar-run',
        default='/gen_rules/family/fs/line/2/consensus_ollama_gpt-oss-20b_2',
        help='Path to SOLAR run directory (consensus_* or pool_*)'
    )
    ap.add_argument('--dataset', default='', help='Dataset name (for output filename prefix); default: infer from path')
    ap.add_argument('--out', default='', help='Output TSV path (default: amie_integration/out/<dataset>_amie_seeds.tsv)')
    args = ap.parse_args()

    # Resolve solar_run relative to repo root for robustness
    def get_repo_root() -> Path:
        env = os.environ.get('REPO_ROOT')
        if env:
            return Path(env).resolve()
        # This file lives under <repo_root>/amie_integration
        return Path(__file__).resolve().parents[1]

    import os as _os
    repo_root = get_repo_root()
    raw = Path(args.solar_run)
    candidates = []
    if raw.is_absolute():
        # Handle the common mistake: absolute path starting at "/gen_rules/..."
        # In that case, reinterpret as repo_root/gen_rules/...
        parts = list(raw.parts)
        try:
            idx = parts.index('gen_rules')
            rel_from_gen = Path(*parts[idx:]) if idx >= 0 else None
        except ValueError:
            rel_from_gen = None
        if rel_from_gen is not None:
            candidates.append(repo_root / rel_from_gen)
        # Still try the absolute path as-is
        candidates.append(raw)
    else:
        candidates.append(Path.cwd() / raw)
        candidates.append(repo_root / raw)
    solar_run = next((p for p in candidates if p.exists()), candidates[-1])
    if not solar_run.exists():
        tried = ", ".join(str(p) for p in candidates)
        raise SystemExit(f"Run directory not found: {solar_run}\nTried: {tried}\nHint: run with an explicit --solar-run or set REPO_ROOT to your project root.")

    dataset = args.dataset
    if not dataset:
        # try to infer from gen_rules/<dataset>/...
        try:
            parts = solar_run.parts
            i = parts.index('gen_rules')
            dataset = parts[i+1]
        except Exception:
            dataset = 'dataset'

    rules_by_pred = collect_rules(solar_run)
    if not rules_by_pred:
        raise SystemExit(f"No rules found under {solar_run}")

    out_path = Path(args.out) if args.out else (Path('amie_integration') / 'out' / f"{dataset}_amie_seeds.tsv")
    n = write_seeds(rules_by_pred, out_path)
    print(f"Wrote {n} seeds -> {out_path}")


if __name__ == '__main__':
    main()
