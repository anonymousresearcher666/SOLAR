from collections import deque, defaultdict
class Dataset(object):
    def __init__(self, data_root, prompt_path, dataset_name):
        # Construct entity_list
        self.predicate_path = data_root + 'predicates.txt'
        self.schema_path = data_root
        self.prompt_path = prompt_path
        self.dataset_name = dataset_name

    def read_triples(self, file_name):
        schema_triples = []
        try:
            with open(file_name, 'r') as file:
                for line in file:
                    line = line.strip()  # Clean up whitespace from the line
                    parts = line.split(' ')  # Split the line into components
                    if len(parts) == 3:
                        subject, predicate, object = parts
                        schema_triples.append((subject, predicate, object))
                    else:
                        print(f"Skipping malformed line: {line}")
        except FileNotFoundError:
            print(f"Error: The file {file_name} does not exist.")
        except Exception as e:
            print(f"An error occurred: {e}")

        formatted_list = []
        # Iterate through each tuple in the list
        for item in schema_triples:
            # Convert the tuple to a string and remove the single quotes
            formatted_item = f"({', '.join(item)})"  # Add the formatted string to the list
            formatted_list.append(formatted_item)
        result = '\n'.join(formatted_list)
        return result

    def read_schema(self, schema_type):
        """
        This method reads a schema file specified by the `schema_path` attribute of the class instance.
        Each line in the schema file should be formatted as "subject predicate object" separated by spaces.
        It processes each line to extract these components and stores them as tuples in a list.

        :return: A list of tuples, where each tuple consists of (subject, predicate, object).
        """
        if schema_type == "domain_range":
            file = self.schema_path + 'domain_and_range.txt'
            return self.read_triples(file)
        elif schema_type == "graph":
            file = self.schema_path + 'schema_graph.txt'
            return self.read_triples(file)
        elif schema_type == "line":
            file = self.schema_path + 'line_graph.txt'
            with open(file, 'r') as file:
                line_graph = file.read()
            return line_graph

    def read_predicates(self):
        """
        Reads a file where each line contains a single predicate.

        :param file_path: str, the path to the file containing the predicates.txt.
        :return: list, a list containing all predicates.txt read from the file.
        """
        predicates = []
        try:
            with open(self.predicate_path, 'r') as file:
                for line in file:
                    # Strip any leading/trailing whitespace and add to the list
                    predicate = line.strip()
                    predicates.append(predicate)
        except FileNotFoundError:
            print(f"Error: The file {self.predicate_path} does not exist.")
        except Exception as e:
            print(f"An error occurred: {e}")

        return predicates

    def read_prompt(self, prompt_type):
        file = ""
        if prompt_type == "c2r":
            file = "c2r.txt"
        elif prompt_type == "c2r_counter":
            file = "c2r_counter.txt"
        elif prompt_type == "c2r_counter_confidence":
            file = "c2r_counter_confidence.txt"
        elif prompt_type == "c2rcl":
            file = "c2rcl.txt"
        elif prompt_type == "c2r_new":
            file = "c2r_new.txt"
        elif prompt_type == "c2r_consensus":
            file = "c2r_consensus.txt"
        elif prompt_type == "base":
            file = "base.txt"
        elif prompt_type == "cot":
            file = "cot.txt"
        elif prompt_type == "fs":
            file = "fs.txt"
        elif prompt_type == "zs":
            file = "zs.txt"
        elif prompt_type == "algo_line":
            file = "algo_line.txt"
        prompt_file = self.prompt_path + file
        prompt = ""
        try:
            with open(prompt_file, 'r') as file:
                prompt = file.read()
        except FileNotFoundError:
            print(f"Error: The file {prompt_file} does not exist.")
        except Exception as e:
            print(f"An error occurred: {e}")
        return prompt


    def parse_schema(self, schema):
        """Parse schema string into nodes and edges."""
        nodes_section = False
        edges_section = False
        nodes = []
        edges = []

        for line in schema.strip().splitlines():
            line = line.strip()
            if line == "<nodes>":
                nodes_section = True
                continue
            elif line == "</nodes>":
                nodes_section = False
                continue
            elif line == "<edges>":
                edges_section = True
                continue
            elif line == "</edges>":
                edges_section = False
                continue

            if nodes_section and line:
                nodes.append(line)
            elif edges_section and line:
                # Parse edge while preserving the relationship type
                line = line.strip("[]")
                src, rel, dst = [item.strip() for item in line.split(",")]
                edges.append([src, rel, dst])

        return nodes, edges

    def build_graph(self, edges):
        """Build directed graph with edge information."""
        graph = defaultdict(list)
        edge_info = {}  # Store edge relationship types
        for src, rel, dst in edges:
            graph[src].append(dst)
            edge_info[(src, dst)] = rel

        return graph, edge_info

    def bfs_paths(self, graph, start_node, max_length):
        """BFS to find all paths up to max_length."""
        visited_paths = set()
        queue = deque([(start_node, [start_node], 0)])
        all_paths = []
        while queue:
            current_node, path, depth = queue.popleft()

            if depth <= max_length:
                all_paths.append(path)

                if depth < max_length:
                    for neighbor in graph[current_node]:
                        new_path = path + [neighbor]
                        path_key = tuple(new_path)

                        if path_key not in visited_paths:
                            visited_paths.add(path_key)
                            queue.append((neighbor, new_path, depth + 1))

        return all_paths

    def extract_subgraph_edges(self, paths, edge_info):
        """Extract edges from paths while preserving relationship types."""
        subgraph_edges = set()
        for path in paths:
            for i in range(len(path) - 1):
                src, dst = path[i], path[i + 1]
                rel = edge_info.get((src, dst))
                if rel:
                    subgraph_edges.add((src, rel, dst))

        return subgraph_edges

    def extract_subschema(self, schema, input_predicate, max_length):
        """Extract subschema centered on input_predicate up to max_length."""
        nodes, edges = self.parse_schema(schema)
        graph, edge_info = self.build_graph(edges)

        # Find all paths starting from input_predicate
        all_paths = self.bfs_paths(graph, input_predicate, max_length)

        # Extract relevant edges with relationship types
        subgraph_edges = self.extract_subgraph_edges(all_paths, edge_info)

        # Collect nodes that appear in the subgraph
        nodes_in_subgraph = {node.split("[")[0] for edge in subgraph_edges for node in (edge[0], edge[2])}
        sub_nodes = [node for node in nodes if node.split("[")[0] in nodes_in_subgraph]

        # Format subschema
        sub_nodes_str = "<nodes>\n" + "\n".join(sorted(sub_nodes)) + "\n</nodes>"
        sub_edges_str = "<edges>\n" + "\n".join(
            f"[{src}, {rel}, {dst}]" for src, rel, dst in sorted(subgraph_edges)) + "\n</edges>"

        return sub_nodes_str + "\n" + sub_edges_str
