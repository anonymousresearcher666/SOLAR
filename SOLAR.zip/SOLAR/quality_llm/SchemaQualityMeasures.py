import re
import numpy as np
from typing import Dict, List, Tuple, Set
from dataclasses import dataclass
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity


@dataclass
class Predicate:
    name: str
    domain: str
    range: str


@dataclass
class Rule:
    head: Predicate
    body: List[Predicate]

    def __str__(self):
        body_str = " ∧ ".join([f"{p.name}(x,z)" for p in self.body])
        return f"{self.head.name}(x,y) ← {body_str}"


class RuleParser:
    """Parse rules from string format like 'actedIn(X,Y) :- playsFor(X,Z), CreativeWork(Z,Y)'"""

    def __init__(self, schema: Dict[str, Predicate]):
        self.schema = schema

    def parse_rule(self, rule_string: str) -> Rule:
        """
        Parse a rule string into a Rule object.

        Args:
            rule_string: String like "actedIn(X,Y) :- playsFor(X,Z), CreativeWork(Z,Y)"

        Returns:
            Rule object
        """
        # Clean the rule string
        rule_string = rule_string.strip()

        # Split head and body
        if ':-' in rule_string:
            head_str, body_str = rule_string.split(':-', 1)
        else:
            raise ValueError(f"Invalid rule format: {rule_string}")

        # Parse head
        head_predicate = self._parse_predicate(head_str.strip())

        # Parse body predicates using regex to handle commas inside parentheses
        body_predicates = []
        if body_str.strip():
            body_predicates = self._parse_body_predicates(body_str.strip())

        return Rule(head=head_predicate, body=body_predicates)

    def _parse_body_predicates(self, body_str: str) -> List[Predicate]:
        """
        Parse body predicates handling commas both as separators and inside parentheses.

        Args:
            body_str: String like "playsFor(X,Z), CreativeWork(Z,Y)"

        Returns:
            List of Predicate objects
        """
        predicates = []

        # Use regex to find all predicate patterns
        # This pattern matches: predicate_name(arg1,arg2,...)
        predicate_pattern = r'(\w+)\s*\([^)]+\)'
        matches = re.findall(predicate_pattern, body_str)

        # Extract full predicate strings
        full_predicates = re.findall(r'\w+\s*\([^)]+\)', body_str)

        for pred_str in full_predicates:
            predicates.append(self._parse_predicate(pred_str.strip()))

        return predicates

    def _parse_predicate(self, pred_string: str) -> Predicate:
        """
        Parse a predicate string like 'actedIn(X,Y)' into a Predicate object.

        Args:
            pred_string: String like "actedIn(X,Y)"

        Returns:
            Predicate object
        """
        # Extract predicate name and arguments
        match = re.match(r'(\w+)\s*\(\s*([^)]+)\s*\)', pred_string.strip())
        if not match:
            raise ValueError(f"Invalid predicate format: '{pred_string}'")

        pred_name = match.group(1)
        args = [arg.strip() for arg in match.group(2).split(',')]

        # Look up predicate in schema
        if pred_name in self.schema:
            return self.schema[pred_name]
        else:
            # If not in schema, create a generic predicate
            print(f"Warning: Predicate {pred_name} not found in schema")
            return Predicate(pred_name, "Unknown", "Unknown")

    def parse_rules(self, rule_strings: List[str]) -> List[Rule]:
        """Parse multiple rule strings into Rule objects."""
        return [self.parse_rule(rule_str) for rule_str in rule_strings]


class SchemaLevelEvaluator:
    """
    Implements Schema Consistency Score (SCS), Semantic Coherence Score (SeCS),
    and Schema Coverage Score (CovS) for rule quality assessment.
    """

    def __init__(self, schema: Dict[str, Predicate], similarity_model: str = 'all-MiniLM-L6-v2'):
        """
        Initialize evaluator with schema and similarity model.

        Args:
            schema: Dictionary mapping predicate names to Predicate objects
            similarity_model: SentenceTransformer model for semantic similarity
        """
        self.schema = schema
        self.parser = RuleParser(schema)
        self.similarity_model = SentenceTransformer(similarity_model)
        self._predicate_embeddings = {}

    def _get_predicate_embedding(self, predicate_name: str) -> np.ndarray:
        """Get or compute embedding for a predicate."""
        if predicate_name not in self._predicate_embeddings:
            self._predicate_embeddings[predicate_name] = self.similarity_model.encode([predicate_name])
        return self._predicate_embeddings[predicate_name]

    def _compute_similarity(self, pred1: str, pred2: str) -> float:
        """Compute semantic similarity between two predicates."""
        emb1 = self._get_predicate_embedding(pred1)
        emb2 = self._get_predicate_embedding(pred2)
        return cosine_similarity(emb1, emb2)[0][0]

    def schema_consistency_score(self, rules: List[Rule]) -> float:
        """
        Compute Schema Consistency Score (SCS) for a set of rules.

        SCS(R) = (1/|R|) * Σ(1 - violations(r)/constraints(r))
        """
        if not rules:
            return 0.0

        total_score = 0.0

        for rule in rules:
            violations = 0
            constraints = 0

            # Check head compatibility with first body predicate
            if rule.body:
                first_pred = rule.body[0]
                constraints += 1
                if (first_pred.domain != rule.head.domain or
                        first_pred.name not in self.schema):
                    violations += 1

            # Check consecutive body predicates
            for i in range(len(rule.body) - 1):
                current_pred = rule.body[i]
                next_pred = rule.body[i + 1]
                constraints += 1

                # Type compatibility: range of current must match domain of next
                if (current_pred.range != next_pred.domain or
                        current_pred.name not in self.schema or
                        next_pred.name not in self.schema):
                    violations += 1

            # Check last body predicate with head
            if rule.body:
                last_pred = rule.body[-1]
                constraints += 1
                if last_pred.range != rule.head.range:
                    violations += 1

            # Calculate rule score
            if constraints > 0:
                rule_score = 1.0 - (violations / constraints)
            else:
                rule_score = 1.0

            total_score += rule_score

        return total_score / len(rules)

    def semantic_coherence_score(self, rules: List[Rule]) -> float:
        """
        Compute Semantic Coherence Score (SeCS) for a set of rules.

        SeCS(R) = (1/|R|) * Σ(1/|path(r)|) * Σ sim(p_i, p_{i+1})
        """
        if not rules:
            return 0.0

        total_score = 0.0

        for rule in rules:
            if len(rule.body) <= 1:
                # Single predicate rule gets perfect coherence
                total_score += 1.0
                continue

            path_similarity = 0.0

            # Compute similarity between consecutive predicates
            for i in range(len(rule.body) - 1):
                pred1 = rule.body[i].name
                pred2 = rule.body[i + 1].name
                similarity = self._compute_similarity(pred1, pred2)
                path_similarity += similarity

            # Average over path length
            rule_score = path_similarity / (len(rule.body) - 1)
            total_score += rule_score

        return total_score / len(rules)

    def schema_coverage_score(self, rules: List[Rule], target_predicate: str) -> float:
        """
        Compute Schema Coverage Score (CovS) for rules targeting a specific predicate.

        CovS(R_p) = |predicates_in_bodies(R_p)| / |candidate_predicates(p)|
        """
        if not rules:
            return 0.0

        # Get predicates used in rule bodies
        used_predicates = set()
        for rule in rules:
            for pred in rule.body:
                used_predicates.add(pred.name)

        # Get candidate predicates (those that can form valid paths to target)
        candidate_predicates = self._get_candidate_predicates(target_predicate)

        if not candidate_predicates:
            return 1.0 if not used_predicates else 0.0

        return len(used_predicates) / len(candidate_predicates)

    def _get_candidate_predicates(self, target_predicate: str) -> Set[str]:
        """Get predicates that can form valid paths to target predicate."""
        if target_predicate not in self.schema:
            return set()

        target_domain = self.schema[target_predicate].domain
        target_range = self.schema[target_predicate].range

        candidates = set()

        # Find predicates that can connect to target predicate
        for pred_name, pred in self.schema.items():
            # Can be first in path if domain matches target domain
            if pred.domain == target_domain:
                candidates.add(pred_name)
            # Can be in path if range can connect to target domain
            if pred.range == target_domain:
                candidates.add(pred_name)
            # Can be last in path if range matches target range
            if pred.range == target_range:
                candidates.add(pred_name)

        return candidates

    def evaluate_rules_from_strings(self, rule_strings: List[str], target_predicate: str) -> Dict[str, float]:
        """
        Evaluate rules from string format.

        Args:
            rule_strings: List of rule strings like ["actedIn(X,Y) :- playsFor(X,Z), CreativeWork(Z,Y)"]
            target_predicate: Name of target predicate for coverage calculation

        Returns:
            Dictionary with SCS, SeCS, and CovS scores
        """
        # Parse rules
        rules = self.parser.parse_rules(rule_strings)

        # Evaluate metrics
        return {
            'SCS': self.schema_consistency_score(rules),
            'SeCS': self.semantic_coherence_score(rules),
            'CovS': self.schema_coverage_score(rules, target_predicate)
        }


# Test the fix
if __name__ == "__main__":
    # Define schema
    schema = {
        'actedIn': Predicate('actedIn', 'Person', 'Movie'),
        'playsFor': Predicate('playsFor', 'Person', 'Team'),
        'CreativeWork': Predicate('CreativeWork', 'Team', 'Movie'),
    }

    # Create evaluator
    evaluator = SchemaLevelEvaluator(schema)

    # Test the problematic rule
    rule_strings = [
        "actedIn(X,Y) :- playsFor(X,Z), CreativeWork(Z,Y)"
    ]

    try:
        results = evaluator.evaluate_rules_from_strings(rule_strings, 'actedIn')
        print("Success! Results:", results)
    except Exception as e:
        print(f"Error: {e}")