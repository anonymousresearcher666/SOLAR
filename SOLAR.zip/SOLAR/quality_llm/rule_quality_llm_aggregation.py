import numpy as np
from typing import List, Dict, Tuple, Any, Set, Optional
from dataclasses import dataclass
from enum import Enum
import re
from collections import defaultdict
import hashlib


@dataclass
class Atom:
    """Represents a single atom in a rule"""
    predicate: str
    variables: List[str]

    def __str__(self):
        return f"{self.predicate}({','.join(self.variables)})"

    def normalize_variables(self) -> 'Atom':
        """Normalize variable names to canonical form (X, Y, Z, ...)"""
        var_mapping = {}
        canonical_vars = []
        next_var_index = 0

        for var in self.variables:
            if var not in var_mapping:
                var_mapping[var] = chr(ord('X') + next_var_index)
                next_var_index += 1
            canonical_vars.append(var_mapping[var])

        return Atom(self.predicate, canonical_vars)


@dataclass
class Rule:
    """Represents a logical rule with additional LLM assessment data"""
    head: Atom
    body: List[Atom]
    rule_id: str
    source_agent: Optional[str] = None
    justification: str = ""
    counter_example: str = ""
    assessment: str = ""
    rule_text: str = ""  # Original rule text from LLM

    def __str__(self):
        if not self.body:
            return f"{self.head}"
        body_str = " ∧ ".join([str(atom) for atom in self.body])
        return f"{self.head} ⇐ {body_str}"

    def get_canonical_form(self) -> str:
        """Get canonical string representation for deduplication"""
        # Normalize all variable names consistently across the entire rule
        all_vars = []
        for atom in [self.head] + self.body:
            all_vars.extend(atom.variables)

        unique_vars = list(dict.fromkeys(all_vars))  # Preserve order, remove duplicates
        var_mapping = {var: chr(ord('X') + i) for i, var in enumerate(unique_vars)}

        # Create normalized atoms
        norm_head = Atom(self.head.predicate, [var_mapping[v] for v in self.head.variables])
        norm_body = [Atom(atom.predicate, [var_mapping[v] for v in atom.variables])
                     for atom in self.body]

        # Sort body atoms for canonical ordering
        norm_body.sort(key=lambda a: (a.predicate, tuple(a.variables)))

        # Create canonical string
        if not norm_body:
            return str(norm_head)
        body_str = " ∧ ".join([str(atom) for atom in norm_body])
        return f"{norm_head} ⇐ {body_str}"

    def get_rule_hash(self) -> str:
        """Get hash of canonical form for fast comparison"""
        canonical = self.get_canonical_form()
        return hashlib.md5(canonical.encode()).hexdigest()

    def get_all_variables(self) -> Set[str]:
        """Get all unique variables in the rule"""
        variables = set(self.head.variables)
        for atom in self.body:
            variables.update(atom.variables)
        return variables

    def get_rule_length(self) -> int:
        """Get the length of the rule (number of body atoms)"""
        return len(self.body)


@dataclass
class LLMRuleEntry:
    """Represents a single rule entry from LLM output"""
    predicate: str
    rule_text: str
    justification: str
    counter_example: str
    assessment: str


class LLMOutputParser:
    """Parser for LLM output in the specified format"""

    def __init__(self):
        # Pattern to match rule structure: predicate(args) :- body
        self.rule_pattern = re.compile(r'(\w+)\s*\([^)]+\)\s*:-\s*.*')
        # Pattern to extract predicate and variables
        self.atom_pattern = re.compile(r'(\w+)\s*\(([^)]+)\)')

    def parse_llm_output(self, text: str, agent_id: str) -> List[Rule]:
        """
        Parse LLM output in the format:
        predicate
        rule_text
        Justification: ...
        Counter-example: ...
        Assessment: ...
        """
        rules = []

        # Split by predicate sections (assuming each new predicate starts a new section)
        sections = self._split_into_sections(text)

        rule_counter = 1
        for section in sections:
            try:
                llm_entries = self._parse_section(section)
                for entry in llm_entries:
                    parsed_rule = self._parse_rule_from_entry(entry, agent_id, rule_counter)
                    if parsed_rule:
                        rules.append(parsed_rule)
                        rule_counter += 1
            except Exception as e:
                print(f"Warning: Error parsing section: {e}")
                continue

        return rules

    def _split_into_sections(self, text: str) -> List[str]:
        """Split text into sections by predicate"""
        # Look for standalone predicate names (single words on their own line)
        lines = text.strip().split('\n')
        sections = []
        current_section = []

        for line in lines:
            line = line.strip()
            if not line:
                continue

            # Check if this line is a predicate name (single word, no parentheses or :-)
            if (re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', line) and
                    not any(keyword in line.lower() for keyword in ['justification', 'counter', 'assessment'])):

                # Start new section
                if current_section:
                    sections.append('\n'.join(current_section))
                current_section = [line]
            else:
                current_section.append(line)

        # Don't forget the last section
        if current_section:
            sections.append('\n'.join(current_section))

        return sections

    def _parse_section(self, section: str) -> List[LLMRuleEntry]:
        """Parse a single section into rule entries"""
        lines = [line.strip() for line in section.split('\n') if line.strip()]

        if not lines:
            return []

        predicate = lines[0]  # First line should be the predicate
        entries = []

        current_rule = None
        current_justification = ""
        current_counter = ""
        current_assessment = ""
        current_field = None

        for line in lines[1:]:  # Skip predicate line
            line_lower = line.lower()

            # Check if this is a new rule (contains :- pattern)
            if ':-' in line:
                # Save previous rule if exists
                if current_rule:
                    entries.append(LLMRuleEntry(
                        predicate=predicate,
                        rule_text=current_rule,
                        justification=current_justification.strip(),
                        counter_example=current_counter.strip(),
                        assessment=current_assessment.strip()
                    ))

                # Start new rule
                current_rule = line
                current_justification = ""
                current_counter = ""
                current_assessment = ""
                current_field = None

            elif line_lower.startswith('justification:'):
                current_justification = line[len('justification:'):].strip()
                current_field = 'justification'
            elif line_lower.startswith('counter-example:') or line_lower.startswith('counter example:'):
                current_counter = line.split(':', 1)[1].strip()
                current_field = 'counter'
            elif line_lower.startswith('assessment:'):
                current_assessment = line[len('assessment:'):].strip()
                current_field = 'assessment'
            else:
                # Continuation of current field
                if current_field == 'justification':
                    current_justification += " " + line
                elif current_field == 'counter':
                    current_counter += " " + line
                elif current_field == 'assessment':
                    current_assessment += " " + line

        # Save the last rule
        if current_rule:
            entries.append(LLMRuleEntry(
                predicate=predicate,
                rule_text=current_rule,
                justification=current_justification.strip(),
                counter_example=current_counter.strip(),
                assessment=current_assessment.strip()
            ))

        return entries

    def _parse_rule_from_entry(self, entry: LLMRuleEntry, agent_id: str, rule_counter: int) -> Optional[Rule]:
        """Parse a rule from an LLM entry"""
        try:
            # Parse the rule text to extract head and body
            if ':-' not in entry.rule_text:
                return None

            head_part, body_part = entry.rule_text.split(':-', 1)
            head_part = head_part.strip()
            body_part = body_part.strip()

            # Parse head atom
            head_match = self.atom_pattern.match(head_part)
            if not head_match:
                return None

            head_predicate = head_match.group(1)
            head_variables = [v.strip() for v in head_match.group(2).split(',')]
            head_atom = Atom(head_predicate, head_variables)

            # Parse body atoms
            body_atoms = []
            # Split by comma, but be careful about commas inside parentheses
            body_parts = self._split_body_atoms(body_part)

            for body_atom_text in body_parts:
                body_atom_text = body_atom_text.strip()
                body_match = self.atom_pattern.match(body_atom_text)
                if body_match:
                    body_predicate = body_match.group(1)
                    body_variables = [v.strip() for v in body_match.group(2).split(',')]
                    body_atoms.append(Atom(body_predicate, body_variables))

            # Create rule
            rule = Rule(
                head=head_atom,
                body=body_atoms,
                rule_id=f"{agent_id}_R{rule_counter}",
                source_agent=agent_id,
                justification=entry.justification,
                counter_example=entry.counter_example,
                assessment=entry.assessment,
                rule_text=entry.rule_text
            )

            return rule

        except Exception as e:
            print(f"Error parsing rule from entry: {e}")
            return None

    def _split_body_atoms(self, body_text: str) -> List[str]:
        """Split body atoms by comma, respecting parentheses"""
        atoms = []
        current_atom = ""
        paren_count = 0

        for char in body_text:
            if char == '(':
                paren_count += 1
            elif char == ')':
                paren_count -= 1
            elif char == ',' and paren_count == 0:
                if current_atom.strip():
                    atoms.append(current_atom.strip())
                current_atom = ""
                continue

            current_atom += char

        if current_atom.strip():
            atoms.append(current_atom.strip())

        return atoms


@dataclass
class AgentRuleSubmission:
    """Represents one agent's rule generation and ranking"""
    agent_id: str
    generated_rules: List[Rule]
    rule_rankings: List[str]  # Rule IDs in order of preference (best first)

    def __post_init__(self):
        # If no rankings provided, create default ranking based on order
        if not self.rule_rankings and self.generated_rules:
            self.rule_rankings = [rule.rule_id for rule in self.generated_rules]

        # Validate that all ranked rules exist in generated rules
        rule_ids = {rule.rule_id for rule in self.generated_rules}
        for ranked_id in self.rule_rankings:
            if ranked_id not in rule_ids:
                print(f"Warning: Agent {self.agent_id} ranked rule {ranked_id} not in generated rules")


@dataclass
class StandardizedRule:
    """Represents a rule after standardization with discovery tracking"""
    canonical_rule: Rule
    canonical_hash: str
    canonical_form: str
    contributing_agents: Set[str]
    original_rule_ids: Dict[str, str]  # agent_id -> original_rule_id
    discovery_count: int
    justifications: Dict[str, str]  # agent_id -> justification
    counter_examples: Dict[str, str]  # agent_id -> counter_example
    assessments: Dict[str, str]  # agent_id -> assessment

    def add_discovery(self, agent_id: str, original_rule_id: str, rule: Rule):
        """Record that an agent discovered this rule"""
        self.contributing_agents.add(agent_id)
        self.original_rule_ids[agent_id] = original_rule_id
        self.justifications[agent_id] = rule.justification
        self.counter_examples[agent_id] = rule.counter_example
        self.assessments[agent_id] = rule.assessment
        self.discovery_count = len(self.contributing_agents)


@dataclass
class SchemaProperty:
    """Schema property for predicates"""
    predicate: str
    arity: int
    type_signature: List[str]
    is_functional: bool = False


class MultiAgentSchemaPCA:
    """Enhanced Schema-PCA implementation for heterogeneous multi-agent rule generation with LLM assessments"""

    def __init__(self, schema_properties: Dict[str, SchemaProperty],
                 weights: Tuple[float, float, float] = (0.5, 0.2, 0.3),
                 discovery_consensus_weight: float = 0.6):
        """
        Initialize Multi-Agent Schema-PCA

        Args:
            schema_properties: Schema definition
            weights: (semantic_weight, structural_weight, consistency_weight)
            discovery_consensus_weight: Alpha parameter for balancing discovery vs coordinator assessment
        """
        self.schema = schema_properties
        self.semantic_weight, self.structural_weight, self.consistency_weight = weights
        self.alpha = discovery_consensus_weight  # α in the paper's formula
        self.parser = LLMOutputParser()

    def parse_agent_output_from_file(self, file_path: str, agent_id: str) -> AgentRuleSubmission:
        """Parse agent output from a file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            return self.parse_agent_output(content, agent_id)
        except Exception as e:
            print(f"Error reading file {file_path}: {e}")
            return AgentRuleSubmission(agent_id, [], [])

    def parse_agent_output(self, llm_output: str, agent_id: str) -> AgentRuleSubmission:
        """Parse LLM output into AgentRuleSubmission"""
        rules = self.parser.parse_llm_output(llm_output, agent_id)

        # Create default ranking based on order (could be enhanced with actual ranking logic)
        rule_rankings = [rule.rule_id for rule in rules]

        return AgentRuleSubmission(agent_id, rules, rule_rankings)

    def standardize_and_deduplicate(self, agent_submissions: List[AgentRuleSubmission]) -> Dict[str, StandardizedRule]:
        """
        Phase 1: Rule Standardization and Deduplication with LLM assessment tracking
        """
        standardized_rules = {}  # canonical_hash -> StandardizedRule

        print(f"Standardizing rules from {len(agent_submissions)} agents...")

        for submission in agent_submissions:
            agent_id = submission.agent_id
            print(f"  Processing {len(submission.generated_rules)} rules from agent {agent_id}")

            for rule in submission.generated_rules:
                # Set source agent
                rule.source_agent = agent_id

                # Get canonical form and hash
                canonical_form = rule.get_canonical_form()
                canonical_hash = rule.get_rule_hash()

                if canonical_hash in standardized_rules:
                    # Rule already exists - record additional discovery
                    standardized_rules[canonical_hash].add_discovery(agent_id, rule.rule_id, rule)
                    print(f"    Found duplicate rule: {rule.rule_id} -> {canonical_form}")
                else:
                    # New unique rule
                    canonical_rule = Rule(
                        head=rule.head,
                        body=rule.body,
                        rule_id=f"STD_{len(standardized_rules) + 1}",
                        source_agent=agent_id,
                        justification=rule.justification,
                        counter_example=rule.counter_example,
                        assessment=rule.assessment,
                        rule_text=rule.rule_text
                    )

                    standardized_rules[canonical_hash] = StandardizedRule(
                        canonical_rule=canonical_rule,
                        canonical_hash=canonical_hash,
                        canonical_form=canonical_form,
                        contributing_agents={agent_id},
                        original_rule_ids={agent_id: rule.rule_id},
                        discovery_count=1,
                        justifications={agent_id: rule.justification},
                        counter_examples={agent_id: rule.counter_example},
                        assessments={agent_id: rule.assessment}
                    )
                    print(f"    New rule: {rule.rule_id} -> {canonical_rule.rule_id}")

        print(f"Standardization complete: {len(standardized_rules)} unique rules")

        # Print discovery consensus summary
        discovery_counts = defaultdict(int)
        for std_rule in standardized_rules.values():
            discovery_counts[std_rule.discovery_count] += 1

        print("Discovery consensus summary:")
        for count, num_rules in sorted(discovery_counts.items()):
            print(f"  {num_rules} rules discovered by {count} agent(s)")

        return standardized_rules

    def compute_enhanced_semantic_ranking(self, standardized_rules: Dict[str, StandardizedRule],
                                          agent_submissions: List[AgentRuleSubmission],
                                          total_agents: int) -> Dict[str, float]:
        """
        Enhanced semantic ranking with discovery consensus and LLM assessments
        """
        semantic_scores = {}

        # Step 1: Compute discovery scores for each standardized rule
        discovery_scores = {}
        for std_rule in standardized_rules.values():
            discovery_score = std_rule.discovery_count / total_agents
            discovery_scores[std_rule.canonical_rule.rule_id] = discovery_score

        # Step 2: Compute coordinator scores based on agent rankings
        coordinator_scores = self._compute_coordinator_scores(standardized_rules, agent_submissions)

        # Step 3: Combine discovery and coordinator scores
        for rule_id in discovery_scores:
            discovery_score = discovery_scores[rule_id]
            coordinator_score = coordinator_scores.get(rule_id, 0.0)

            semantic_score = (self.alpha * discovery_score +
                              (1 - self.alpha) * coordinator_score)
            semantic_scores[rule_id] = semantic_score

        return semantic_scores

    def _compute_coordinator_scores(self, standardized_rules: Dict[str, StandardizedRule],
                                    agent_submissions: List[AgentRuleSubmission]) -> Dict[str, float]:
        """Compute coordinator assessment scores from individual agent rankings"""
        coordinator_scores = {}
        total_agents = len(agent_submissions)

        # For each standardized rule, collect its rankings from agents that discovered it
        for std_rule in standardized_rules.values():
            std_rule_id = std_rule.canonical_rule.rule_id
            collected_ranks = []

            # Find rankings from agents that discovered this rule
            for submission in agent_submissions:
                if submission.agent_id in std_rule.contributing_agents:
                    original_rule_id = std_rule.original_rule_ids[submission.agent_id]

                    # Find position in agent's ranking
                    try:
                        rank_position = submission.rule_rankings.index(original_rule_id)
                        # Convert to score (higher rank = lower position = higher score)
                        num_rules_ranked = len(submission.rule_rankings)
                        rank_score = (num_rules_ranked - rank_position) / num_rules_ranked
                        collected_ranks.append(rank_score)
                    except ValueError:
                        # Rule was generated but not ranked by this agent
                        collected_ranks.append(0.0)

            # Average the collected ranking scores
            if collected_ranks:
                coordinator_scores[std_rule_id] = np.mean(collected_ranks)
            else:
                coordinator_scores[std_rule_id] = 0.0

        return coordinator_scores

    def structural_ranking(self, rules: List[Rule]) -> Dict[str, float]:
        """Compute structural complexity scores"""
        structural_scores = {}

        for rule in rules:
            # Basic complexity metrics
            rule_length = rule.get_rule_length()
            variable_count = len(rule.get_all_variables())

            # Join complexity
            join_count = 0
            for i, atom1 in enumerate(rule.body):
                for atom2 in rule.body[i + 1:]:
                    shared_vars = set(atom1.variables) & set(atom2.variables)
                    join_count += len(shared_vars)

            # Compute complexity score (lower = better, so we invert for scoring)
            complexity = rule_length + (join_count * 0.5) + (variable_count * 0.1)

            # Convert to score (higher = better)
            structural_scores[rule.rule_id] = 1.0 / (1.0 + complexity)

        return structural_scores

    def consistency_ranking(self, rules: List[Rule]) -> Dict[str, float]:
        """Compute type consistency scores"""
        consistency_scores = {}

        for rule in rules:
            violations = self._count_type_violations(rule)
            # Score based on violations (fewer violations = higher score)
            consistency_scores[rule.rule_id] = max(0.0, 1.0 - (violations * 0.2))

        return consistency_scores

    def _count_type_violations(self, rule: Rule) -> int:
        """Count type constraint violations in a rule"""
        violations = 0

        # Check head predicate exists
        head_prop = self.schema.get(rule.head.predicate)
        if not head_prop:
            violations += 1
            return violations

        # Check head arity
        if len(rule.head.variables) != head_prop.arity:
            violations += 1

        # Track variable types
        var_types = {}

        # Process body atoms
        for atom in rule.body:
            body_prop = self.schema.get(atom.predicate)
            if not body_prop:
                violations += 1
                continue

            if len(atom.variables) != body_prop.arity:
                violations += 1
                continue

            # Type consistency check
            for i, var in enumerate(atom.variables):
                if i < len(body_prop.type_signature):
                    expected_type = body_prop.type_signature[i]
                    if var in var_types and var_types[var] != expected_type:
                        violations += 1
                    else:
                        var_types[var] = expected_type

        # Check head variable types
        for i, var in enumerate(rule.head.variables):
            if i < len(head_prop.type_signature):
                expected_type = head_prop.type_signature[i]
                if var in var_types and var_types[var] != expected_type:
                    violations += 1
                elif var not in var_types:
                    violations += 1  # Ungrounded variable

        return violations

    def compute_final_ranking_by_predicate(self, agent_submissions: List[AgentRuleSubmission]) -> Dict[
        str, List[Tuple[Rule, float, Dict[str, Any]]]]:
        """
        Complete Multi-Agent Schema-PCA evaluation GROUPED BY PREDICATE

        Returns:
            Dictionary mapping predicate -> List of (rule, final_score, analysis) tuples sorted by quality
        """
        print("Starting Multi-Agent Schema-PCA evaluation BY PREDICATE...")

        # Phase 1: Standardization and Deduplication
        standardized_rules = self.standardize_and_deduplicate(agent_submissions)

        if not standardized_rules:
            return {}

        # Group standardized rules by predicate
        rules_by_predicate = defaultdict(list)
        for std_rule in standardized_rules.values():
            predicate = std_rule.canonical_rule.head.predicate
            rules_by_predicate[predicate].append(std_rule.canonical_rule)

        print(f"\nFound rules for {len(rules_by_predicate)} predicates:")
        for predicate, rules in rules_by_predicate.items():
            print(f"  {predicate}: {len(rules)} unique rules")

        total_agents = len(agent_submissions)
        results_by_predicate = {}

        # Process each predicate separately
        for predicate, rules in rules_by_predicate.items():
            print(f"\n🔄 Analyzing predicate: {predicate}")
            print(f"   Computing quality scores for {len(rules)} rules...")

            # Phase 2: Multi-dimensional ranking for this predicate
            semantic_scores = self.compute_enhanced_semantic_ranking(
                standardized_rules, agent_submissions, total_agents)
            structural_scores = self.structural_ranking(rules)
            consistency_scores = self.consistency_ranking(rules)

            # Compute final weighted scores for this predicate
            predicate_results = []

            for rule in rules:
                rule_id = rule.rule_id
                std_rule = None
                for sr in standardized_rules.values():
                    if sr.canonical_rule.rule_id == rule_id:
                        std_rule = sr
                        break

                semantic_score = semantic_scores.get(rule_id, 0.0)
                structural_score = structural_scores.get(rule_id, 0.0)
                consistency_score = consistency_scores.get(rule_id, 0.0)

                # Weighted combination
                final_score = (self.semantic_weight * semantic_score +
                               self.structural_weight * structural_score +
                               self.consistency_weight * consistency_score)

                # Detailed analysis including LLM assessments
                analysis = {
                    'final_score': final_score,
                    'semantic_score': semantic_score,
                    'structural_score': structural_score,
                    'consistency_score': consistency_score,
                    'rule_length': rule.get_rule_length(),
                    'discovery_count': std_rule.discovery_count if std_rule else 0,
                    'contributing_agents': list(std_rule.contributing_agents) if std_rule else [],
                    'canonical_form': std_rule.canonical_form if std_rule else str(rule),
                    'original_rule_ids': dict(std_rule.original_rule_ids) if std_rule else {},
                    'justifications': dict(std_rule.justifications) if std_rule else {},
                    'counter_examples': dict(std_rule.counter_examples) if std_rule else {},
                    'assessments': dict(std_rule.assessments) if std_rule else {},
                    'rule_text': rule.rule_text,
                    'predicate': predicate
                }

                predicate_results.append((rule, final_score, analysis))

            # Sort by final score (descending) within this predicate
            predicate_results.sort(key=lambda x: x[1], reverse=True)
            results_by_predicate[predicate] = predicate_results

            print(f"   ✅ {predicate}: {len(predicate_results)} rules ranked")

        print("Multi-Agent Schema-PCA evaluation BY PREDICATE complete!")
        return results_by_predicate

    def print_ranking_results_by_predicate(self,
                                           results_by_predicate: Dict[str, List[Tuple[Rule, float, Dict[str, Any]]]]):
        """Print detailed ranking results GROUPED BY PREDICATE"""
        print("\n" + "=" * 100)
        print("MULTI-AGENT SCHEMA-PCA RANKING RESULTS BY PREDICATE")
        print("=" * 100)
        print(
            f"Weights: Semantic={self.semantic_weight}, Structural={self.structural_weight}, Consistency={self.consistency_weight}")
        print(f"Discovery Consensus Weight (α): {self.alpha}")
        print()

        # Sort predicates by name for consistent output
        for predicate in sorted(results_by_predicate.keys()):
            results = results_by_predicate[predicate]

            print(f"{'=' * 20} PREDICATE: {predicate.upper()} {'=' * 20}")
            print(f"Total rules for {predicate}: {len(results)}")
            print()

            for i, (rule, final_score, analysis) in enumerate(results):
                print(f"  RANK {i + 1}: {rule}")
                print(f"    Final Score: {final_score:.3f}")
                print(f"    - Semantic: {analysis['semantic_score']:.3f}")
                print(f"    - Structural: {analysis['structural_score']:.3f}")
                print(f"    - Consistency: {analysis['consistency_score']:.3f}")
                print(f"    Discovery Count: {analysis['discovery_count']} agents")
                print(f"    Contributing Agents: {analysis['contributing_agents']}")
                print(f"    Rule Length: {analysis['rule_length']}")

                # Print LLM assessments (truncated for readability)
                if analysis['justifications']:
                    print(f"    Justifications:")
                    for agent, justification in analysis['justifications'].items():
                        print(f"      {agent}: {justification[:80]}..." if len(
                            justification) > 80 else f"      {agent}: {justification}")

                if analysis['counter_examples']:
                    print(f"    Counter-examples:")
                    for agent, counter in analysis['counter_examples'].items():
                        print(f"      {agent}: {counter[:80]}..." if len(counter) > 80 else f"      {agent}: {counter}")

                if analysis['assessments']:
                    print(f"    Assessments:")
                    for agent, assessment in analysis['assessments'].items():
                        print(f"      {agent}: {assessment[:80]}..." if len(
                            assessment) > 80 else f"      {agent}: {assessment}")

                print()

            print()  # Extra line between predicates


# Example usage function
def process_agent_files(file_paths: List[str], agent_ids: List[str], schema: Dict[str, SchemaProperty]) -> List[
    Tuple[Rule, float, Dict[str, Any]]]:
    """
    Process multiple agent output files and return ranked results

    Args:
        file_paths: List of file paths containing LLM outputs
        agent_ids: List of agent identifiers
        schema: Schema definition

    Returns:
        Ranked list of rules with scores and analysis
    """
    evaluator = MultiAgentSchemaPCA(schema, discovery_consensus_weight=0.7)

    # Parse agent outputs
    agent_submissions = []
    for file_path, agent_id in zip(file_paths, agent_ids):
        submission = evaluator.parse_agent_output_from_file(file_path, agent_id)
        agent_submissions.append(submission)
        print(f"Loaded {len(submission.generated_rules)} rules from {agent_id}")

    # Compute ranking
    results = evaluator.compute_final_ranking(agent_submissions)

    # Print results
    evaluator.print_ranking_results(results)

    return results

    # Demo function with the new format


def demo_with_llm_output():
    """Demonstrate parsing of the specified LLM output format"""

    # Example LLM output in the specified format
    sample_output = """actedIn
actedIn(X,Y) :- isLeaderOf(X,Z), created(Z,Y)
Justification: A person who is a leader of an organization that created a creative work is likely to have acted in that work, especially if the organization is a production company.
Counter-example: The leader of an organization might not necessarily be an actor or have acted in the creative work.
Assessment: The rule is logically coherent but may not always hold true in practice, as organizational leaders are not always actors.

actedIn(X,Y) :- hasChild(X,Z), actedIn(Z,Y)
Justification: A person who has a child who has acted in a creative work might also have acted in the same work, especially if they are part of a family of actors.
Counter-example: Parents and children might act in different works or not act at all.
Assessment: The rule captures a familial relationship but may not be universally applicable.

nationality
nationality(X,Y) :- bornIn(X,Y)
Justification: A person's nationality is typically determined by their place of birth.
Counter-example: Some people may have different nationality than their birth country due to naturalization or citizenship laws.
Assessment: This is a strong rule that holds in many cases but has exceptions due to complex citizenship laws.

nationality(X,Y) :- parentOf(Z,X), nationality(Z,Y)
Justification: Children often inherit their nationality from their parents.
Counter-example: In some countries, nationality is not automatically inherited from parents.
Assessment: This rule represents a common inheritance pattern but is subject to specific legal frameworks."""

    # Create demo schema
    schema = {
        'actedIn': SchemaProperty('actedIn', 2, ['Person', 'CreativeWork']),
        'isLeaderOf': SchemaProperty('isLeaderOf', 2, ['Person', 'Organization']),
        'created': SchemaProperty('created', 2, ['Organization', 'CreativeWork']),
        'hasChild': SchemaProperty('hasChild', 2, ['Person', 'Person']),
        'nationality': SchemaProperty('nationality', 2, ['Person', 'Country']),
        'bornIn': SchemaProperty('bornIn', 2, ['Person', 'Country']),
        'parentOf': SchemaProperty('parentOf', 2, ['Person', 'Person']),
    }

    print("=== DEMO: LLM OUTPUT PARSING ===\n")
    print("Sample LLM Output:")
    print("-" * 50)
    print(sample_output[:200] + "...")
    print("-" * 50)

    # Initialize evaluator
    evaluator = MultiAgentSchemaPCA(schema, discovery_consensus_weight=0.7)

    # Parse the output
    print("\nParsing LLM output...")
    submission = evaluator.parse_agent_output(sample_output, "Agent1")

    print(f"\nParsed {len(submission.generated_rules)} rules:")
    for rule in submission.generated_rules:
        print(f"  {rule.rule_id}: {rule}")
        print(f"    Justification: {rule.justification[:50]}...")
        print(f"    Counter-example: {rule.counter_example[:50]}...")
        print(f"    Assessment: {rule.assessment[:50]}...")
        print()

    # Create a second agent with some overlapping rules for demo
    sample_output2 = """actedIn
actedIn(X,Y) :- isLeaderOf(X,Z), created(Z,Y)
Justification: Leaders of production companies often act in their own works.
Counter-example: Not all organizational leaders are performers.
Assessment: Strong logical connection but context-dependent.

worksFor
worksFor(X,Y) :- actedIn(X,Z), produced(Y,Z)
Justification: Actors often work for the companies that produce their films.
Counter-example: Actors might be freelance or work through agencies.
Assessment: Reasonable connection but not always direct employment."""

    # Add worksFor to schema for this demo
    schema['worksFor'] = SchemaProperty('worksFor', 2, ['Person', 'Organization'])
    schema['produced'] = SchemaProperty('produced', 2, ['Organization', 'CreativeWork'])

    submission2 = evaluator.parse_agent_output(sample_output2, "Agent2")

    print(f"Agent2 parsed {len(submission2.generated_rules)} rules")

    # Run multi-agent evaluation
    print("\n=== MULTI-AGENT EVALUATION ===")
    results = evaluator.compute_final_ranking([submission, submission2])

    # Show top results
    print(f"\nTop 3 Rules:")
    for i, (rule, score, analysis) in enumerate(results[:3]):
        print(f"\n{i + 1}. {rule} (Score: {score:.3f})")
        print(f"   Discovery: {analysis['discovery_count']} agents")
        if analysis['justifications']:
            agent_id = list(analysis['justifications'].keys())[0]
            print(f"   Justification: {analysis['justifications'][agent_id][:80]}...")


def create_schema_from_file(file_path: str) -> Dict[str, SchemaProperty]:
    """
    Create schema from file with nodes and edges format:

    Format:
    predicate[domain,range]
    predicate[domain,range]
    </nodes>
    <edges>
    [predicate,domain,range]
    [predicate,domain,range]
    """
    schema = {}

    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        # Split into nodes and edges sections
        parts = content.split('</nodes>')

        if len(parts) >= 1:
            # Process nodes section
            nodes_section = parts[0].strip()
            for line in nodes_section.split('\n'):
                line = line.strip()
                if line and '[' in line and ']' in line:
                    # Parse: predicate[domain,range]
                    predicate = line.split('[')[0].strip()
                    types_part = line.split('[')[1].split(']')[0]
                    types = [t.strip() for t in types_part.split(',')]

                    if len(types) >= 2:
                        schema[predicate] = SchemaProperty(
                            predicate=predicate,
                            arity=len(types),
                            type_signature=types
                        )

        if len(parts) >= 2:
            # Process edges section
            edges_section = parts[1].strip()
            if '<edges>' in edges_section:
                edges_section = edges_section.split('<edges>')[1].strip()

            for line in edges_section.split('\n'):
                line = line.strip()
                if line and line.startswith('[') and line.endswith(']'):
                    # Parse: [predicate,domain,range]
                    content_part = line[1:-1]  # Remove [ and ]
                    parts_list = [p.strip() for p in content_part.split(',')]

                    if len(parts_list) >= 3:
                        predicate = parts_list[0]
                        types = parts_list[1:]

                        schema[predicate] = SchemaProperty(
                            predicate=predicate,
                            arity=len(types),
                            type_signature=types
                        )

        print(f"Loaded schema with {len(schema)} predicates from {file_path}")
        return schema

    except Exception as e:
        print(f"Error reading schema file {file_path}: {e}")
        return create_demo_schema()  # Fallback to demo schema
def create_demo_schema() -> Dict[str, SchemaProperty]:
    """Create comprehensive demo schema for testing"""
    return {
        'almaMater': SchemaProperty('almaMater', 2, ['Person', 'EducationalInstitution']),
        'worksFor': SchemaProperty('worksFor', 2, ['Person', 'Organization']),
        'enrolledIn': SchemaProperty('enrolledIn', 2, ['Person', 'Course']),
        'department': SchemaProperty('department', 2, ['Course', 'EducationalInstitution']),
        'graduatedFrom': SchemaProperty('graduatedFrom', 2, ['Person', 'AcademicProgram']),
        'isPartOf': SchemaProperty('isPartOf', 2, ['AcademicProgram', 'EducationalInstitution']),
        'nationality': SchemaProperty('nationality', 2, ['Person', 'Country']),
        'birthPlace': SchemaProperty('birthPlace', 2, ['Person', 'Place']),
        'residence': SchemaProperty('residence', 2, ['Person', 'Place']),
        'actedIn': SchemaProperty('actedIn', 2, ['Person', 'CreativeWork']),
        'isLeaderOf': SchemaProperty('isLeaderOf', 2, ['Person', 'Organization']),
        'created': SchemaProperty('created', 2, ['Organization', 'CreativeWork']),
        'hasChild': SchemaProperty('hasChild', 2, ['Person', 'Person']),
        'bornIn': SchemaProperty('bornIn', 2, ['Person', 'Country']),
        'parentOf': SchemaProperty('parentOf', 2, ['Person', 'Person']),
    }


# Integration function for use with the rule extractor
def integrate_with_rule_extractor(rule_extractor_output_path: str, agent_id: str, schema_path: Optional[str] = None) -> \
List[Tuple[Rule, float, Dict[str, Any]]]:
    """
    Integrate with the rule extractor output to perform Schema-PCA evaluation

    Args:
        rule_extractor_output_path: Path to the rule extractor's minimal output file
        agent_id: Identifier for the agent
        schema_path: Optional path to schema definition file

    Returns:
        Ranked list of rules with scores and analysis
    """

    # Use demo schema if no schema provided
    if schema_path is None:
        schema = create_demo_schema()
    else:
        # Load schema from file (implement based on your schema format)
        schema = create_demo_schema()  # Placeholder

    # Read the rule extractor output
    try:
        with open(rule_extractor_output_path, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception as e:
        print(f"Error reading rule extractor output: {e}")
        return []

    # Initialize evaluator and parse
    evaluator = MultiAgentSchemaPCA(schema, discovery_consensus_weight=0.7)
    submission = evaluator.parse_agent_output(content, agent_id)

    # Compute ranking for single agent (can be extended for multiple agents)
    results = evaluator.compute_final_ranking([submission])

    return results


# Main execution with file reading configuration
if __name__ == "__main__":
    # CONFIGURATION - SET YOUR EXPERIMENT DETAILS
    COORDINATOR_LLM = "ollama_gemma3:27b"
    participant_models = [
        "ollama_deepseek-r1:1.5b",
        "ollama_qwen2.5:72b",
        "ollama_qwen3:30b-a3b"
    ]
    dataset="family"
    schema_encoding="line"
    schema_file="/SOLAR/dataset/"+dataset+"/line_graph.txt"

    # CHOOSE WHAT TO ANALYZE WITH SCHEMA-PCA:
    # -1: Coordinator only
    #  0: Agent1 (first participant)
    #  1: Agent2 (second participant)
    #  2: Agent3 (third participant)
    # -2: All individual agents
    # -3: Consensus results only
    # -4: Everything (individual + consensus)
    index_llm = -2  # SET THIS TO CHOOSE WHAT TO ANALYZE

    # Base paths
    BASE_EXPERIMENT_PATH = "/SOLAR/gen_rules/"+dataset+"/c2r_new/"+schema_encoding+"/2/two_phase_consensus_" + COORDINATOR_LLM
    INDIVIDUAL_EXPERIMENT_PATH = f"{BASE_EXPERIMENT_PATH}/individual_rules"
    CONSENSUS_EXPERIMENT_PATH = f"{BASE_EXPERIMENT_PATH}/consensus_results"

    # Create schema (you can modify this for your specific predicates)
    schema = create_schema_from_file(file_path=schema_file)# create_demo_schema()

    # Initialize Schema-PCA evaluator
    evaluator = MultiAgentSchemaPCA(schema, discovery_consensus_weight=0.7)

    print("🎯 MULTI-AGENT SCHEMA-PCA ANALYSIS")
    print("=" * 50)
    print(f"Coordinator LLM: {COORDINATOR_LLM}")
    print(f"Participant Models: {participant_models}")
    print(f"Analysis Selection (index_llm): {index_llm}")

    # Collect agent submissions based on selection
    agent_submissions = []

    if index_llm == -1:
        # Coordinator only
        coord_path = f"{INDIVIDUAL_EXPERIMENT_PATH}/Coordinator_{COORDINATOR_LLM}"
        print(f"\n🔄 Loading Coordinator: {COORDINATOR_LLM}")

        # Look for rule files in the coordinator directory
        from pathlib import Path

        coord_dir = Path(coord_path)
        if coord_dir.exists():
            # Look for .txt files (from your rule extractor output)
            txt_files = list(coord_dir.glob("*.txt"))
            if txt_files:
                # Use the first txt file or combine multiple files
                combined_content = ""
                for txt_file in txt_files:
                    print(f"  Reading: {txt_file.name}")
                    with open(txt_file, 'r', encoding='utf-8') as f:
                        combined_content += f.read() + "\n\n"

                submission = evaluator.parse_agent_output(combined_content, "Coordinator")
                agent_submissions.append(submission)
                print(f"  Loaded {len(submission.generated_rules)} rules")
            else:
                print(f"  ⚠️ No .txt files found in {coord_path}")
        else:
            print(f"  ⚠️ Path not found: {coord_path}")

    elif 0 <= index_llm < len(participant_models):
        # Specific agent
        agent_model = participant_models[index_llm]
        agent_path = f"{INDIVIDUAL_EXPERIMENT_PATH}/Agent{index_llm + 1}_{agent_model}"
        print(f"\n🔄 Loading Agent {index_llm + 1}: {agent_model}")

        from pathlib import Path

        agent_dir = Path(agent_path)
        if agent_dir.exists():
            txt_files = list(agent_dir.glob("*.txt"))
            if txt_files:
                combined_content = ""
                for txt_file in txt_files:
                    print(f"  Reading: {txt_file.name}")
                    with open(txt_file, 'r', encoding='utf-8') as f:
                        combined_content += f.read() + "\n\n"

                submission = evaluator.parse_agent_output(combined_content, f"Agent{index_llm + 1}")
                agent_submissions.append(submission)
                print(f"  Loaded {len(submission.generated_rules)} rules")
            else:
                print(f"  ⚠️ No .txt files found in {agent_path}")
        else:
            print(f"  ⚠️ Path not found: {agent_path}")

    elif index_llm == -2:
        # All individual agents
        print(f"\n🔄 Loading ALL INDIVIDUAL AGENTS")

        # Load coordinator
        coord_path = f"{INDIVIDUAL_EXPERIMENT_PATH}/Coordinator_{COORDINATOR_LLM}"
        from pathlib import Path

        coord_dir = Path(coord_path)
        if coord_dir.exists():
            txt_files = list(coord_dir.glob("*.txt"))
            if txt_files:
                combined_content = ""
                for txt_file in txt_files:
                    print(f"  Coordinator - Reading: {txt_file.name}")
                    with open(txt_file, 'r', encoding='utf-8') as f:
                        combined_content += f.read() + "\n\n"

                submission = evaluator.parse_agent_output(combined_content, "Coordinator")
                agent_submissions.append(submission)
                print(f"  Coordinator: {len(submission.generated_rules)} rules")

        # Load all participant agents
        for i, model in enumerate(participant_models):
            agent_path = f"{INDIVIDUAL_EXPERIMENT_PATH}/Agent{i + 1}_{model}"
            agent_dir = Path(agent_path)
            if agent_dir.exists():
                txt_files = list(agent_dir.glob("*.txt"))
                if txt_files:
                    combined_content = ""
                    for txt_file in txt_files:
                        print(f"  Agent {i + 1} - Reading: {txt_file.name}")
                        with open(txt_file, 'r', encoding='utf-8') as f:
                            combined_content += f.read() + "\n\n"

                    submission = evaluator.parse_agent_output(combined_content, f"Agent{i + 1}")
                    agent_submissions.append(submission)
                    print(f"  Agent {i + 1}: {len(submission.generated_rules)} rules")
                else:
                    print(f"  ⚠️ No .txt files found in {agent_path}")
            else:
                print(f"  ⚠️ Path not found: {agent_path}")

    elif index_llm == -3:
        # Consensus results only
        consensus_path = CONSENSUS_EXPERIMENT_PATH
        print(f"\n🔄 Loading CONSENSUS RESULTS")

        from pathlib import Path

        consensus_dir = Path(consensus_path)
        if consensus_dir.exists():
            txt_files = list(consensus_dir.glob("*.txt"))
            if txt_files:
                combined_content = ""
                for txt_file in txt_files:
                    print(f"  Reading: {txt_file.name}")
                    with open(txt_file, 'r', encoding='utf-8') as f:
                        combined_content += f.read() + "\n\n"

                submission = evaluator.parse_agent_output(combined_content, "Consensus")
                agent_submissions.append(submission)
                print(f"  Loaded {len(submission.generated_rules)} rules")
            else:
                print(f"  ⚠️ No .txt files found in {consensus_path}")
        else:
            print(f"  ⚠️ Path not found: {consensus_path}")

    elif index_llm == -4:
        # Everything (individual + consensus)
        print(f"\n🔄 Loading EVERYTHING (Individual + Consensus)")

        from pathlib import Path

        # Load coordinator
        coord_path = f"{INDIVIDUAL_EXPERIMENT_PATH}/Coordinator_{COORDINATOR_LLM}"
        coord_dir = Path(coord_path)
        if coord_dir.exists():
            txt_files = list(coord_dir.glob("*.txt"))
            if txt_files:
                combined_content = ""
                for txt_file in txt_files:
                    with open(txt_file, 'r', encoding='utf-8') as f:
                        combined_content += f.read() + "\n\n"
                submission = evaluator.parse_agent_output(combined_content, "Coordinator")
                agent_submissions.append(submission)
                print(f"  Coordinator: {len(submission.generated_rules)} rules")

        # Load all agents
        for i, model in enumerate(participant_models):
            agent_path = f"{INDIVIDUAL_EXPERIMENT_PATH}/Agent{i + 1}_{model}"
            agent_dir = Path(agent_path)
            if agent_dir.exists():
                txt_files = list(agent_dir.glob("*.txt"))
                if txt_files:
                    combined_content = ""
                    for txt_file in txt_files:
                        with open(txt_file, 'r', encoding='utf-8') as f:
                            combined_content += f.read() + "\n\n"
                    submission = evaluator.parse_agent_output(combined_content, f"Agent{i + 1}")
                    agent_submissions.append(submission)
                    print(f"  Agent {i + 1}: {len(submission.generated_rules)} rules")

        # Load consensus
        consensus_dir = Path(CONSENSUS_EXPERIMENT_PATH)
        if consensus_dir.exists():
            txt_files = list(consensus_dir.glob("*.txt"))
            if txt_files:
                combined_content = ""
                for txt_file in txt_files:
                    with open(txt_file, 'r', encoding='utf-8') as f:
                        combined_content += f.read() + "\n\n"
                submission = evaluator.parse_agent_output(combined_content, "Consensus")
                agent_submissions.append(submission)
                print(f"  Consensus: {len(submission.generated_rules)} rules")

    else:
        print(f"❌ Invalid index_llm: {index_llm}")
        print("Valid options:")
        print("  -1: Coordinator")
        print("   0: Agent1")
        print("   1: Agent2")
        print("   2: Agent3")
        print("  -2: All individual agents")
        print("  -3: Consensus results only")
        print("  -4: Everything (individual + consensus)")
        exit(1)

    # Run Schema-PCA analysis if we have agent submissions
    if agent_submissions:
        print(f"\n🚀 RUNNING SCHEMA-PCA ANALYSIS")
        print(f"Total agents loaded: {len(agent_submissions)}")

        total_rules = sum(len(sub.generated_rules) for sub in agent_submissions)
        print(f"Total rules to analyze: {total_rules}")

        if total_rules > 0:
            # Compute final ranking BY PREDICATE
            results_by_predicate = evaluator.compute_final_ranking_by_predicate(agent_submissions)

            # Print detailed results BY PREDICATE
            evaluator.print_ranking_results_by_predicate(results_by_predicate)

            # Save results to file BY PREDICATE
            output_file = f"schema_pca_analysis_{COORDINATOR_LLM}_{index_llm}_by_predicate.txt"
            output_file=dataset+"_"+output_file
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write("MULTI-AGENT SCHEMA-PCA ANALYSIS RESULTS BY PREDICATE\n")
                f.write("=" * 60 + "\n")
                f.write(f"Coordinator LLM: {COORDINATOR_LLM}\n")
                f.write(f"Analysis Selection: {index_llm}\n")
                f.write(f"Total Agents: {len(agent_submissions)}\n")
                f.write(f"Total Rules: {total_rules}\n")
                f.write(f"Predicates Found: {len(results_by_predicate)}\n\n")

                # Write results by predicate
                for predicate in sorted(results_by_predicate.keys()):
                    results = results_by_predicate[predicate]
                    f.write(f"PREDICATE: {predicate.upper()}\n")
                    f.write("=" * (len(predicate) + 11) + "\n")
                    f.write(f"Total rules: {len(results)}\n\n")

                    for i, (rule, final_score, analysis) in enumerate(results):
                        f.write(f"  RANK {i + 1}: {rule}\n")
                        f.write(f"    Final Score: {final_score:.3f}\n")
                        f.write(f"    - Semantic: {analysis['semantic_score']:.3f}\n")
                        f.write(f"    - Structural: {analysis['structural_score']:.3f}\n")
                        f.write(f"    - Consistency: {analysis['consistency_score']:.3f}\n")
                        f.write(f"    Discovery Count: {analysis['discovery_count']} agents\n")
                        f.write(f"    Contributing Agents: {analysis['contributing_agents']}\n")

                        if analysis['justifications']:
                            f.write(f"    Justifications:\n")
                            for agent, justification in analysis['justifications'].items():
                                f.write(f"      {agent}: {justification}\n")

                        if analysis['counter_examples']:
                            f.write(f"    Counter-examples:\n")
                            for agent, counter in analysis['counter_examples'].items():
                                f.write(f"      {agent}: {counter}\n")

                        if analysis['assessments']:
                            f.write(f"    Assessments:\n")
                            for agent, assessment in analysis['assessments'].items():
                                f.write(f"      {agent}: {assessment}\n")

                        f.write("\n")

                    f.write("\n" + "-" * 60 + "\n\n")

            print(f"\n💾 Results saved to: {output_file}")

            # Print summary by predicate
            print(f"\n📊 SUMMARY BY PREDICATE:")
            total_unique_rules = sum(len(results) for results in results_by_predicate.values())
            print(f"Total unique rules after deduplication: {total_unique_rules}")
            for predicate in sorted(results_by_predicate.keys()):
                results = results_by_predicate[predicate]
                print(f"  {predicate}: {len(results)} unique rules")
        else:
            print("⚠️ No rules found to analyze")
    else:
        print("⚠️ No agent submissions loaded")

    print(f"\n💡 TO CHANGE ANALYSIS:")
    print("Change 'index_llm' value:")
    print("  -1: Coordinator only")
    print("   0: Agent1 only")
    print("   1: Agent2 only")
    print("   2: Agent3 only")
    print("  -2: All individual agents")
    print("  -3: Consensus results only")
    print("  -4: Everything (individual + consensus)")