import numpy as np
from typing import List, Dict, Tuple, Any, Set, Optional
from dataclasses import dataclass
from enum import Enum
import re
from collections import defaultdict


@dataclass
class Atom:
    """Represents a single atom in a rule"""
    predicate: str
    variables: List[str]  # Can be any number of variables

    def __str__(self):
        return f"{self.predicate}({','.join(self.variables)})"

    def get_variable_pairs(self) -> List[Tuple[str, str]]:
        """Get all adjacent variable pairs for binary predicates"""
        if len(self.variables) == 2:
            return [(self.variables[0], self.variables[1])]
        elif len(self.variables) > 2:
            # For n-ary predicates, return adjacent pairs
            return [(self.variables[i], self.variables[i + 1]) for i in range(len(self.variables) - 1)]
        return []


@dataclass
class Rule:
    """Represents a logical rule of any length"""
    head: Atom
    body: List[Atom]
    rule_id: str

    def __str__(self):
        if not self.body:
            return f"{self.head}"
        body_str = " ∧ ".join([str(atom) for atom in self.body])
        return f"{self.head} ⇐ {body_str}"

    def get_all_variables(self) -> Set[str]:
        """Get all unique variables in the rule"""
        variables = set(self.head.variables)
        for atom in self.body:
            variables.update(atom.variables)
        return variables

    def get_variable_connections(self) -> List[Tuple[str, str]]:
        """Get all variable connections (joins) in the rule body"""
        connections = []
        all_vars = []

        # Collect all variable positions
        for atom in self.body:
            all_vars.extend(atom.variables)

        # Find connections where same variable appears in different positions
        var_positions = defaultdict(list)
        for i, var in enumerate(all_vars):
            var_positions[var].append(i)

        # Each variable that appears multiple times creates connections
        for var, positions in var_positions.items():
            if len(positions) > 1:
                # Create connections between all positions of this variable
                for i in range(len(positions) - 1):
                    connections.append((var, var))  # Self-join through this variable

        return connections

    def get_rule_length(self) -> int:
        """Get the length of the rule (number of body atoms)"""
        return len(self.body)


@dataclass
class SchemaProperty:
    """Schema property for a predicate (supports n-ary predicates)"""
    predicate: str
    arity: int
    type_signature: List[str]  # List of types for each argument position
    is_functional: bool = False  # For binary predicates, functional in first argument
    subclass_relations: List[Tuple[str, str]] = None

    @property
    def domain(self) -> str:
        """First argument type (for backward compatibility)"""
        return self.type_signature[0] if self.type_signature else None

    @property
    def range(self) -> str:
        """Last argument type (for backward compatibility)"""
        return self.type_signature[-1] if len(self.type_signature) > 1 else None


class TypeMatch(Enum):
    PERFECT = "perfect"
    SUBCLASS = "subclass"
    SUPERCLASS = "superclass"
    UNRELATED = "unrelated"


class SchemaParser:
    """Parser for schema files in the specified format"""

    @staticmethod
    def parse_schema_file(file_path: str) -> Dict[str, SchemaProperty]:
        """
        Parse schema from file with format:
        <nodes> nationality[Person,Country] birthPlace[Person,Place] ...
        <edges> [nationality,Person,birthPlace] [nationality,Person,residence] ...
        """
        with open(file_path, 'r') as f:
            content = f.read()

        return SchemaParser.parse_schema_content(content)

    @staticmethod
    def parse_schema_content(content: str) -> Dict[str, SchemaProperty]:
        """Parse schema from string content"""
        schema_properties = {}

        # Extract nodes section
        nodes_match = re.search(r'<nodes>\s*(.*?)(?=<edges>|$)', content, re.DOTALL)
        if nodes_match:
            nodes_content = nodes_match.group(1).strip()
            schema_properties.update(SchemaParser._parse_nodes(nodes_content))

        # Extract edges section
        edges_match = re.search(r'<edges>\s*(.*?)$', content, re.DOTALL)
        if edges_match:
            edges_content = edges_match.group(1).strip()
            subclass_relations = SchemaParser._parse_edges(edges_content)

            # Add subclass relations to existing schema properties
            for predicate, relations in subclass_relations.items():
                if predicate in schema_properties:
                    schema_properties[predicate].subclass_relations = relations

        return schema_properties

    @staticmethod
    def _parse_nodes(nodes_content: str) -> Dict[str, SchemaProperty]:
        """
        Parse nodes section: nationality[Person,Country] birthPlace[Person,Place] ...
        """
        schema_properties = {}

        # Pattern to match predicate[Type1,Type2,...]
        node_pattern = r'(\w+)\[([^\]]+)\]'

        for match in re.finditer(node_pattern, nodes_content):
            predicate = match.group(1)
            types_str = match.group(2)

            # Split types by comma and clean whitespace
            types = [t.strip() for t in types_str.split(',')]

            # Create schema property
            schema_properties[predicate] = SchemaProperty(
                predicate=predicate,
                arity=len(types),
                type_signature=types,
                is_functional=False  # Can be set separately if needed
            )

        return schema_properties

    @staticmethod
    def _parse_edges(edges_content: str) -> Dict[str, List[Tuple[str, str]]]:
        """
        Parse edges section: [nationality,Person,birthPlace] [nationality,Person,residence] ...
        Returns subclass relations grouped by predicate
        """
        subclass_relations = defaultdict(list)

        # Pattern to match [pred1,type,pred2]
        edge_pattern = r'\[([^,]+),([^,]+),([^,]+)\]'

        for match in re.finditer(edge_pattern, edges_content):
            pred1 = match.group(1).strip()
            connecting_type = match.group(2).strip()
            pred2 = match.group(3).strip()

            # This represents a connection between predicates through a shared type
            # We can interpret this as a potential subclass relation or semantic connection
            # For now, we'll store these as potential semantic relationships
            subclass_relations[pred1].append((connecting_type, pred2))

        return dict(subclass_relations)

    @staticmethod
    def create_example_schema_file(file_path: str):
        """Create an example schema file for testing"""
        example_content = """<nodes>
nationality[Person,Country]
birthPlace[Person,Place] 
residence[Person,Place]
almaMater[Person,EducationalInstitution]
director[Person,Organization]
child[Person,Person]
parent[Person,Person]
spouse[Person,Person]
enrolledIn[Person,Course]
department[Course,EducationalInstitution]
graduatedFrom[Person,AcademicProgram]
isPartOf[AcademicProgram,EducationalInstitution]
worksFor[Person,Organization]
author[Person,Publication]
employer[Publication,Organization]

<edges>
[nationality,Person,birthPlace]
[nationality,Person,residence] 
[nationality,Person,almaMater]
[nationality,Person,director]
[nationality,Person,child]
[nationality,Person,parent]
[nationality,Person,spouse]
[almaMater,Person,enrolledIn]
[almaMater,EducationalInstitution,department]
[almaMater,Person,graduatedFrom]
[almaMater,EducationalInstitution,isPartOf]
"""

        with open(file_path, 'w') as f:
            f.write(example_content)

        print(f"Example schema file created at: {file_path}")


class GenericSchemaPCA:
    def __init__(self, schema_properties: Dict[str, SchemaProperty],
                 weights: Tuple[float, float, float] = (0.5, 0.2, 0.3),
                 max_rule_length: int = 5):
        """
        Initialize Generic Schema-PCA evaluator for any rule length

        Args:
            schema_properties: Dict mapping predicate names to SchemaProperty objects
            weights: (semantic_weight, structural_weight, consistency_weight)
            max_rule_length: Maximum rule length to consider for normalization
        """
        self.schema = schema_properties
        self.semantic_weight, self.structural_weight, self.consistency_weight = weights
        self.max_rule_length = max_rule_length

        # Build subclass hierarchy for type checking
        self.subclass_map = {}
        for prop in schema_properties.values():
            if prop.subclass_relations:
                for subclass, superclass in prop.subclass_relations:
                    if subclass not in self.subclass_map:
                        self.subclass_map[subclass] = set()
                    self.subclass_map[subclass].add(superclass)

    def get_type_match(self, actual_type: str, expected_type: str) -> TypeMatch:
        """Determine how well actual_type matches expected_type"""
        if actual_type == expected_type:
            return TypeMatch.PERFECT
        elif expected_type in self.subclass_map.get(actual_type, set()):
            return TypeMatch.SUBCLASS
        elif actual_type in self.subclass_map.get(expected_type, set()):
            return TypeMatch.SUPERCLASS
        else:
            return TypeMatch.UNRELATED

    def analyze_path_complexity(self, rule: Rule) -> Dict[str, Any]:
        """Analyze structural complexity of a rule of any length"""
        rule_length = rule.get_rule_length()
        all_variables = rule.get_all_variables()
        connections = rule.get_variable_connections()

        # Count unique joins (connections between different atoms)
        join_count = 0
        for i, atom1 in enumerate(rule.body):
            for j, atom2 in enumerate(rule.body[i + 1:], i + 1):
                # Check if atoms share variables
                shared_vars = set(atom1.variables) & set(atom2.variables)
                if shared_vars:
                    join_count += len(shared_vars)

        # Calculate path characteristics
        variable_reuse = sum(1 for var in all_variables
                             if sum(var in atom.variables for atom in rule.body + [rule.head]) > 1)

        return {
            'rule_length': rule_length,
            'variable_count': len(all_variables),
            'join_count': join_count,
            'variable_reuse': variable_reuse,
            'complexity_score': rule_length + (join_count * 0.5) + (variable_reuse * 0.3),
            'directness': 'direct' if rule_length == 1 else f'{rule_length}-hop'
        }

    def count_type_violations(self, rule: Rule) -> Dict[str, Any]:
        """Count type constraint violations in a rule of any length"""
        violations = []
        violation_count = 0

        # Check head predicate
        head_prop = self.schema.get(rule.head.predicate)
        if not head_prop:
            violations.append(f"Unknown head predicate: {rule.head.predicate}")
            violation_count += 1
            return {'violation_count': violation_count, 'details': violations}

        # Check head arity
        if len(rule.head.variables) != head_prop.arity:
            violations.append(f"Head arity mismatch: {len(rule.head.variables)} vs {head_prop.arity}")
            violation_count += 1

        # Track variable types through rule body and head
        var_types = {}

        # Process each body atom
        for atom in rule.body:
            body_prop = self.schema.get(atom.predicate)
            if not body_prop:
                violations.append(f"Unknown predicate: {atom.predicate}")
                violation_count += 1
                continue

            # Check arity
            if len(atom.variables) != body_prop.arity:
                violations.append(f"Arity mismatch for {atom.predicate}: {len(atom.variables)} vs {body_prop.arity}")
                violation_count += 1
                continue

            # Check type constraints for each argument position
            for i, var in enumerate(atom.variables):
                expected_type = body_prop.type_signature[i]

                if var in var_types:
                    # Variable already has a type, check compatibility
                    existing_type = var_types[var]
                    match = self.get_type_match(existing_type, expected_type)
                    if match == TypeMatch.UNRELATED:
                        violations.append(f"Type conflict for {var}: {existing_type} vs {expected_type}")
                        violation_count += 1
                    elif match == TypeMatch.SUPERCLASS:
                        # Update to more specific type
                        var_types[var] = expected_type
                else:
                    # First occurrence of this variable
                    var_types[var] = expected_type

        # Check head variable types
        for i, var in enumerate(rule.head.variables):
            if i < len(head_prop.type_signature):
                expected_type = head_prop.type_signature[i]

                if var in var_types:
                    existing_type = var_types[var]
                    match = self.get_type_match(existing_type, expected_type)
                    if match == TypeMatch.UNRELATED:
                        violations.append(f"Head type conflict for {var}: {existing_type} vs {expected_type}")
                        violation_count += 1
                else:
                    # Head variable not constrained by body
                    violations.append(f"Ungrounded head variable: {var}")
                    violation_count += 1

        return {
            'violation_count': violation_count,
            'details': violations,
            'var_types': var_types,
            'type_consistency_score': max(0, 1 - (violation_count * 0.2))  # Penalty per violation
        }

    def semantic_ranking(self, rules: List[Rule], agent_rankings: List[List[str]]) -> Dict[str, int]:
        """Convert agent rankings to consensus semantic ranking"""
        rule_ids = [rule.rule_id for rule in rules]
        borda_scores = {rule_id: 0 for rule_id in rule_ids}

        for ranking in agent_rankings:
            for i, rule_id in enumerate(ranking):
                if rule_id in borda_scores:  # Safety check
                    borda_scores[rule_id] += len(rule_ids) - i

        # Convert scores to ranks
        sorted_rules = sorted(borda_scores.items(), key=lambda x: x[1], reverse=True)
        semantic_ranks = {rule_id: rank + 1 for rank, (rule_id, score) in enumerate(sorted_rules)}

        return semantic_ranks

    def structural_ranking(self, rules: List[Rule]) -> Dict[str, int]:
        """Rank rules by structural complexity (simpler = better, length-normalized)"""
        complexity_scores = []

        for rule in rules:
            analysis = self.analyze_path_complexity(rule)

            # Normalize complexity by rule length to fairly compare different lengths
            rule_length = analysis['rule_length']
            base_complexity = analysis['complexity_score']

            # Length penalty: longer rules are inherently more complex
            length_penalty = rule_length / self.max_rule_length

            # Final complexity score (lower = better)
            final_complexity = base_complexity + length_penalty

            complexity_scores.append((rule.rule_id, final_complexity))

        # Sort by complexity (lower score = better rank)
        sorted_rules = sorted(complexity_scores, key=lambda x: x[1])
        structural_ranks = {rule_id: rank + 1 for rank, (rule_id, score) in enumerate(sorted_rules)}

        return structural_ranks

    def consistency_ranking(self, rules: List[Rule]) -> Dict[str, int]:
        """Rank rules by type consistency (fewer violations = better)"""
        violation_scores = []

        for rule in rules:
            violations = self.count_type_violations(rule)
            # Use both violation count and consistency score
            penalty = violations['violation_count'] + (1 - violations['type_consistency_score'])
            violation_scores.append((rule.rule_id, penalty))

        # Sort by penalty (lower penalty = better rank)
        sorted_rules = sorted(violation_scores, key=lambda x: x[1])
        consistency_ranks = {rule_id: rank + 1 for rank, (rule_id, score) in enumerate(sorted_rules)}

        return consistency_ranks

    def compute_final_ranking(self, rules: List[Rule], agent_rankings: List[List[str]]) -> List[
        Tuple[Rule, float, Dict[str, Any]]]:
        """Compute final Schema-PCA ranking for rules of any length"""

        # Validate input
        if not rules:
            return []

        # Get individual rankings
        semantic_ranks = self.semantic_ranking(rules, agent_rankings)
        structural_ranks = self.structural_ranking(rules)
        consistency_ranks = self.consistency_ranking(rules)

        # Compute weighted final scores
        final_scores = []

        for rule in rules:
            rule_id = rule.rule_id

            # Get individual ranks (lower rank = better)
            sem_rank = semantic_ranks.get(rule_id, len(rules))  # Default to worst if missing
            struct_rank = structural_ranks.get(rule_id, len(rules))
            cons_rank = consistency_ranks.get(rule_id, len(rules))

            # Weighted combination (lower = better)
            weighted_rank = (
                    self.semantic_weight * sem_rank +
                    self.structural_weight * struct_rank +
                    self.consistency_weight * cons_rank
            )

            # Detailed analysis
            analysis = {
                'rule_length': rule.get_rule_length(),
                'semantic_rank': sem_rank,
                'structural_rank': struct_rank,
                'consistency_rank': cons_rank,
                'weighted_rank': weighted_rank,
                'path_complexity': self.analyze_path_complexity(rule),
                'type_violations': self.count_type_violations(rule),
                'all_variables': list(rule.get_all_variables()),
                'variable_connections': rule.get_variable_connections()
            }

            final_scores.append((rule, weighted_rank, analysis))

        # Sort by weighted rank (lower = better)
        final_scores.sort(key=lambda x: x[1])

        return final_scores

    def print_ranking_results(self, ranked_rules: List[Tuple[Rule, float, Dict[str, Any]]]):
        """Print detailed ranking results for rules of any length"""
        print("=" * 100)
        print("GENERIC SCHEMA-PCA RANKING RESULTS")
        print("=" * 100)
        print(
            f"Weights: Semantic={self.semantic_weight}, Structural={self.structural_weight}, Consistency={self.consistency_weight}")
        print(f"Max Rule Length: {self.max_rule_length}")
        print()

        for i, (rule, score, analysis) in enumerate(ranked_rules):
            print(f"RANK {i + 1}: {rule}")
            print(f"  Rule Length: {analysis['rule_length']}")
            print(f"  Final Score: {score:.3f}")
            print(f"  Semantic Rank: {analysis['semantic_rank']}")
            print(f"  Structural Rank: {analysis['structural_rank']}")
            print(f"  Consistency Rank: {analysis['consistency_rank']}")
            print(f"  Variables: {analysis['all_variables']}")
            print(f"  Complexity Score: {analysis['path_complexity']['complexity_score']:.2f}")
            print(f"  Join Count: {analysis['path_complexity']['join_count']}")
            print(f"  Type Violations: {analysis['type_violations']['violation_count']}")
            if analysis['type_violations']['details']:
                print(f"  Violation Details: {analysis['type_violations']['details']}")
            print()


# Factory functions for creating rules of different lengths
def create_rule_length_1(head_pred: str, head_vars: Tuple[str, ...],
                         body_pred: str, body_vars: Tuple[str, ...], rule_id: str) -> Rule:
    """Create a length-1 rule"""
    head = Atom(head_pred, list(head_vars))
    body = [Atom(body_pred, list(body_vars))]
    return Rule(head, body, rule_id)


def create_rule_length_2(head_pred: str, head_vars: Tuple[str, ...],
                         body_pred1: str, body_vars1: Tuple[str, ...],
                         body_pred2: str, body_vars2: Tuple[str, ...], rule_id: str) -> Rule:
    """Create a length-2 rule"""
    head = Atom(head_pred, list(head_vars))
    body = [Atom(body_pred1, list(body_vars1)), Atom(body_pred2, list(body_vars2))]
    return Rule(head, body, rule_id)


def create_rule_length_3(head_pred: str, head_vars: Tuple[str, ...],
                         body_pred1: str, body_vars1: Tuple[str, ...],
                         body_pred2: str, body_vars2: Tuple[str, ...],
                         body_pred3: str, body_vars3: Tuple[str, ...], rule_id: str) -> Rule:
    """Create a length-3 rule"""
    head = Atom(head_pred, list(head_vars))
    body = [Atom(body_pred1, list(body_vars1)),
            Atom(body_pred2, list(body_vars2)),
            Atom(body_pred3, list(body_vars3))]
    return Rule(head, body, rule_id)


# Generic factory function
def create_rule(head_pred: str, head_vars: Tuple[str, ...],
                body_atoms: List[Tuple[str, Tuple[str, ...]]], rule_id: str) -> Rule:
    """
    Generic rule creation function

    Args:
        head_pred: Head predicate name
        head_vars: Head variables tuple
        body_atoms: List of (predicate, variables_tuple) for body atoms
        rule_id: Unique rule identifier
    """
    head = Atom(head_pred, list(head_vars))
    body = [Atom(pred, list(vars)) for pred, vars in body_atoms]
    return Rule(head, body, rule_id)


# Example usage with different rule lengths
def create_mixed_length_examples() -> List[Rule]:
    """Create example rules of different lengths"""
    return [
        # Length 1 rules
        create_rule('almaMater', ('X', 'Y'), [('worksFor', ('X', 'Y'))], 'R1_len1'),
        create_rule('almaMater', ('X', 'Y'), [('studiedAt', ('X', 'Y'))], 'R2_len1'),

        # Length 2 rules
        create_rule('almaMater', ('X', 'Y'), [
            ('enrolledIn', ('X', 'Z')),
            ('department', ('Z', 'Y'))
        ], 'R1_len2'),
        create_rule('almaMater', ('X', 'Y'), [
            ('graduatedFrom', ('X', 'Z')),
            ('isPartOf', ('Z', 'Y'))
        ], 'R2_len2'),

        # Length 3 rules
        create_rule('almaMater', ('X', 'Y'), [
            ('enrolled', ('X', 'Z')),
            ('inProgram', ('Z', 'W')),
            ('offeredBy', ('W', 'Y'))
        ], 'R1_len3'),
        create_rule('almaMater', ('X', 'Y'), [
            ('hasAdvisor', ('X', 'Z')),
            ('worksAt', ('Z', 'W')),
            ('partOf', ('W', 'Y'))
        ], 'R2_len3')
    ]


def create_generic_schema() -> Dict[str, SchemaProperty]:
    """Create schema supporting different rule lengths"""
    return {
        'almaMater': SchemaProperty('almaMater', 2, ['Person', 'EducationalInstitution'], is_functional=True),
        'worksFor': SchemaProperty('worksFor', 2, ['Person', 'Organization']),
        'studiedAt': SchemaProperty('studiedAt', 2, ['Person', 'EducationalInstitution']),
        'enrolledIn': SchemaProperty('enrolledIn', 2, ['Person', 'Course']),
        'department': SchemaProperty('department', 2, ['Course', 'EducationalInstitution']),
        'graduatedFrom': SchemaProperty('graduatedFrom', 2, ['Person', 'AcademicProgram']),
        'isPartOf': SchemaProperty('isPartOf', 2, ['AcademicProgram', 'EducationalInstitution']),
        'enrolled': SchemaProperty('enrolled', 2, ['Person', 'Enrollment']),
        'inProgram': SchemaProperty('inProgram', 2, ['Enrollment', 'AcademicProgram']),
        'offeredBy': SchemaProperty('offeredBy', 2, ['AcademicProgram', 'EducationalInstitution']),
        'hasAdvisor': SchemaProperty('hasAdvisor', 2, ['Person', 'Person']),
        'worksAt': SchemaProperty('worksAt', 2, ['Person', 'Department']),
        'partOf': SchemaProperty('partOf', 2, ['Department', 'EducationalInstitution'])
    }


# Example usage with schema file parsing
def demo_with_schema_file():
    """Demonstrate Schema-PCA with file-based schema loading"""

    # Create example schema file
    schema_file = "example_schema.txt"
    SchemaParser.create_example_schema_file(schema_file)

    # Parse schema from file
    print("Parsing schema from file...")
    schema = SchemaParser.parse_schema_file(schema_file)

    print(f"Loaded {len(schema)} predicates from schema file:")
    for pred, prop in schema.items():
        print(f"  {pred}: {prop.type_signature} (arity: {prop.arity})")
    print()

    # Create example rules
    rules = [
        create_rule('almaMater', ('X', 'Y'), [('enrolledIn', ('X', 'Z')), ('department', ('Z', 'Y'))], 'R1'),
        create_rule('almaMater', ('X', 'Y'), [('graduatedFrom', ('X', 'Z')), ('isPartOf', ('Z', 'Y'))], 'R2'),
        create_rule('almaMater', ('X', 'Y'), [('worksFor', ('X', 'Y'))], 'R3'),
        create_rule('nationality', ('X', 'Y'), [('birthPlace', ('X', 'Z')), ('residence', ('Z', 'Y'))], 'R4')
    ]

    # Agent rankings
    agent_rankings = [
        ['R2', 'R1', 'R4', 'R3'],
        ['R1', 'R2', 'R4', 'R3'],
        ['R2', 'R1', 'R4', 'R3'],
        ['R1', 'R2', 'R4', 'R3']
    ]

    # Initialize evaluator with parsed schema
    evaluator = GenericSchemaPCA(schema)

    # Compute ranking
    final_ranking = evaluator.compute_final_ranking(rules, agent_rankings)

    # Print results
    evaluator.print_ranking_results(final_ranking)

    return evaluator, final_ranking


def parse_schema_from_string_example():
    """Example of parsing schema directly from string"""

    schema_content = """<nodes>
nationality[Person,Country]
birthPlace[Person,Place] 
residence[Person,Place]
almaMater[Person,EducationalInstitution]
enrolledIn[Person,Course]
department[Course,EducationalInstitution]
graduatedFrom[Person,AcademicProgram]
isPartOf[AcademicProgram,EducationalInstitution]
worksFor[Person,Organization]

<edges>
[nationality,Person,birthPlace]
[nationality,Person,residence] 
[almaMater,Person,enrolledIn]
[almaMater,EducationalInstitution,department]
[almaMater,Person,graduatedFrom]
[almaMater,EducationalInstitution,isPartOf]
"""

    # Parse schema from string
    schema = SchemaParser.parse_schema_content(schema_content)

    print("Schema parsed from string:")
    for pred, prop in schema.items():
        print(f"  {pred}: {prop.type_signature}")
        if prop.subclass_relations:
            print(f"    Relations: {prop.subclass_relations}")

    return schema


# Utility function to convert your schema format to our internal format
def load_schema_for_solar(file_path: str) -> Dict[str, SchemaProperty]:
    """
    Load schema from file for use with SOLAR Schema-PCA

    Args:
        file_path: Path to schema file with <nodes> and <edges> sections

    Returns:
        Dictionary of SchemaProperty objects ready for Schema-PCA

    Example file format:
        <nodes>
        nationality[Person,Country]
        birthPlace[Person,Place]
        residence[Person,Place]
        almaMater[Person,EducationalInstitution]

        <edges>
        [nationality,Person,birthPlace]
        [nationality,Person,residence]
        [almaMater,Person,enrolledIn]
    """
    return SchemaParser.parse_schema_file(file_path)


# Convenience function for SOLAR integration
def evaluate_rules_with_schema_file(schema_file: str, rules: List[Rule],
                                    agent_rankings: List[List[str]],
                                    weights: Tuple[float, float, float] = (0.5, 0.2, 0.3)) -> List[
    Tuple[Rule, float, Dict[str, Any]]]:
    """
    Complete Schema-PCA evaluation using schema file

    Args:
        schema_file: Path to schema file
        rules: List of Rule objects to evaluate
        agent_rankings: List of rule preference rankings from LLM agents
        weights: (semantic, structural, consistency) weights

    Returns:
        List of (rule, score, analysis) tuples sorted by quality
    """
    # Load schema
    schema = load_schema_for_solar(schema_file)

    # Initialize evaluator
    evaluator = GenericSchemaPCA(schema, weights)

    # Compute ranking
    return evaluator.compute_final_ranking(rules, agent_rankings)


# Enhanced main execution with file parsing
if __name__ == "__main__":
    print("=== SCHEMA-PCA WITH FILE PARSING ===\n")

    # Demo 1: Parse from file
    print("1. PARSING SCHEMA FROM FILE:")
    evaluator, ranking = demo_with_schema_file()

    print("\n" + "=" * 60 + "\n")

    # Demo 2: Parse from string
    print("2. PARSING SCHEMA FROM STRING:")
    schema = parse_schema_from_string_example()

    print("\n" + "=" * 60 + "\n")

    # Demo 3: Manual schema creation (backward compatibility)
    print("3. MANUAL SCHEMA CREATION:")
    manual_schema = create_generic_schema()
    manual_rules = create_mixed_length_examples()

    manual_rankings = [
        ['R2_len1', 'R1_len2', 'R2_len2', 'R1_len3', 'R2_len3', 'R1_len1'],
        ['R1_len2', 'R2_len1', 'R2_len2', 'R1_len3', 'R2_len3', 'R1_len1'],
        ['R2_len2', 'R1_len2', 'R2_len1', 'R1_len3', 'R2_len3', 'R1_len1'],
        ['R1_len2', 'R2_len2', 'R2_len1', 'R1_len3', 'R2_len3', 'R1_len1']
    ]

    manual_evaluator = GenericSchemaPCA(manual_schema)
    manual_final_ranking = manual_evaluator.compute_final_ranking(manual_rules, manual_rankings)

    print("Manual schema results:")
    for i, (rule, score, analysis) in enumerate(manual_final_ranking[:3]):
        print(f"  {i + 1}. {rule.rule_id}: {score:.3f} (Length: {analysis['rule_length']})")

    print("\n=== ALL DEMOS COMPLETED ===")


# Additional utility functions for SOLAR integration

def create_schema_from_predicates(predicates_info: List[Tuple[str, List[str]]],
                                  functional_predicates: List[str] = None) -> Dict[str, SchemaProperty]:
    """
    Create schema from predicate information

    Args:
        predicates_info: List of (predicate_name, type_signature) tuples
        functional_predicates: List of predicate names that are functional

    Returns:
        Dictionary of SchemaProperty objects
    """
    schema = {}
    functional_set = set(functional_predicates or [])

    for pred_name, type_sig in predicates_info:
        schema[pred_name] = SchemaProperty(
            predicate=pred_name,
            arity=len(type_sig),
            type_signature=type_sig,
            is_functional=pred_name in functional_set
        )

    return schema


def quick_evaluate_rules(rules: List[Rule], agent_rankings: List[List[str]],
                         schema: Dict[str, SchemaProperty] = None,
                         schema_file: str = None) -> List[Tuple[str, float]]:
    """
    Quick evaluation returning just rule IDs and scores

    Args:
        rules: Rules to evaluate
        agent_rankings: Agent preference rankings
        schema: Schema dictionary (optional if schema_file provided)
        schema_file: Path to schema file (optional if schema provided)

    Returns:
        List of (rule_id, score) tuples sorted by quality
    """
    if schema_file and not schema:
        schema = load_schema_for_solar(schema_file)
    elif not schema and not schema_file:
        raise ValueError("Either schema or schema_file must be provided")

    evaluator = GenericSchemaPCA(schema)
    results = evaluator.compute_final_ranking(rules, agent_rankings)

    return [(rule.rule_id, score) for rule, score, _ in results]


def analyze_rule_quality(rule: Rule, schema: Dict[str, SchemaProperty]) -> Dict[str, Any]:
    """
    Analyze a single rule's quality components

    Args:
        rule: Rule to analyze
        schema: Schema dictionary

    Returns:
        Dictionary with detailed quality analysis
    """
    evaluator = GenericSchemaPCA(schema)

    complexity = evaluator.analyze_path_complexity(rule)
    violations = evaluator.count_type_violations(rule)

    return {
        'rule_length': rule.get_rule_length(),
        'variables': list(rule.get_all_variables()),
        'complexity': complexity,
        'type_violations': violations,
        'is_valid': violations['violation_count'] == 0,
        'quality_score': max(0, 1 - (complexity['complexity_score'] * 0.1) - (violations['violation_count'] * 0.2))
    }


def filter_valid_rules(rules: List[Rule], schema: Dict[str, SchemaProperty]) -> List[Rule]:
    """
    Filter rules to keep only those with no type violations

    Args:
        rules: List of rules to filter
        schema: Schema dictionary

    Returns:
        List of valid rules (no type violations)
    """
    valid_rules = []
    evaluator = GenericSchemaPCA(schema)

    for rule in rules:
        violations = evaluator.count_type_violations(rule)
        if violations['violation_count'] == 0:
            valid_rules.append(rule)

    return valid_rules


def export_ranking_results(results: List[Tuple[Rule, float, Dict[str, Any]]],
                           output_file: str, format: str = 'csv'):
    """
    Export ranking results to file

    Args:
        results: Results from compute_final_ranking
        output_file: Output file path
        format: Export format ('csv' or 'json')
    """
    if format == 'csv':
        import csv
        with open(output_file, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['Rank', 'Rule_ID', 'Rule', 'Score', 'Length', 'Semantic_Rank',
                             'Structural_Rank', 'Consistency_Rank', 'Type_Violations'])

            for i, (rule, score, analysis) in enumerate(results):
                writer.writerow([
                    i + 1,
                    rule.rule_id,
                    str(rule),
                    f"{score:.3f}",
                    analysis['rule_length'],
                    analysis['semantic_rank'],
                    analysis['structural_rank'],
                    analysis['consistency_rank'],
                    analysis['type_violations']['violation_count']
                ])

    elif format == 'json':
        import json
        export_data = []
        for i, (rule, score, analysis) in enumerate(results):
            export_data.append({
                'rank': i + 1,
                'rule_id': rule.rule_id,
                'rule': str(rule),
                'score': round(score, 3),
                'analysis': {
                    'rule_length': analysis['rule_length'],
                    'semantic_rank': analysis['semantic_rank'],
                    'structural_rank': analysis['structural_rank'],
                    'consistency_rank': analysis['consistency_rank'],
                    'complexity_score': round(analysis['path_complexity']['complexity_score'], 2),
                    'type_violations': analysis['type_violations']['violation_count']
                }
            })

        with open(output_file, 'w') as f:
            json.dump(export_data, f, indent=2)

    print(f"Results exported to {output_file} in {format} format")


# Example comprehensive workflow
def complete_schema_pca_workflow(schema_file: str, rules: List[Rule],
                                 agent_rankings: List[List[str]],
                                 output_dir: str = "results"):
    """
    Complete workflow: load schema, evaluate rules, export results

    Args:
        schema_file: Path to schema file
        rules: Rules to evaluate
        agent_rankings: Agent preference rankings
        output_dir: Directory for output files
    """
    import os

    # Create output directory
    os.makedirs(output_dir, exist_ok=True)

    # Load schema
    print("Loading schema...")
    schema = load_schema_for_solar(schema_file)
    print(f"Loaded {len(schema)} predicates")

    # Filter valid rules
    print("Filtering valid rules...")
    valid_rules = filter_valid_rules(rules, schema)
    print(f"Valid rules: {len(valid_rules)}/{len(rules)}")

    # Evaluate rules
    print("Evaluating rules with Schema-PCA...")
    evaluator = GenericSchemaPCA(schema)
    results = evaluator.compute_final_ranking(valid_rules, agent_rankings)

    # Print summary
    print("\nTop 5 rules:")
    for i, (rule, score, analysis) in enumerate(results[:5]):
        print(f"  {i + 1}. {rule.rule_id}: {score:.3f}")

    # Export results
    export_ranking_results(results, os.path.join(output_dir, "ranking_results.csv"), "csv")
    export_ranking_results(results, os.path.join(output_dir, "ranking_results.json"), "json")

    # Save detailed analysis
    with open(os.path.join(output_dir, "detailed_analysis.txt"), 'w') as f:
        f.write("SCHEMA-PCA DETAILED ANALYSIS\n")
        f.write("=" * 50 + "\n\n")

        for i, (rule, score, analysis) in enumerate(results):
            f.write(f"RANK {i + 1}: {rule}\n")
            f.write(f"  Score: {score:.3f}\n")
            f.write(f"  Length: {analysis['rule_length']}\n")
            f.write(f"  Complexity: {analysis['path_complexity']['complexity_score']:.2f}\n")
            f.write(f"  Violations: {analysis['type_violations']['violation_count']}\n")
            if analysis['type_violations']['details']:
                f.write(f"  Issues: {analysis['type_violations']['details']}\n")
            f.write("\n")

    print(f"\nComplete analysis saved to {output_dir}/")
    return results