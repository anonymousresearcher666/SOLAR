#!/usr/bin/env python3
"""
Rule Extractor Script - WITH JUSTIFICATIONS
Extracts logical rules and their justifications from all files in a specified folder.
Rules should be in format: "RULE X: head(X,Y) :- body1(X,Z), body2(Z,Y)"
Followed by: "Justification: explanation text..."
"""

import os
import re
import argparse
from pathlib import Path
from collections import defaultdict
import csv
import json


class RuleExtractor:
    def __init__(self, folder_path, output_format='txt'):
        self.folder_path = Path(folder_path)
        self.output_format = output_format.lower()
        self.rules_data = []
        self.stats = defaultdict(int)

        # Regex pattern to match rules
        # Matches: RULE X: predicate(args) :- body
        self.rule_pattern = re.compile(
            r'RULE\s+(\d+):\s*([^:]+)\s*:-\s*(.+)',
            re.IGNORECASE
        )

        # Pattern to extract predicate name from rule head
        self.predicate_pattern = re.compile(r'(\w+)\s*\([^)]+\)')

        # Pattern to match justifications
        # Matches: Justification: explanation text
        self.justification_pattern = re.compile(
            r'Justification:\s*(.+?)(?=\n\s*(?:RULE|\Z))',
            re.IGNORECASE | re.DOTALL
        )

    def extract_predicate_from_filename(self, filename):
        """Extract predicate name from filename."""
        # Remove .txt extension
        name_without_ext = filename.replace('.txt', '')

        # Common patterns for predicate extraction from filename
        # Try different approaches:

        # 1. If filename is just the predicate name
        if '_' not in name_without_ext and '-' not in name_without_ext:
            return name_without_ext

        # 2. If filename has underscores, try different splits
        if '_' in name_without_ext:
            parts = name_without_ext.split('_')
            # Often the predicate is the first part or the main part
            for part in parts:
                if part and not part.isdigit():  # Skip numeric parts
                    return part

        # 3. If filename has dashes
        if '-' in name_without_ext:
            parts = name_without_ext.split('-')
            for part in parts:
                if part and not part.isdigit():
                    return part

        # 4. Fallback: return the whole name without extension
        return name_without_ext

    def extract_rules_from_file(self, file_path):
        """Extract rules and justifications from a single file."""
        rules_found = []

        # Extract predicate from filename
        file_predicate = self.extract_predicate_from_filename(file_path.name)

        try:
            # Try different encodings
            for encoding in ['utf-8', 'latin-1', 'cp1252']:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        content = f.read()
                    break
                except UnicodeDecodeError:
                    continue
            else:
                print(f"Warning: Could not decode {file_path}")
                return rules_found

            # Split content into sections by RULE
            rule_sections = re.split(r'(?=RULE\s+\d+:)', content, flags=re.IGNORECASE)

            for section in rule_sections:
                if not section.strip():
                    continue

                # Find rule matches in this section
                rule_matches = self.rule_pattern.findall(section)

                if rule_matches:
                    for match in rule_matches:
                        rule_number = match[0]
                        rule_head = match[1].strip()
                        rule_body = match[2].strip()

                        # Extract predicate name from rule head (for verification)
                        pred_match = self.predicate_pattern.match(rule_head)
                        head_predicate = pred_match.group(1) if pred_match else "unknown"

                        # Look for justification in this section
                        justification = ""
                        justification_matches = self.justification_pattern.findall(section)
                        if justification_matches:
                            # Take the first justification found in this section
                            justification = justification_matches[0].strip()
                            # Clean up the justification text
                            justification = re.sub(r'\s+', ' ', justification)  # Normalize whitespace
                            justification = justification.replace('\n', ' ').strip()

                        rule_data = {
                            'file': file_path.name,
                            'file_predicate': file_predicate,  # Predicate from filename
                            'rule_number': int(rule_number),
                            'head_predicate': head_predicate,  # Predicate from rule head
                            'head': rule_head,
                            'body': rule_body,
                            'full_rule': f"{rule_head} :- {rule_body}",
                            'justification': justification,
                            'original_line': f"RULE {rule_number}: {rule_head} :- {rule_body}"
                        }

                        rules_found.append(rule_data)
                        self.stats['total_rules'] += 1
                        self.stats[f'file_predicate_{file_predicate}'] += 1
                        self.stats[f'head_predicate_{head_predicate}'] += 1
                        if justification:
                            self.stats['rules_with_justifications'] += 1

            if rules_found:
                self.stats['files_with_rules'] += 1
                justified_count = sum(1 for r in rules_found if r['justification'])
                print(
                    f"Found {len(rules_found)} rules for predicate '{file_predicate}' in {file_path.name} ({justified_count} with justifications)")
            else:
                print(f"No rules found in {file_path.name} (predicate: {file_predicate})")

        except Exception as e:
            print(f"Error processing {file_path}: {e}")

        return rules_found

    def process_folder(self):
        """Process all .txt files in the folder."""
        if not self.folder_path.exists():
            print(f"Error: Folder {self.folder_path} does not exist")
            return

        print(f"Processing .txt files in: {self.folder_path}")

        # Get only .txt files
        txt_files = [f for f in self.folder_path.iterdir()
                     if f.is_file() and f.suffix.lower() == '.txt']

        if not txt_files:
            print("No .txt files found in the folder")
            return

        print(f"Found {len(txt_files)} .txt files to process")
        self.stats['total_files'] = len(txt_files)

        # Process each .txt file
        for file_path in sorted(txt_files):  # Sort for consistent processing order
            print(f"Processing: {file_path.name}")
            rules = self.extract_rules_from_file(file_path)
            self.rules_data.extend(rules)

        print(f"\nProcessing complete!")
        print(f"Total .txt files processed: {self.stats['total_files']}")
        print(f"Files with rules: {self.stats['files_with_rules']}")
        print(f"Total rules extracted: {self.stats['total_rules']}")
        print(f"Rules with justifications: {self.stats.get('rules_with_justifications', 0)}")

    def get_file_predicate_stats(self):
        """Get statistics by file predicates."""
        predicate_counts = {}
        for key, value in self.stats.items():
            if key.startswith('file_predicate_'):
                predicate = key.replace('file_predicate_', '')
                predicate_counts[predicate] = value
        return predicate_counts

    def get_head_predicate_stats(self):
        """Get statistics by rule head predicates."""
        predicate_counts = {}
        for key, value in self.stats.items():
            if key.startswith('head_predicate_'):
                predicate = key.replace('head_predicate_', '')
                predicate_counts[predicate] = value
        return predicate_counts

    def save_results(self, output_file=None, no_verbose=False, simple_csv=False):
        """Save extracted rules to file."""
        if not self.rules_data:
            print("No rules to save")
            return

        if output_file is None:
            output_file = f"extracted_rules.{self.output_format}"

        if no_verbose:
            self.save_minimal(output_file)
        elif simple_csv:
            self.save_csv_simple(output_file)
        elif self.output_format == 'csv':
            self.save_csv(output_file)
        elif self.output_format == 'json':
            self.save_json(output_file)
        else:
            self.save_txt(output_file)

    def save_minimal(self, output_file):
        """Save in minimal format: just predicate, rules, and justifications."""
        with open(output_file, 'w', encoding='utf-8') as f:
            # Group by file predicate and sort
            rules_by_predicate = defaultdict(list)
            for rule in self.rules_data:
                rules_by_predicate[rule['file_predicate']].append(rule)

            # Output format: predicate followed by its rules and justifications
            for predicate in sorted(rules_by_predicate.keys()):
                f.write(f"{predicate}\n")

                # Sort rules by rule number within each predicate
                sorted_rules = sorted(rules_by_predicate[predicate],
                                      key=lambda x: (x['file'], x['rule_number']))

                for rule in sorted_rules:
                    f.write(f"{rule['full_rule']}\n")
                    if rule['justification']:
                        f.write(f"Justification: {rule['justification']}\n")
                    f.write("\n")  # Empty line after each rule

                f.write("\n")  # Extra line between predicates

        print(f"Minimal rules with justifications saved to: {output_file}")

    def save_txt(self, output_file):
        """Save as text file."""
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write("EXTRACTED LOGICAL RULES WITH JUSTIFICATIONS FROM .TXT FILES\n")
            f.write("=" * 60 + "\n\n")

            # Group by file predicate first, then by file
            rules_by_predicate = defaultdict(list)
            for rule in self.rules_data:
                rules_by_predicate[rule['file_predicate']].append(rule)

            # Sort predicates alphabetically
            for predicate in sorted(rules_by_predicate.keys()):
                f.write(f"PREDICATE: {predicate.upper()}\n")
                f.write("=" * (len(predicate) + 11) + "\n\n")

                # Group rules by file within each predicate
                rules_by_file = defaultdict(list)
                for rule in rules_by_predicate[predicate]:
                    rules_by_file[rule['file']].append(rule)

                # Sort files within predicate
                for filename in sorted(rules_by_file.keys()):
                    f.write(f"  FILE: {filename}\n")
                    f.write("  " + "-" * (len(filename) + 6) + "\n")

                    # Sort rules by rule number within file
                    for rule in sorted(rules_by_file[filename], key=lambda x: x['rule_number']):
                        f.write(f"  RULE {rule['rule_number']}: {rule['full_rule']}\n")
                        if rule['justification']:
                            f.write(f"  Justification: {rule['justification']}\n")

                        # Show if head predicate differs from file predicate
                        if rule['head_predicate'] != rule['file_predicate']:
                            f.write(
                                f"    (Note: Head predicate '{rule['head_predicate']}' differs from file predicate '{rule['file_predicate']}')\n")
                        f.write("\n")
                    f.write("\n")
                f.write("\n")

            # Add statistics
            f.write(f"STATISTICS\n")
            f.write("=" * 20 + "\n")
            f.write(f"Total .txt files processed: {self.stats['total_files']}\n")
            f.write(f"Files with rules: {self.stats['files_with_rules']}\n")
            f.write(f"Total rules extracted: {self.stats['total_rules']}\n")
            f.write(f"Rules with justifications: {self.stats.get('rules_with_justifications', 0)}\n")

            justified_percentage = (self.stats.get('rules_with_justifications', 0) / self.stats['total_rules'] * 100) if \
            self.stats['total_rules'] > 0 else 0
            f.write(f"Justification coverage: {justified_percentage:.1f}%\n")

            file_predicate_stats = self.get_file_predicate_stats()
            if file_predicate_stats:
                f.write(f"\nRules by file predicate:\n")
                for pred, count in sorted(file_predicate_stats.items(), key=lambda x: x[1], reverse=True):
                    f.write(f"  {pred}: {count} rules\n")

            head_predicate_stats = self.get_head_predicate_stats()
            if head_predicate_stats:
                f.write(f"\nRules by head predicate:\n")
                for pred, count in sorted(head_predicate_stats.items(), key=lambda x: x[1], reverse=True):
                    f.write(f"  {pred}: {count} rules\n")

        print(f"Rules with justifications saved to: {output_file}")

    def save_csv(self, output_file):
        """Save as CSV file with full details."""
        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=[
                'file_predicate', 'file', 'rule_number', 'head_predicate', 'head', 'body', 'full_rule', 'justification'
            ])
            writer.writeheader()
            for rule in sorted(self.rules_data, key=lambda x: (x['file_predicate'], x['file'], x['rule_number'])):
                writer.writerow({
                    'file_predicate': rule['file_predicate'],
                    'file': rule['file'],
                    'rule_number': rule['rule_number'],
                    'head_predicate': rule['head_predicate'],
                    'head': rule['head'],
                    'body': rule['body'],
                    'full_rule': rule['full_rule'],
                    'justification': rule['justification']
                })

        print(f"Rules with justifications saved to CSV: {output_file}")

    def save_csv_simple(self, output_file):
        """Save as simple CSV file: predicate, rule, justification."""
        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            # Write header
            writer.writerow(['predicate', 'rule', 'justification'])

            # Write data rows - one rule per line, no empty lines
            for rule in sorted(self.rules_data, key=lambda x: (x['file_predicate'], x['file'], x['rule_number'])):
                writer.writerow([
                    rule['file_predicate'],
                    rule['full_rule'],
                    rule['justification'] if rule['justification'] else ''
                ])

        print(f"Simple CSV (predicate, rule, justification) saved to: {output_file}")

    def save_json(self, output_file):
        """Save as JSON file."""
        output_data = {
            'metadata': {
                'total_txt_files': self.stats['total_files'],
                'files_with_rules': self.stats['files_with_rules'],
                'total_rules': self.stats['total_rules'],
                'rules_with_justifications': self.stats.get('rules_with_justifications', 0),
                'justification_coverage_percentage': (
                            self.stats.get('rules_with_justifications', 0) / self.stats['total_rules'] * 100) if
                self.stats['total_rules'] > 0 else 0,
                'file_predicate_counts': self.get_file_predicate_stats(),
                'head_predicate_counts': self.get_head_predicate_stats()
            },
            'rules': sorted(self.rules_data, key=lambda x: (x['file_predicate'], x['file'], x['rule_number']))
        }

        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(output_data, f, indent=2, ensure_ascii=False)

        print(f"Rules with justifications saved to JSON: {output_file}")

    def print_summary(self, no_verbose=False):
        """Print a summary of extracted rules."""
        if not self.rules_data:
            print("No rules found in .txt files")
            return

        if no_verbose:
            self.print_minimal_summary()
        else:
            self.print_detailed_summary()

    def print_minimal_summary(self):
        """Print minimal summary for --no-verbose mode."""
        justified_count = self.stats.get('rules_with_justifications', 0)
        print(
            f"Found {self.stats['total_rules']} rules across {len(self.get_file_predicate_stats())} predicates ({justified_count} with justifications)")

        # Just show the rules in minimal format with justifications
        rules_by_predicate = defaultdict(list)
        for rule in self.rules_data:
            rules_by_predicate[rule['file_predicate']].append(rule)

        for predicate in sorted(rules_by_predicate.keys()):
            print(f"\n{predicate}")
            sorted_rules = sorted(rules_by_predicate[predicate],
                                  key=lambda x: (x['file'], x['rule_number']))
            for rule in sorted_rules:
                print(f"{rule['full_rule']}")
                if rule['justification']:
                    print(f"Justification: {rule['justification']}")
                print()  # Empty line after each rule

    def print_detailed_summary(self):
        """Print detailed summary (original behavior)."""
        print(f"\nSUMMARY")
        print("=" * 40)
        print(f"Total .txt files processed: {self.stats['total_files']}")
        print(f"Files with rules: {self.stats['files_with_rules']}")
        print(f"Total rules extracted: {self.stats['total_rules']}")
        print(f"Rules with justifications: {self.stats.get('rules_with_justifications', 0)}")

        justified_percentage = (self.stats.get('rules_with_justifications', 0) / self.stats['total_rules'] * 100) if \
        self.stats['total_rules'] > 0 else 0
        print(f"Justification coverage: {justified_percentage:.1f}%")

        # Show rules by file predicate
        file_predicate_stats = self.get_file_predicate_stats()
        if file_predicate_stats:
            print(f"\nRules by file predicate:")
            sorted_preds = sorted(file_predicate_stats.items(), key=lambda x: x[1], reverse=True)
            for pred, count in sorted_preds:
                print(f"  {pred}: {count} rules")

        # Show some example rules grouped by predicate
        print(f"\nSample rules by predicate:")
        rules_by_predicate = defaultdict(list)
        for rule in self.rules_data:
            rules_by_predicate[rule['file_predicate']].append(rule)

        for predicate in sorted(rules_by_predicate.keys())[:3]:  # Show first 3 predicates
            print(f"\n  {predicate.upper()}:")
            for i, rule in enumerate(rules_by_predicate[predicate][:2]):  # Show first 2 rules per predicate
                print(f"    {i + 1}. {rule['full_rule']} (from {rule['file']})")
                if rule['justification']:
                    print(f"       Justification: {rule['justification'][:100]}..." if len(
                        rule['justification']) > 100 else f"       Justification: {rule['justification']}")
            if len(rules_by_predicate[predicate]) > 2:
                print(f"    ... and {len(rules_by_predicate[predicate]) - 2} more rules")

        if len(rules_by_predicate) > 3:
            remaining_preds = len(rules_by_predicate) - 3
            print(f"\n  ... and {remaining_preds} more predicates")

        # Check for mismatches between file predicate and head predicate
        mismatches = [r for r in self.rules_data if r['file_predicate'] != r['head_predicate']]
        if mismatches:
            print(f"\nWARNING: Found {len(mismatches)} rules where file predicate differs from head predicate:")
            for rule in mismatches[:3]:  # Show first 3 mismatches
                print(
                    f"  File '{rule['file']}' (predicate: {rule['file_predicate']}) contains rule with head: {rule['head_predicate']}")
            if len(mismatches) > 3:
                print(f"  ... and {len(mismatches) - 3} more mismatches")


def main():
    parser = argparse.ArgumentParser(
        description='Extract logical rules with justifications from .txt files in a folder')
    parser.add_argument('folder', help='Path to folder containing .txt files to process')
    parser.add_argument('-o', '--output', help='Output file name (optional)')
    parser.add_argument('-f', '--format', choices=['txt', 'csv', 'json'], default='txt',
                        help='Output format (default: txt)')
    parser.add_argument('--preview-only', action='store_true',
                        help='Only show preview, do not save to file')
    parser.add_argument('--no-verbose', action='store_true',
                        help='Minimal output: only predicate names, rules, and justifications')
    parser.add_argument('--simple-csv', action='store_true',
                        help='Export as simple CSV: predicate, rule, justification (no newlines between rules)')

    args = parser.parse_args()

    # Create extractor
    extractor = RuleExtractor(args.folder, args.format)

    # Process files
    extractor.process_folder()

    # Show summary
    extractor.print_summary(args.no_verbose)

    # Save results unless preview only
    if not args.preview_only:
        extractor.save_results(args.output, args.no_verbose, args.simple_csv)


# Alternative simple usage function
def extract_rules_simple(folder_path, output_file="extracted_rules.txt", no_verbose=False, simple_csv=False):
    """Simple function to extract rules with justifications from .txt files."""
    extractor = RuleExtractor(folder_path)
    extractor.process_folder()
    extractor.save_results(output_file, no_verbose, simple_csv)
    extractor.print_summary(no_verbose)
    return extractor.rules_data


# Test example
if __name__ == "__main__":
    # CONFIGURATION - SET YOUR EXPERIMENT DETAILS
    COORDINATOR_LLM = "ollama_gemma3:27b"
    participant_models = [
        "ollama_deepseek-r1:1.5b",
        "ollama_qwen2.5:72b",
        "ollama_qwen3:30b-a3b"
    ]

    # CHOOSE WHAT TO EXTRACT:
    # -1: Coordinator
    #  0: Agent1 (first participant)
    #  1: Agent2 (second participant)
    #  2: Agent3 (third participant)
    # -2: All individual agents
    # -3: Consensus results
    # -4: Everything (individual + consensus)
    index_llm = 0  # SET THIS TO CHOOSE WHAT TO EXTRACT

    # Base paths
    BASE_EXPERIMENT_PATH = "/SOLAR/gen_rules/yago/c2r_new/graph/2/two_phase_consensus_" + COORDINATOR_LLM
    INDIVIDUAL_EXPERIMENT_PATH = f"{BASE_EXPERIMENT_PATH}/individual_rules"
    CONSENSUS_EXPERIMENT_PATH = f"{BASE_EXPERIMENT_PATH}/consensus_results"

    # Determine path and output filename based on selection
    if index_llm == -1:
        # Coordinator
        path = f"{INDIVIDUAL_EXPERIMENT_PATH}/Coordinator_{COORDINATOR_LLM}"
        out_path = f"coordinator_{COORDINATOR_LLM}_rules_with_justifications.txt"
        print(f"🎯 Extracting COORDINATOR: {COORDINATOR_LLM}")

    elif 0 <= index_llm < len(participant_models):
        # Specific agent
        agent_model = participant_models[index_llm]
        path = f"{INDIVIDUAL_EXPERIMENT_PATH}/Agent{index_llm + 1}_{agent_model}"
        out_path = f"agent_{index_llm + 1}_{agent_model}_rules_with_justifications.txt"
        print(f"🎯 Extracting AGENT {index_llm + 1}: {agent_model}")

    elif index_llm == -2:
        # All individual agents
        print(f"🎯 Extracting ALL INDIVIDUAL AGENTS")
        results = {}

        # Extract coordinator
        coord_path = f"{INDIVIDUAL_EXPERIMENT_PATH}/Coordinator_{COORDINATOR_LLM}"
        coord_out = f"coordinator_{COORDINATOR_LLM}_rules.txt"
        print(f"\n🔄 Processing Coordinator: {COORDINATOR_LLM}")
        coord_rules = extract_rules_simple(coord_path, coord_out, no_verbose=True)
        results['coordinator'] = len(coord_rules)

        # Extract all agents
        for i, model in enumerate(participant_models):
            agent_path = f"{INDIVIDUAL_EXPERIMENT_PATH}/Agent{i + 1}_{model}"
            agent_out = f"agent_{i + 1}_{model}_rules.txt"
            print(f"\n🔄 Processing Agent {i + 1}: {model}")
            agent_rules = extract_rules_simple(agent_path, agent_out, no_verbose=True)
            results[f'agent_{i + 1}'] = len(agent_rules)

        print(f"\n✅ EXTRACTION COMPLETE:")
        for agent, count in results.items():
            print(f"  {agent}: {count} rules")

    elif index_llm == -3:
        # Consensus results only
        path = CONSENSUS_EXPERIMENT_PATH
        out_path = f"consensus_{COORDINATOR_LLM}_rules_with_justifications.txt"
        print(f"🎯 Extracting CONSENSUS RESULTS")

    elif index_llm == -4:
        # Everything (individual + consensus)
        print(f"🎯 Extracting EVERYTHING (Individual + Consensus)")
        results = {}

        # Extract individual agents (reuse -2 logic)
        print("\n📁 EXTRACTING INDIVIDUAL AGENTS:")

        # Coordinator
        coord_path = f"{INDIVIDUAL_EXPERIMENT_PATH}/Coordinator_{COORDINATOR_LLM}"
        coord_out = f"coordinator_{COORDINATOR_LLM}_rules.txt"
        print(f"🔄 Coordinator: {COORDINATOR_LLM}")
        coord_rules = extract_rules_simple(coord_path, coord_out, no_verbose=True)
        results['coordinator'] = len(coord_rules)

        # Agents
        for i, model in enumerate(participant_models):
            agent_path = f"{INDIVIDUAL_EXPERIMENT_PATH}/Agent{i + 1}_{model}"
            agent_out = f"agent_{i + 1}_{model}_rules.txt"
            print(f"🔄 Agent {i + 1}: {model}")
            agent_rules = extract_rules_simple(agent_path, agent_out, no_verbose=True)
            results[f'agent_{i + 1}'] = len(agent_rules)

        # Extract consensus
        print(f"\n📁 EXTRACTING CONSENSUS:")
        consensus_path = CONSENSUS_EXPERIMENT_PATH
        consensus_out = f"consensus_{COORDINATOR_LLM}_rules.txt"
        print(f"🔄 Consensus results")
        consensus_rules = extract_rules_simple(consensus_path, consensus_out, no_verbose=True)
        results['consensus'] = len(consensus_rules)

        print(f"\n✅ COMPLETE EXTRACTION FINISHED:")
        for agent, count in results.items():
            print(f"  {agent}: {count} rules")

    else:
        print(f"❌ Invalid index_llm: {index_llm}")
        print("Valid options:")
        print("  -1: Coordinator")
        print("   0: Agent1")
        print("   1: Agent2")
        print("   2: Agent3")
        print("  -2: All individual agents")
        print("  -3: Consensus results only")
        print("  -4: Everything (individual + consensus)")
        exit(1)

    # Extract single path (for individual selections)
    if index_llm not in [-2, -4]:
        print(f"📂 Path: {path}")
        print(f"📄 Output: {out_path}")

        # Extract rules
        rules = extract_rules_simple(path, out_path, no_verbose=True)
        print(f"✅ Extracted {len(rules)} rules")

    print(f"\n🎯 CURRENT SELECTION SUMMARY:")
    print(f"Coordinator LLM: {COORDINATOR_LLM}")
    print(f"Participant Models: {participant_models}")
    print(f"Selection (index_llm): {index_llm}")

    selection_names = {
        -1: "Coordinator",
        0: "Agent1", 1: "Agent2", 2: "Agent3",
        -2: "All Individual Agents",
        -3: "Consensus Results",
        -4: "Everything"
    }
    print(f"Extracting: {selection_names.get(index_llm, 'Unknown')}")

    print(f"\n💡 TO CHANGE SELECTION:")
    print("Change 'index_llm' value:")
    print("  -1: Coordinator only")
    print("   0: Agent1 only")
    print("   1: Agent2 only")
    print("   2: Agent3 only")
    print("  -2: All individual agents")
    print("  -3: Consensus results only")
    print("  -4: Everything (individual + consensus)")