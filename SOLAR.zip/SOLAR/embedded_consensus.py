import argparse
from functools import partial
from multiprocessing.pool import ThreadPool
from tqdm import tqdm
from data import *
from llm import call_models
from llm.consensus_llms import simulate_consensus_discussion


def assign_variables_to_prompt(head, predicates, k, m, schema, prompt_with_variables):
    """
    Assign variables to the prompt template.
    Uses the same logic as main_SOLAR.py for individual rule generation.
    """
    final_prompt = ""
    # Convert template to f-string format
    final_prompt = prompt_with_variables.replace("{{head}}", str(head)) \
        .replace("{{k}}", str(k)) \
        .replace("{{schema}}", str(schema)) \
        .replace("{{number}}", str(m))

    # Substitute the variables using an f-string
    final_prompt = final_prompt.format(
        head=head,
        k=k,
        schema=schema,
        predicates=predicates
    )

    return final_prompt


def create_directory_with_progressive_number(base_path, dir_name):
    """Create directory with progressive numbering if directory exists."""
    counter = 1
    new_dir_name = dir_name
    while os.path.exists(os.path.join(base_path, new_dir_name)):
        new_dir_name = f"{dir_name}_{counter}"
        counter += 1
    new_dir_path = os.path.join(base_path, new_dir_name)
    os.makedirs(new_dir_path)
    return new_dir_path


def generate_individual_rules(input_predicate, schema_predicates, schema, rule_path, args, 
                            prompt_with_variables, agent_name, agent_llm):
    """
    Generate rules for a single agent/coordinator (Phase 1).
    This mirrors the logic from main_SOLAR.py but for individual agents.
    """
    rule_head = input_predicate

    # Build prompt for individual rule generation
    current_prompt = assign_variables_to_prompt(
        rule_head, schema_predicates, args.numbodyatoms, args.m, schema, prompt_with_variables)

    # Create agent-specific directory
    agent_rule_path = os.path.join(rule_path, "individual_rules", agent_name)
    os.makedirs(agent_rule_path, exist_ok=True)

    if args.is_zero:  # For zero-shot setting
        query_file = os.path.join(agent_rule_path, f"{rule_head}_zero_shot.query")
        result_file = os.path.join(agent_rule_path, f"{rule_head}_zero_shot.txt")
    else:  # For few-shot setting
        file_name = rule_head.replace("/", "-")
        query_file = os.path.join(agent_rule_path, f"{file_name}.query")
        result_file = os.path.join(agent_rule_path, f"{file_name}.txt")

    # Save query
    with open(query_file, "w") as f:
        f.write(current_prompt + "\n")

    # Generate rules if not dry run
    if not args.dry_run:
        response = call_models.query_remote_llm(current_prompt, llm=agent_llm)
        with open(result_file, "w") as f:
            f.write(f"Agent: {agent_name}\n")
            f.write(f"Rule_head: {rule_head}\n")
            f.write(str(response) + "\n")
        return str(response)
    return ""


def run_consensus_phase(input_predicate, individual_rules, coordinator_llm, agent_llms, 
                       schema, rule_path, args, prompt_path):
    """
    Run consensus phase (Phase 2) using individual rules from all agents.
    """
    rule_head = input_predicate
    
    # Combine all individual rules into a single string for consensus
    combined_rules = ""
    agent_names = list(individual_rules.keys())
    
    for agent_name, rules in individual_rules.items():
        combined_rules += f"\n=== {agent_name} RULES ===\n"
        combined_rules += rules + "\n"
    
    # Create consensus directory
    consensus_rule_path = os.path.join(rule_path, "consensus_results")
    os.makedirs(consensus_rule_path, exist_ok=True)
    
    # Run consensus discussion
    consensus_response = simulate_consensus_discussion(
        coordinator_llm=coordinator_llm,
        agents=agent_llms,
        rules=combined_rules,
        schema=schema,
        rounds=args.consensus_rounds,
        prompt_path=prompt_path
    )
    
    # Save consensus results
    if args.is_zero:
        consensus_file = os.path.join(consensus_rule_path, f"{rule_head}_zero_shot_consensus.txt")
    else:
        file_name = rule_head.replace("/", "-")
        consensus_file = os.path.join(consensus_rule_path, f"{file_name}_consensus.txt")
    
    with open(consensus_file, "w") as f:
        f.write(f"Rule_head: {rule_head}\n")
        f.write("=== INDIVIDUAL RULES FROM ALL AGENTS ===\n")
        f.write(combined_rules + "\n")
        f.write("=== CONSENSUS DISCUSSION ===\n")
        f.write(consensus_response + "\n")


def generate_two_phase_consensus(input_predicate, schema_predicates, schema, rule_path, args, 
                               prompt_with_variables, coordinator_llm, agent_llms, prompt_path):
    """
    Two-phase consensus: First individual rule generation, then consensus.
    """
    rule_head = input_predicate
    
    # Phase 1: Individual rule generation for each agent
    print(f"Phase 1: Generating individual rules for {rule_head}")
    individual_rules = {}
    
    # Generate rules for coordinator
    coordinator_name = f"Coordinator_{args.coordinator_model}"
    coordinator_rules = generate_individual_rules(
        input_predicate, schema_predicates, schema, rule_path, args,
        prompt_with_variables, coordinator_name, coordinator_llm
    )
    individual_rules[coordinator_name] = coordinator_rules
    
    # Generate rules for each agent
    for i, (agent_name, agent_llm) in enumerate(agent_llms.items()):
        agent_rules = generate_individual_rules(
            input_predicate, schema_predicates, schema, rule_path, args,
            prompt_with_variables, agent_name, agent_llm
        )
        individual_rules[agent_name] = agent_rules
    
    # Phase 2: Consensus phase
    if not args.dry_run:
        print(f"Phase 2: Running consensus for {rule_head}")
        run_consensus_phase(
            input_predicate, individual_rules, coordinator_llm, agent_llms,
            schema, rule_path, args, prompt_path
        )


def create_agent_llms(coordinator_model, agent_models):
    """Create dictionary of agent LLMs from model names."""
    # Create coordinator LLM
    coordinator_llm = call_models.create_llm(coordinator_model)
    
    # Create agent LLMs
    agents = {}
    for i, model_name in enumerate(agent_models):
        agent_name = f"Agent{i+1}_{model_name}"
        agents[agent_name] = call_models.create_llm(model_name)
    
    return coordinator_llm, agents


def main(args):
    """Main function for two-phase consensus rule generation."""
    prompt_path = os.path.join(args.data_path, "prompts") + "/"
    data_path = os.path.join(args.data_path, args.dataset) + "/"

    dataset = Dataset(data_root=data_path, prompt_path=prompt_path, dataset_name=args.dataset)
    schema = dataset.read_schema(args.schema_type)
    schema_predicates = dataset.read_predicates()
    
    # Use the specified prompt for individual rule generation
    prompt_with_variables = dataset.read_prompt(args.prompt_type)

    # Create LLMs for coordinator and agents
    coordinator_llm, agent_llms = create_agent_llms(args.coordinator_model, args.agent_models)
    
    # Update num_agents to match provided models
    args.num_agents = len(args.agent_models)

    # Save paths
    rule_path = os.path.join(
        args.rule_path,
        args.dataset + "/" + f"{args.prompt_type}" + "/" + f"{args.schema_type}" + "/" + f"{args.numbodyatoms}",
        f"{args.prefix}two_phase_consensus_{args.coordinator_model}",
    )
    rule_path = create_directory_with_progressive_number(rule_path, rule_path)
    
    print(f"Coordinator: {args.coordinator_model}")
    print(f"Agents: {args.agent_models}")
    print(f"Number of agents: {args.num_agents}")
    print(f"Prompt type: {args.prompt_type}")
    print(f"Schema type: {args.schema_type}")
    print(f"Body atoms: {args.numbodyatoms}")
    print(f"Rules per predicate: {args.m}")
    print(f"Consensus rounds: {args.consensus_rounds}")
    print("\n=== Starting Two-Phase Consensus Rule Generation ===")
    
    # Generate rules with two-phase consensus
    with ThreadPool(args.n) as p:
        for _ in tqdm(
                p.imap_unordered(
                    partial(
                        generate_two_phase_consensus,
                        schema_predicates=schema_predicates,
                        rule_path=rule_path,
                        args=args,
                        schema=schema,
                        prompt_with_variables=prompt_with_variables,
                        coordinator_llm=coordinator_llm,
                        agent_llms=agent_llms,
                        prompt_path=prompt_path
                    ),
                    schema_predicates,
                ),
                total=len(schema_predicates),
        ):
            pass


if __name__ == "__main__":
    import os

    base_path = "."
    parser = argparse.ArgumentParser(description="Two-Phase Consensus Rule Generation")
    parser.add_argument(
        "--data_path", type=str, default=base_path + "/SOLAR/dataset", help="data directory"
    )
    parser.add_argument(
        "--prompt_type", type=str, default="c2r_new",
        help="Type of prompt for individual rule generation (base,zs,fs,cot,c2r,c2rcl,c2r_counter,c2r_confidence)"
    )
    parser.add_argument(
        "--schema_type", type=str, default="graph", help="Type of schema graph (domain_range,graph,line)"
    )
    parser.add_argument("--dataset", type=str, default="family",
                        help="dataset")  # family,dbpedia, yago3, fb15k187, airgraph,yago26K906
    parser.add_argument(
        "--rule_path", type=str, default=base_path + "SOLAR/gen_rules", help="path to rule file"
    )
    
    # Consensus-specific arguments
    parser.add_argument("--coordinator_model", type=str, default="ollama_gemma3:27b", 
                        help="Model to use as coordinator")
    parser.add_argument("--agent_models", type=str, nargs='+', 
                        default=["ollama_deepseek-r1:1.5b", "ollama_qwen2.5:72b", "ollama_qwen3:30b-a3b"],
                        help="Models to use as debate agents")
    parser.add_argument("--consensus_rounds", type=int, default=3,
                        help="Number of consensus debate rounds")
    
    parser.add_argument(
        "--is_zero",
        action="store_true",
        help="Enable this for zero-shot rule generation",
    )
    parser.add_argument(
        "-m",
        type=int,
        default=10,
        help="Number of generated rules, 0 denotes as much as possible",
    )
    parser.add_argument(
        "-numbodyatoms",
        type=int,
        default=2,
        help="Number of atoms in the body",
    )
    parser.add_argument(
        "-numex",
        type=int,
        default=1,
        help="Number of examples",
    )
    parser.add_argument("-n", type=int, default=1, help="multi thread number")
    parser.add_argument(
        "-l", type=int, default=3, help="sample l times for generating k rules"
    )
    parser.add_argument("--prefix", type=str, default="", help="prefix")
    parser.add_argument("--dry_run", action="store_true", help="dry run")
    
    args, _ = parser.parse_known_args()
    args = parser.parse_args()

    main(args)