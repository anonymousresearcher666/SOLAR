import argparse
from functools import partial
from multiprocessing.pool import ThreadPool

from tqdm import tqdm

from data import *
from extract_subschema import extract_subschema
from llm import call_models
from llm.consensus_llms import simulate_consensus_discussion


def assign_variables_to_prompt(head, predicates, k, m, schema, prompt_with_variables):
    final_prompt = ""
    # Convert template to f-string format
    final_prompt = prompt_with_variables.replace("{{head}}", str(head)) \
        .replace("{{k}}", str(k)) \
        .replace("{{schema}}", str(schema)) \
        # .replace("{{number}}", str(m))

    # Substitute the variables using an f-string
    final_prompt = final_prompt.format(
        head=head,
        k=k,
        schema=schema,
        predicates=predicates
    )

    return final_prompt


def create_directory_with_progressive_number(base_path, dir_name):
    # Initialize the counter
    counter = 1
    new_dir_name = dir_name
    # Check if the directory already exists and increment the counter if it does
    while os.path.exists(os.path.join(base_path, new_dir_name)):
        new_dir_name = f"{dir_name}_{counter}"
        counter += 1
    # Create the new directory
    new_dir_path = os.path.join(base_path, new_dir_name)
    os.makedirs(new_dir_path)
    return new_dir_path


def generate_rule_consensuOLD(input_predicate, schema_predicates, schema, rule_path, args, prompt_with_variables,
                            coordinator_llm, prompt_path, agent_llms):
    rule_head = input_predicate

    ##extract a head-centerd subschema (return in teh same format as that in input)
    _, schema = extract_subschema(schema=schema, input_predicate=rule_head, max_length=args.numbodyatoms)
    # print(schema)

    # Build prompt excluding rules
    current_prompt = assign_variables_to_prompt(
        rule_head, schema_predicates, args.numbodyatoms, args.m, schema, prompt_with_variables)

    if args.is_zero:  # For zero-shot setting
        with open(os.path.join(rule_path, f"{rule_head}_zero_shot_consensus.query"), "w") as f:
            f.write(current_prompt + "\n")
            f.close()
        if not args.dry_run:
            # First generate initial rules with coordinator
            initial_response = call_models.query_remote_llm(current_prompt, llm=coordinator_llm)

            # Then run consensus discussion
            consensus_response = simulate_consensus_discussion(
                coordinator_llm=coordinator_llm,
                agents=agent_llms,
                rules=str(initial_response),
                schema=schema,
                rounds=args.consensus_rounds,
                prompt_path=prompt_path
            )

            with open(os.path.join(rule_path, f"{rule_head}_zero_shot_consensus.txt"), "w") as f:
                f.write("=== INITIAL RESPONSE ===\n")
                f.write(str(initial_response) + "\n\n")
                f.write("=== CONSENSUS DISCUSSION ===\n")
                f.write(consensus_response + "\n")
                f.close()
    else:

        file_name = rule_head.replace("/", "-")
        with open(os.path.join(rule_path, f"{file_name}_consensus.txt"), "w") as rule_file, open(
                os.path.join(rule_path, f"{file_name}_consensus.query"), "w"
        ) as query_file:
            rule_file.write(f"Rule_head: {rule_head}\n")
            prompt = current_prompt

            query_file.write(prompt + "\n")
            if not args.dry_run:
                # First generate initial rules with coordinator
                initial_response = call_models.query_remote_llm(current_prompt, llm=coordinator_llm)

                # Then run consensus discussion
                consensus_response = simulate_consensus_discussion(
                    coordinator_llm=coordinator_llm,
                    agents=agent_llms,
                    rules=str(initial_response),
                    schema=schema,
                    rounds=args.consensus_rounds,
                    prompt_path=prompt_path
                )

                rule_file.write("=== INITIAL RESPONSE ===\n")
                rule_file.write(str(initial_response) + "\n\n")
                rule_file.write("=== CONSENSUS DISCUSSION ===\n")
                rule_file.write(consensus_response + "\n")


def generate_rule_consensus(input_predicate, schema_predicates, schema, rule_path, args, prompt_with_variables,
                            coordinator_llm, prompt_path, agent_llms):
    rule_head = input_predicate

    # Extract a head-centered subschema (return in the same format as that in input)
    _, schema = extract_subschema(schema=schema, input_predicate=rule_head, max_length=args.numbodyatoms)

    # Build prompt excluding rules
    current_prompt = assign_variables_to_prompt(
        rule_head, schema_predicates, args.numbodyatoms, args.m, schema, prompt_with_variables)

    if args.is_zero:  # For zero-shot setting
        file_suffix = f"_zero_shot_{args.spca_mode}"
        with open(os.path.join(rule_path, f"{rule_head}{file_suffix}.query"), "w") as f:
            f.write(current_prompt + "\n")
            f.close()

        if not args.dry_run:
            # First generate initial rules with coordinator
            initial_response = call_models.query_remote_llm(current_prompt, llm=coordinator_llm)

            # Choose evaluation method based on SPCA mode
            if args.spca_mode == "consensus":
                # SPCA^{cons}: Multi-agent consensus discussion
                evaluation_response = simulate_consensus_discussion(
                    coordinator_llm=coordinator_llm,
                    agents=agent_llms,
                    rules=str(initial_response),
                    schema=schema,
                    rounds=args.consensus_rounds,
                    prompt_path=prompt_path
                )
                evaluation_header = "=== CONSENSUS DISCUSSION ==="

            elif args.spca_mode == "pool":
                # SPCA^{pool}: Independent ranking pool
                evaluation_response = collect_independent_rankings(
                    agents=agent_llms,
                    rules=str(initial_response),
                    schema=schema,
                    prompt_path=prompt_path
                )
                evaluation_header = "=== INDEPENDENT RANKINGS ==="

            else:
                raise ValueError(f"Unknown SPCA mode: {args.spca_mode}")

            with open(os.path.join(rule_path, f"{rule_head}{file_suffix}.txt"), "w") as f:
                f.write("=== INITIAL RESPONSE ===\n")
                f.write(str(initial_response) + "\n\n")
                f.write(f"{evaluation_header}\n")
                f.write(evaluation_response + "\n")
                f.close()

    else:
        file_name = rule_head.replace("/", "-")
        file_suffix = f"_{args.spca_mode}"

        with open(os.path.join(rule_path, f"{file_name}{file_suffix}.txt"), "w") as rule_file, open(
                os.path.join(rule_path, f"{file_name}{file_suffix}.query"), "w"
        ) as query_file:
            rule_file.write(f"Rule_head: {rule_head}\n")
            prompt = current_prompt

            query_file.write(prompt + "\n")

            if not args.dry_run:
                # First generate initial rules with coordinator
                initial_response = call_models.query_remote_llm(current_prompt, llm=coordinator_llm)

                # Choose evaluation method based on SPCA mode
                if args.spca_mode == "consensus":
                    # SPCA^{cons}: Multi-agent consensus discussion
                    evaluation_response = simulate_consensus_discussion(
                        coordinator_llm=coordinator_llm,
                        agents=agent_llms,
                        rules=str(initial_response),
                        schema=schema,
                        rounds=args.consensus_rounds,
                        prompt_path=prompt_path
                    )
                    evaluation_header = "=== CONSENSUS DISCUSSION ==="

                elif args.spca_mode == "pool":
                    # SPCA^{pool}: Independent ranking pool
                    evaluation_response = collect_independent_rankings(
                        agents=agent_llms,
                        rules=str(initial_response),
                        schema=schema,
                        prompt_path=prompt_path
                    )
                    evaluation_header = "=== INDEPENDENT RANKINGS ==="

                else:
                    raise ValueError(f"Unknown SPCA mode: {args.spca_mode}")

                rule_file.write("=== INITIAL RESPONSE ===\n")
                rule_file.write(str(initial_response) + "\n\n")
                rule_file.write(f"{evaluation_header}\n")
                rule_file.write(evaluation_response + "\n")


def collect_independent_rankings(agents, rules, schema, prompt_path):
    """
    Collect independent rankings from multiple agents for SPCA^{pool} evaluation.
    """
    # Load the SPCA^{pool} prompt template
    with open(os.path.join(prompt_path, "spca_pool_prompt.txt"), "r") as f:
        pool_prompt_template = f.read()

    rankings = []

    for i, agent in enumerate(agents):
        # Create evaluation prompt for this agent
        evaluation_prompt = pool_prompt_template.format(
            rules=rules,
            schema=schema,
            agent_id=i + 1
        )

        # Get independent ranking from this agent
        agent_ranking = call_models.query_remote_llm(evaluation_prompt, llm=agent)
        rankings.append(f"=== AGENT {i + 1} RANKING ===\n{agent_ranking}\n")

    return "\n".join(rankings)



def create_agent_llms(agent_models):
    """Create dictionary of agent LLMs from model names."""
    agents = {}
    for i, model_name in enumerate(agent_models):
        agent_name = f"Agent{i + 1}_{model_name}"
        agents[agent_name] = call_models.create_llm(model_name)
    return agents


def main(args):
    prompt_path = os.path.join(args.data_path, "prompts") + "/"
    data_path = os.path.join(args.data_path, args.dataset) + "/"

    dataset = Dataset(data_root=data_path, prompt_path=prompt_path, dataset_name=args.dataset)
    schema = dataset.read_schema(args.schema_type)
    schema_predicates = dataset.read_predicates()
    prompt_with_variables = dataset.read_prompt(args.prompt_type)

    # Save paths
    rule_path = os.path.join(
        args.rule_path,
        args.dataset + "/" + f"{args.prompt_type}" + "/" + f"{args.schema_type}" + "/" + f"{args.numbodyatoms}",
        f"{args.prefix}consensus_{args.coordinator_model}",
    )
    rule_path = create_directory_with_progressive_number(rule_path, rule_path)

    # Create LLMs
    coordinator_llm = call_models.create_llm(args.coordinator_model)
    agent_llms = create_agent_llms(args.agent_models)

    print(f"Coordinator: {args.coordinator_model}")
    print(f"Agents: {args.agent_models}")
    print(f"Consensus rounds: {args.consensus_rounds}")

    # Generate rules with consensus
    with ThreadPool(args.n) as p:
        for _ in tqdm(
                p.imap_unordered(
                    partial(
                        generate_rule_consensus,
                        schema_predicates=schema_predicates,
                        rule_path=rule_path,
                        args=args,
                        schema=schema,
                        prompt_with_variables=prompt_with_variables,
                        coordinator_llm=coordinator_llm,
                        prompt_path=prompt_path,
                        agent_llms=agent_llms
                    ),
                    schema_predicates,
                ),
                total=len(schema_predicates),
        ):
            pass


if __name__ == "__main__":
    import os

    base_path = "/Volumes/DATI/"
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--data_path", type=str, default=base_path + "GitHub/SOLAR/dataset", help="data directory"
    )
    parser.add_argument(
        "--prompt_type", type=str, default="c2r_new",
        help="Type of prompt (base,zs,fs,cot,c2r,c2rcl,c2r_counter,c2r_confidence)"
    )

    parser.add_argument(
        "--schema_type", type=str, default="line", help="Type of schema graph (domain_range,graph,line)"
    )

    parser.add_argument("--dataset", type=str, default="yago",
                        help="dataset")  # family,dbpedia, yago3, fb15k187, airgraph,yago26K906, schemadotorg

    parser.add_argument(
        "--rule_path", type=str, default=base_path + "GitHub/SOLAR/gen_rules", help="path to rule file"
    )


    parser.add_argument(
        "--spca_mode", type=str, default="consensus", help="SPCA ranking strategy" #consensus or pool
    )

    # Consensus-specific arguments
    parser.add_argument("--coordinator_model", type=str, default="ollama_qwen2.5:latest",
                        help="Model to use as coordinator")

    parser.add_argument("--agent_models", type=str, nargs='+',
                        default=["ollama_deepseek-r1:1.5b", "ollama_gemma3:27b", "ollama_llama3:latest"],
                        help="Models to use as debate agents")
    parser.add_argument("--consensus_rounds", type=int, default=3,
                        help="Number of consensus debate rounds")

    parser.add_argument(
        "--is_zero",
        action="store_true",
        help="Enable this for zero-shot rule generation",
    )
    parser.add_argument(
        "-m",
        type=int,
        default=10,
        help="Number of generated rules, 0 denotes as much as possible",
    )

    parser.add_argument(
        "-numbodyatoms",
        type=int,
        default=2,
        help="Number of atoms in the body",
    )

    parser.add_argument(
        "-numex",
        type=int,
        default=1,
        help="Number of examples",
    )

    parser.add_argument("-n", type=int, default=1, help="multi thread number")
    parser.add_argument(
        "-l", type=int, default=3, help="sample l times for generating k rules"
    )

    parser.add_argument("--prefix", type=str, default="", help="prefix")
    parser.add_argument("--dry_run", action="store_true", help="dry run")
    args, _ = parser.parse_known_args()
    args = parser.parse_args()

    main(args)
