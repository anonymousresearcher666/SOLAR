import os
import tiktoken
from llama_index.core import Settings
from llama_index.core.llms import ChatMessage, MessageRole
from llama_index.llms.anthropic import Anthropic
from llama_index.llms.gemini import Gemini
from llama_index.llms.ollama import Ollama
from llama_index.llms.openai import OpenAI
from typing import List, Tuple
def create_llm(model_name: str = "gpt-3.5-turbo", timeout: int = 1200):
    """Creates an LLM instance based on the model name."""
    try:
        if model_name.startswith("gpt"):
            return OpenAI(model=model_name, timeout=timeout)
        elif model_name.startswith("claude"):
             # Adjust max_tokens for Anthropic if needed, default is often sufficient
            return Anthropic(model=model_name, timeout=timeout, max_tokens=4000)
        elif model_name.startswith("gemini"):
            # Ensure the model name format is correct for the Gemini API
            # e.g., "gemini-1.5-pro-latest" or "gemini-1.0-pro"
            # The "models/" prefix might be specific to certain SDK versions/uses
            gemini_model_id = f"models/{model_name}" if "models/" not in model_name else model_name
            return Gemini(model=gemini_model_id) # timeout might not be direct param, handled by underlying client
        elif model_name.startswith("ollama_"):
            m_name = model_name[7:]  # strip the prefix ollama_
            return Ollama(model=m_name, request_timeout=timeout)
        else:
            raise ValueError(f"Unknown or unsupported model prefix: {model_name}")
    except Exception as e:
        print(f"Error creating LLM for {model_name}: {e}")
        raise # Re-raise the exception to stop execution if LLM can't be created


def simulate_consensus_discussion(
        coordinator_llm,
        agents: dict,
        rules: str,
        schema: str,
        rounds: int = 3,
        prompt_path: str = None,
        predicate_id: str = None  # NEW: Unique identifier for this predicate
) -> str:
    """Token-optimized multi-turn discussion between LLM agents and coordinator.

    CRITICAL: Each call is for a DIFFERENT predicate - all history must be reset!
    """

    # 🔴 CRITICAL: RESET ALL CONVERSATION STATE
    print(f"🔄 RESETTING for new predicate: {predicate_id or 'unknown'}")

    # 1. EXTRACT STATIC CONTENT (cached/reused)
    predicate_session_id = f"PRED_{hash(rules + schema) % 10000}_{predicate_id or 'unknown'}"
    static_schema_ref = f"[SCHEMA_ID: {predicate_session_id}]"

    # 2. COMPRESSED PROMPTS
    if prompt_path:
        with open(prompt_path + "consensus_prompt.txt", 'r') as f:
            base_prompt = f.read()
        with open(prompt_path + "consensus_user_instruction.txt", 'r') as f:
            user_instruction = f.read()

    # 3. 🔴 FRESH SESSION SETUP - NO PREVIOUS PREDICATE CONTAMINATION
    fresh_schema_setup = ChatMessage(
        role=MessageRole.SYSTEM,
        content=(
            f"[NEW_SESSION: {predicate_session_id}]\n"
            f"[CACHE_BOUNDARY]Schema Context:\n{schema}\n[/CACHE_BOUNDARY]\n"
            f"{base_prompt.format(coordinator_name=coordinator_llm)}\n"
            f"🔴 IMPORTANT: This is a completely new predicate analysis. "
            f"Ignore any previous discussions about other predicates."
        )
    )

    # 4. COMPRESSED INITIAL INSTRUCTION (no schema repetition)
    initial_instruction = user_instruction.format(
        rules=rules,
        schema=static_schema_ref,  # Reference only!
        rounds=rounds,
        coordinator_name=coordinator_llm
    )

    # 5. 🔴 COMPLETELY FRESH CONVERSATION STATE
    conversation_summary = ""  # Reset summary
    current_round_history = []  # Reset round history

    print(f"--- Starting FRESH Token-Optimized Debate for {predicate_session_id} ---")

    # 6. CONVERSATION SUMMARIZATION STRATEGY
    def summarize_previous_rounds(history: List[ChatMessage], max_summary_tokens: int = 500) -> str:
        """Compress conversation history into key points."""
        if len(history) <= 3:  # Keep short conversations as-is
            return ""

        # Extract key points from each agent's contributions
        agent_positions = {}
        for msg in history:
            if hasattr(msg, 'additional_kwargs') and 'agent_name' in msg.additional_kwargs:
                agent_name = msg.additional_kwargs['agent_name']
                if agent_name not in agent_positions:
                    agent_positions[agent_name] = []
                # Extract first sentence as key position
                first_sentence = msg.content.split('.')[0] + '.'
                agent_positions[agent_name].append(first_sentence)

        # Create compressed summary
        summary_parts = []
        for agent, positions in agent_positions.items():
            latest_position = positions[-1] if positions else "No clear position"
            summary_parts.append(f"{agent}: {latest_position}")

        return f"Summary of CURRENT predicate discussion:\n" + "\n".join(summary_parts)

    # 7. 🔴 AGENT DISCUSSION WITH EXPLICIT SESSION ISOLATION
    for r in range(rounds):
        print(f"--- Round {r + 1} ---")
        round_responses = []

        for agent_name, agent_llm in agents.items():
            # 🔴 BUILD COMPLETELY FRESH CONTEXT FOR THIS AGENT
            agent_context = [fresh_schema_setup]  # Fresh session with explicit reset

            # Add compressed history ONLY from current predicate discussion
            if conversation_summary:
                summary_msg = ChatMessage(
                    role=MessageRole.SYSTEM,
                    content=f"🔴 CURRENT PREDICATE ONLY: {conversation_summary}"
                )
                agent_context.append(summary_msg)

            # Add only current round's relevant exchanges (not full history!)
            if current_round_history:
                recent_context = ChatMessage(
                    role=MessageRole.SYSTEM,
                    content=f"Current round context (THIS PREDICATE ONLY): {'; '.join(current_round_history[-3:])}"
                )
                agent_context.append(recent_context)

            # 🔴 EXPLICIT AGENT PROMPT WITH SESSION ISOLATION
            agent_prompt = ChatMessage(
                role=MessageRole.USER,
                content=(
                    f"🔴 NEW PREDICATE SESSION: {predicate_session_id}\n"
                    f"{agent_name}, analyze ONLY these rules for THIS predicate: {rules[:200]}{'...' if len(rules) > 200 else ''}\n"
                    f"Ignore any previous predicate discussions. Your position (max 150 words):"
                )
            )
            agent_context.append(agent_prompt)

            try:
                print(f"Asking {agent_name} (context: {sum(len(msg.content) for msg in agent_context)} chars)...")
                response = agent_llm.chat(agent_context)
                agent_response = response.message.content

                # Store only essential info
                round_responses.append(f"{agent_name}: {agent_response}")
                current_round_history.append(f"{agent_name}: {agent_response[:100]}...")  # Truncated for next context

                print(f"{agent_name}: {agent_response}\n")

            except Exception as e:
                print(f"Error with {agent_name}: {e}")
                round_responses.append(f"{agent_name}: [Error]")

        # 8. UPDATE ROLLING SUMMARY (compress old rounds)
        if r > 0:  # After first round, start summarizing
            # Compress previous rounds into summary
            conversation_summary = summarize_previous_rounds(
                [ChatMessage(role=MessageRole.ASSISTANT, content=resp) for resp in round_responses[:-len(agents)]]
            )

        # Keep only current round in active history
        current_round_history = current_round_history[-len(agents):]  # Only current round

    # 9. 🔴 COORDINATOR FINAL CONSENSUS (completely fresh context)
    print(f"--- Coordinator Summarization for {predicate_session_id} ---")

    final_context = [
        fresh_schema_setup,  # Fresh session setup
        ChatMessage(
            role=MessageRole.SYSTEM,
            content=(
                f"🔴 FINAL CONSENSUS FOR PREDICATE: {predicate_session_id}\n"
                f"{conversation_summary if conversation_summary else 'No previous discussion for this predicate.'}"
            )
        ),
        ChatMessage(
            role=MessageRole.SYSTEM,
            content=f"Final round positions (THIS PREDICATE ONLY): {'; '.join(current_round_history)}"
        ),
        ChatMessage(
            role=MessageRole.USER,
            content=(
                f"🔴 FINAL TASK FOR {predicate_session_id}\n"
                f"{coordinator_llm}, provide final consensus ranking for THIS predicate only "
                f"with confidence levels (max 200 words). Ignore all previous predicates:"
            )
        )
    ]

    try:
        total_chars = sum(len(msg.content) for msg in final_context)
        print(f"Final consensus context: {total_chars} chars...")

        final_response = coordinator_llm.chat(final_context)
        consensus_content = final_response.message.content

        print(f"\n{coordinator_llm}: {consensus_content}\n")
        return consensus_content

    except Exception as e:
        print(f"Error during coordinator's summarization: {e}")
        return "Error: Could not generate final consensus."


# ADDITIONAL OPTIMIZATION: Prompt Caching Wrapper
def cache_optimized_chat(llm, messages, cache_boundary_content=None):
    """Wrapper to leverage prompt caching when available."""
    if cache_boundary_content and hasattr(llm, 'supports_caching'):
        # Restructure messages to maximize cache hits
        cached_msgs = [msg for msg in messages if cache_boundary_content in msg.content]
        non_cached_msgs = [msg for msg in messages if cache_boundary_content not in msg.content]
        return llm.chat(cached_msgs + non_cached_msgs)
    else:
        return llm.chat(messages)


# TOKEN USAGE MONITORING
def estimate_tokens(text: str) -> int:
    """Rough token estimation: ~4 chars per token."""
    return len(text) // 4


def log_token_usage(messages: List[ChatMessage], stage: str):
    """Log token usage for monitoring."""
    total_chars = sum(len(msg.content) for msg in messages)
    estimated_tokens = estimate_tokens(''.join(msg.content for msg in messages))
    print(f"[TOKEN USAGE] {stage}: ~{estimated_tokens} tokens ({total_chars} chars)")
